<?php
/**
 * Atomic locks and single-use records stored as rows in the options table.
 *
 * add_option() is not atomic (it upserts), so these helpers use INSERT IGNORE
 * against the unique option_name index and compare-and-swap updates instead.
 * Rows are written with autoload disabled and are never read through
 * get_option(), so the object cache cannot return stale values.
 *
 * @package Reckon_WC
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Atomic INSERT IGNORE / compare-and-swap cannot be done through the options API,
// and caching would defeat the lock. Every query is prepared.
// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

class Reckon_WC_Lock {

	const PREFIX = '_reckon_wc_lock_';

	/**
	 * Acquire a named lock.
	 *
	 * @param string $name Lock name (letters, digits, underscore, hyphen).
	 * @param int    $ttl  Seconds before an unreleased lock is considered abandoned.
	 * @return string|false Lock token on success, false when another holder owns it.
	 */
	public static function acquire( $name, $ttl ) {
		$option = self::option_name( $name );
		$token  = self::new_token();
		$value  = $token . '|' . ( time() + max( 1, (int) $ttl ) );

		if ( self::insert_if_absent( $option, $value ) ) {
			return $token;
		}

		$current = self::read( $option );
		if ( null === $current ) {
			// Released between our insert and read; try once more.
			return self::insert_if_absent( $option, $value ) ? $token : false;
		}

		$parts   = explode( '|', $current );
		$expires = isset( $parts[1] ) ? (int) $parts[1] : 0;
		if ( $expires > time() ) {
			return false;
		}

		// Abandoned lock: take it over only if nobody else did first.
		return self::compare_and_swap( $option, $current, $value ) ? $token : false;
	}

	/**
	 * Release a lock held with the given token. Never releases someone else's lock.
	 *
	 * @param string $name  Lock name.
	 * @param string $token Token returned by acquire().
	 * @return bool
	 */
	public static function release( $name, $token ) {
		global $wpdb;
		if ( ! is_string( $token ) || '' === $token ) {
			return false;
		}
		$option  = self::option_name( $name );
		$current = self::read( $option );
		if ( null === $current || 0 !== strpos( $current, $token . '|' ) ) {
			return false;
		}
		$deleted = $wpdb->query(
			$wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name = %s AND option_value = %s", $option, $current )
		);
		return 1 === (int) $deleted;
	}

	/**
	 * Confirm this holder still owns the lock and extend it. Fails if another
	 * process took the lock over (for example after it expired).
	 *
	 * @param string $name  Lock name.
	 * @param string $token Token returned by acquire().
	 * @param int    $ttl   New time to live in seconds.
	 * @return bool
	 */
	public static function refresh( $name, $token, $ttl ) {
		global $wpdb;
		if ( ! is_string( $token ) || '' === $token ) {
			return false;
		}
		$option  = self::option_name( $name );
		$current = self::read( $option );
		if ( null === $current || 0 !== strpos( $current, $token . '|' ) ) {
			// Ownership was lost, or the lock was taken over after it expired.
			return false;
		}
		$value = $token . '|' . ( time() + max( 1, (int) $ttl ) );

		// A refresh inside the same second as the acquisition/previous refresh
		// produces an identical value. The prefix check above already proved this
		// holder still owns the lock, so nothing needs to change. A compare-and-swap
		// here would update zero rows (MySQL reports *changed* rows, not matched
		// rows) and could be misread as losing ownership.
		if ( $value === $current ) {
			return true;
		}

		$updated = $wpdb->query(
			$wpdb->prepare(
				"UPDATE {$wpdb->options} SET option_value = %s WHERE option_name = %s AND option_value = %s",
				$value,
				$option,
				$current
			)
		);
		if ( false === $updated ) {
			// A database failure is not the same as losing ownership; neither is
			// it a success. Callers stop without sending, and the difference is
			// recorded so the failure is diagnosable.
			Reckon_WC_Logger::error( 'Lock refresh failed at the database layer.', array( 'operation' => 'lock' ) );
			return false;
		}
		// 1 row updated = still owned and extended. 0 rows = someone else replaced it.
		return 1 === (int) $updated;
	}

	/**
	 * Whether a lock is currently held and not expired.
	 *
	 * @param string $name Lock name.
	 * @return bool
	 */
	public static function is_locked( $name ) {
		$current = self::read( self::option_name( $name ) );
		if ( null === $current ) {
			return false;
		}
		$parts = explode( '|', $current );
		return isset( $parts[1] ) && (int) $parts[1] > time();
	}

	/**
	 * Store a single-use record. Returns false if a record with the name exists.
	 *
	 * @param string $option Full option name.
	 * @param string $value  Value.
	 * @return bool
	 */
	public static function insert_if_absent( $option, $value ) {
		global $wpdb;
		$inserted = $wpdb->query(
			$wpdb->prepare(
				"INSERT IGNORE INTO {$wpdb->options} (option_name, option_value, autoload) VALUES (%s, %s, 'no')",
				$option,
				$value
			)
		);
		return 1 === (int) $inserted;
	}

	/**
	 * Read a raw row value directly from the database.
	 *
	 * @param string $option Full option name.
	 * @return string|null
	 */
	public static function read( $option ) {
		global $wpdb;
		$value = $wpdb->get_var(
			$wpdb->prepare( "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s LIMIT 1", $option )
		);
		return null === $value ? null : (string) $value;
	}

	/**
	 * Atomically delete a record, succeeding for exactly one caller.
	 *
	 * @param string $option Full option name.
	 * @param string $value  Expected current value.
	 * @return bool True when this call removed the row.
	 */
	public static function consume( $option, $value ) {
		global $wpdb;
		$deleted = $wpdb->query(
			$wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name = %s AND option_value = %s", $option, $value )
		);
		return 1 === (int) $deleted;
	}

	/**
	 * Replace a row value only if it still holds the expected value.
	 *
	 * @param string $option   Full option name.
	 * @param string $expected Expected current value.
	 * @param string $value    New value.
	 * @return bool
	 */
	private static function compare_and_swap( $option, $expected, $value ) {
		global $wpdb;
		$updated = $wpdb->query(
			$wpdb->prepare(
				"UPDATE {$wpdb->options} SET option_value = %s WHERE option_name = %s AND option_value = %s",
				$value,
				$option,
				$expected
			)
		);
		return 1 === (int) $updated;
	}

	/**
	 * Build the option name for a lock.
	 *
	 * @param string $name Lock name.
	 * @return string
	 */
	private static function option_name( $name ) {
		return self::PREFIX . preg_replace( '/[^A-Za-z0-9_\-]/', '', (string) $name );
	}

	/**
	 * Random token.
	 *
	 * @return string
	 */
	private static function new_token() {
		try {
			return bin2hex( random_bytes( 16 ) );
		} catch ( Exception $e ) {
			return wp_generate_password( 32, false, false );
		}
	}
}
