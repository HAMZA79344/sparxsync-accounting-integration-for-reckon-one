<?php
/**
 * "What will be sent" preview of the Reckon invoice for an order.
 *
 * Runs the same Reckon_WC_Invoice_Builder::prepare() step the worker uses, with the
 * saved mappings and the cached Reckon data. It never calls the Reckon API: item
 * lookups by SKU and the customer match happen only when the order is sent, so the
 * preview says so instead of guessing.
 *
 * @package Reckon_WC
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Reckon_WC_Invoice_Preview {

	/**
	 * Build the preview.
	 *
	 * @param WC_Order   $order    Order.
	 * @param array      $mappings Mappings option.
	 * @param array      $book     Book option.
	 * @param array|null $ref      Cached Reckon data for the book (ledger_accounts, tax_rates, tax_settings).
	 * @return array {
	 *     @type string $error    Message when the order cannot be sent as it is; '' otherwise.
	 *     @type array  $lines    Each: name, kind, quantity, amount, tax, destination, tax_code.
	 *     @type array  $totals   net, tax, gross (major units).
	 *     @type string $status   Inclusive|Exclusive|NonTaxed.
	 *     @type string $currency Currency code.
	 *     @type array  $notes    Things checked only when the order is sent.
	 * }
	 */
	public static function build( $order, $mappings, $book, $ref ) {
		$out = array(
			'error'    => '',
			'lines'    => array(),
			'totals'   => array(),
			'status'   => '',
			'currency' => '',
			'notes'    => array(),
		);
		if ( '' === $book['book_id'] ) {
			$out['error'] = __( 'No Reckon book is selected yet.', 'sparxsync-accounting-integration-for-reckon-one' );
			return $out;
		}
		if ( $mappings['book_id'] !== $book['book_id'] ) {
			$out['error'] = __( 'Save the account and tax mappings for the selected book first.', 'sparxsync-accounting-integration-for-reckon-one' );
			return $out;
		}
		if ( ! is_array( $ref ) ) {
			$out['error'] = __( 'Reckon data for this book is not loaded. Use "Refresh Reckon data" in the settings.', 'sparxsync-accounting-integration-for-reckon-one' );
			return $out;
		}

		$prepared = Reckon_WC_Invoice_Builder::prepare( $order, $mappings, $book, isset( $ref['tax_settings'] ) ? $ref['tax_settings'] : array() );
		if ( is_wp_error( $prepared ) ) {
			$out['error'] = $prepared->get_error_message();
			return $out;
		}

		$scale    = pow( 10, $prepared['dp'] );
		$accounts = array(
			'product'  => $mappings['sales_account'],
			'shipping' => $mappings['shipping_account'],
			'fee'      => $mappings['fee_account'],
		);
		$policy   = $mappings['product_policy'];

		foreach ( $prepared['lines'] as $line ) {
			$account_name = self::name_of( isset( $ref['ledger_accounts'] ) ? $ref['ledger_accounts'] : array(), $accounts[ $line['kind'] ] );
			if ( 'product' === $line['kind'] && 'account_only' !== $policy && '' !== $line['sku'] ) {
				/* translators: %s: product SKU. */
				$destination = sprintf( __( 'Reckon item with code "%s"', 'sparxsync-accounting-integration-for-reckon-one' ), $line['sku'] );
				if ( 'item_or_account' === $policy ) {
					/* translators: %s: ledger account name. */
					$destination .= ' ' . sprintf( __( '(or %s if not found)', 'sparxsync-accounting-integration-for-reckon-one' ), $account_name );
				}
			} elseif ( 'product' === $line['kind'] && 'require_item' === $policy ) {
				$destination  = __( 'No SKU', 'sparxsync-accounting-integration-for-reckon-one' );
				/* translators: %s: line name. */
				$out['error'] = sprintf( __( 'Product "%s" has no SKU, but your product policy requires a matching Reckon item. Add a SKU or change the policy.', 'sparxsync-accounting-integration-for-reckon-one' ), $line['name'] );
			} else {
				$destination = $account_name;
			}

			$out['lines'][] = array(
				'name'        => $line['name'],
				'kind'        => $line['kind'],
				'quantity'    => $line['quantity'],
				'amount'      => $line['amount_c'] / $scale,
				'tax'         => $line['tax_c'] / $scale,
				'destination' => $destination,
				'tax_code'    => null === $line['tax_rate'] ? '' : self::name_of( isset( $ref['tax_rates'] ) ? $ref['tax_rates'] : array(), (string) $line['tax_rate'] ),
			);
		}

		$out['totals']   = array(
			'net'   => $prepared['totals']['net_c'] / $scale,
			'tax'   => $prepared['totals']['tax_c'] / $scale,
			'gross' => $prepared['totals']['gross_c'] / $scale,
		);
		$out['status']   = $prepared['status'];
		$out['currency'] = $prepared['currency'];

		if ( 'account_only' !== $policy ) {
			$out['notes'][] = __( 'Reckon items are looked up by SKU when the order is sent.', 'sparxsync-accounting-integration-for-reckon-one' );
		}
		$out['notes'][] = __( 'The customer is matched by billing email, or created, when the order is sent.', 'sparxsync-accounting-integration-for-reckon-one' );
		if ( $prepared['adjustments'] > 0 ) {
			$out['notes'][] = __( 'A rounding difference of a cent or less was spread across lines so the invoice matches the order total exactly.', 'sparxsync-accounting-integration-for-reckon-one' );
		}
		return $out;
	}

	/**
	 * Display name of a cached Reckon record, falling back to its ID.
	 *
	 * @param array  $records ID => record (with name) or ID => name.
	 * @param string $id      ID.
	 * @return string
	 */
	private static function name_of( $records, $id ) {
		if ( '' === (string) $id ) {
			return __( 'Not mapped', 'sparxsync-accounting-integration-for-reckon-one' );
		}
		if ( ! isset( $records[ $id ] ) ) {
			return (string) $id;
		}
		$record = $records[ $id ];
		if ( is_array( $record ) ) {
			$code = isset( $record['code'] ) && '' !== $record['code'] ? $record['code'] . ' ' : '';
			return trim( $code . ( isset( $record['name'] ) ? $record['name'] : (string) $id ) );
		}
		return (string) $record;
	}

	/**
	 * Render the preview inside the order's Reckon One box (collapsed by default).
	 *
	 * @param WC_Order $order Order.
	 */
	public static function render( $order ) {
		$book    = Reckon_WC_Settings::get( Reckon_WC_Settings::OPTION_BOOK );
		$preview = self::build(
			$order,
			Reckon_WC_Settings::get( Reckon_WC_Settings::OPTION_MAPPINGS ),
			$book,
			'' !== $book['book_id'] ? Reckon_WC_Reference_Data::get_book_data( $book['book_id'] ) : null
		);
		$money   = function ( $amount ) use ( $preview, $order ) {
			return wp_strip_all_tags( wc_price( $amount, array( 'currency' => '' !== $preview['currency'] ? $preview['currency'] : $order->get_currency() ) ) );
		};
		$kinds   = array(
			'product'  => __( 'Product', 'sparxsync-accounting-integration-for-reckon-one' ),
			'shipping' => __( 'Shipping', 'sparxsync-accounting-integration-for-reckon-one' ),
			'fee'      => __( 'Fee', 'sparxsync-accounting-integration-for-reckon-one' ),
		);

		echo '<details class="reckon-wc-preview" style="margin:12px 0;border:1px solid #dcdcde;border-radius:6px;padding:8px 10px;background:#fbfbfc;">';
		echo '<summary style="cursor:pointer;font-weight:600;">' . esc_html__( 'Preview the Reckon invoice', 'sparxsync-accounting-integration-for-reckon-one' ) . '</summary>';

		if ( '' !== $preview['error'] ) {
			echo '<p style="margin:8px 0;color:#b32d2e;"><span class="dashicons dashicons-warning" aria-hidden="true"></span> <strong>' . esc_html__( 'This order cannot be sent yet:', 'sparxsync-accounting-integration-for-reckon-one' ) . '</strong> ' . esc_html( $preview['error'] ) . '</p>';
		}
		if ( ! empty( $preview['lines'] ) ) {
			echo '<ul style="margin:8px 0;">';
			foreach ( $preview['lines'] as $line ) {
				echo '<li style="margin:0 0 8px;padding-bottom:8px;border-bottom:1px solid #f0f0f1;">';
				echo '<div style="display:flex;justify-content:space-between;gap:8px;"><strong style="word-break:break-word;">' . esc_html( $line['name'] ) . ( 'product' === $line['kind'] ? ' × ' . esc_html( wc_format_decimal( $line['quantity'], '', true ) ) : '' ) . '</strong><span style="white-space:nowrap;">' . esc_html( $money( $line['amount'] ) ) . '</span></div>';
				echo '<div class="description" style="font-size:12px;color:#646970;">' . esc_html( $kinds[ $line['kind'] ] . ' → ' . $line['destination'] );
				if ( '' !== $line['tax_code'] ) {
					/* translators: 1: Reckon tax code name, 2: tax amount. */
					echo '<br />' . esc_html( sprintf( __( 'Tax code %1$s, tax %2$s', 'sparxsync-accounting-integration-for-reckon-one' ), $line['tax_code'], $money( $line['tax'] ) ) );
				}
				echo '</div></li>';
			}
			echo '</ul>';
			echo '<table style="width:100%;font-size:12px;"><tbody>';
			$amounts = array(
				__( 'Net', 'sparxsync-accounting-integration-for-reckon-one' )   => $preview['totals']['net'],
				__( 'Tax', 'sparxsync-accounting-integration-for-reckon-one' )   => $preview['totals']['tax'],
				__( 'Total', 'sparxsync-accounting-integration-for-reckon-one' ) => $preview['totals']['gross'],
			);
			foreach ( $amounts as $label => $amount ) {
				echo '<tr><td>' . esc_html( $label ) . '</td><td style="text-align:right;font-weight:600;">' . esc_html( $money( $amount ) ) . '</td></tr>';
			}
			echo '</tbody></table>';
			$statuses = array(
				'Inclusive' => __( 'Amounts are tax inclusive.', 'sparxsync-accounting-integration-for-reckon-one' ),
				'Exclusive' => __( 'Amounts are tax exclusive.', 'sparxsync-accounting-integration-for-reckon-one' ),
				'NonTaxed'  => __( 'The book is not registered for tax; no tax codes are sent.', 'sparxsync-accounting-integration-for-reckon-one' ),
			);
			$notes    = $preview['notes'];
			if ( isset( $statuses[ $preview['status'] ] ) ) {
				array_unshift( $notes, $statuses[ $preview['status'] ] );
			}
			echo '<ul class="description" style="margin:8px 0 0;font-size:12px;color:#646970;list-style:disc;padding-left:16px;">';
			foreach ( $notes as $note ) {
				echo '<li>' . esc_html( $note ) . '</li>';
			}
			echo '</ul>';
		}
		echo '<p class="description" style="font-size:12px;">' . esc_html__( 'Preview only. Nothing has been sent to Reckon.', 'sparxsync-accounting-integration-for-reckon-one' ) . '</p>';
		echo '</details>';
	}
}
