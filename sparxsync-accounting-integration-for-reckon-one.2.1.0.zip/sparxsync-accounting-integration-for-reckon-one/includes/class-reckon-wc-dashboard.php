<?php
/**
 * Dashboard tab: setup progress, 30-day invoice figures, queue health and recent invoices.
 *
 * Every figure comes from this site's own order metadata. Nothing is sent anywhere
 * and the Reckon API is never called while the page renders. The 30-day figures
 * are cached for a few minutes and cleared whenever an invoice is linked.
 *
 * @package Reckon_WC
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Reckon_WC_Dashboard {

	const DAYS        = 30;
	const CACHE_TTL   = 600;
	const SCAN_LIMIT  = 1000;
	const RECENT_ROWS = 8;

	/**
	 * Setup steps, in order, with whether each one is done.
	 *
	 * @return array[] Each: label, done, tab.
	 */
	public static function setup_steps() {
		$book     = Reckon_WC_Settings::get( Reckon_WC_Settings::OPTION_BOOK );
		$mappings = Reckon_WC_Settings::get( Reckon_WC_Settings::OPTION_MAPPINGS );
		$sync     = Reckon_WC_Settings::get( Reckon_WC_Settings::OPTION_SYNC );
		$conn     = Reckon_WC_OAuth::get_connection();
		$blocking = false;
		foreach ( Reckon_WC_Settings::validate_configuration() as $check ) {
			$blocking = $blocking || ! empty( $check['blocking'] );
		}

		return array(
			array(
				'label' => __( 'Save your Reckon API credentials', 'sparxsync-accounting-integration-for-reckon-one' ),
				'done'  => Reckon_WC_Settings::credentials_complete(),
				'tab'   => 'connection',
			),
			array(
				'label' => __( 'Connect to Reckon One', 'sparxsync-accounting-integration-for-reckon-one' ),
				'done'  => Reckon_WC_OAuth::has_tokens() && 'connected' === $conn['status'],
				'tab'   => 'connection',
			),
			array(
				'label' => __( 'Choose your Reckon book', 'sparxsync-accounting-integration-for-reckon-one' ),
				'done'  => '' !== $book['book_id'],
				'tab'   => 'book',
			),
			array(
				'label' => __( 'Map accounts and tax codes', 'sparxsync-accounting-integration-for-reckon-one' ),
				'done'  => '' !== $book['book_id'] && $mappings['book_id'] === $book['book_id'],
				'tab'   => 'book',
			),
			array(
				'label' => __( 'Turn on automatic synchronization', 'sparxsync-accounting-integration-for-reckon-one' ),
				'done'  => $sync['enabled'] && ! $blocking,
				'tab'   => 'sync',
			),
		);
	}

	/**
	 * 30-day figures, cached.
	 *
	 * @return array
	 */
	public static function stats() {
		$cached = get_transient( Reckon_WC_Sync::STATS_CACHE );
		if ( is_array( $cached ) && isset( $cached['series'] ) ) {
			return $cached;
		}
		$now    = time();
		$orders = Reckon_WC_Sync::find_invoiced_since( $now - self::DAYS * DAY_IN_SECONDS, self::SCAN_LIMIT );
		$stats  = self::aggregate( is_array( $orders ) ? $orders : array(), $now );

		$stats['all_time']  = Reckon_WC_Sync::count_invoiced();
		$stats['truncated'] = is_array( $orders ) && count( $orders ) >= self::SCAN_LIMIT;
		set_transient( Reckon_WC_Sync::STATS_CACHE, $stats, self::CACHE_TTL );
		return $stats;
	}

	/**
	 * Group invoiced orders into daily counts and totals.
	 *
	 * Orders are re-checked against the window here, so the result is correct even if
	 * the storage layer ignored the meta query.
	 *
	 * @param WC_Order[] $orders Orders.
	 * @param int        $now    Current Unix timestamp.
	 * @return array count, total, series (Y-m-d => count, total), recent rows.
	 */
	public static function aggregate( $orders, $now ) {
		$since  = $now - self::DAYS * DAY_IN_SECONDS;
		$series = array();
		for ( $i = self::DAYS - 1; $i >= 0; $i-- ) {
			$series[ wp_date( 'Y-m-d', $now - $i * DAY_IN_SECONDS ) ] = array(
				'count' => 0,
				'total' => 0.0,
			);
		}

		$count  = 0;
		$total  = 0.0;
		$paid   = 0;
		$recent = array();
		foreach ( $orders as $order ) {
			$at = (int) $order->get_meta( Reckon_WC_Order_State::SYNCED_AT, true );
			if ( $at < $since || $at > $now ) {
				continue;
			}
			$value   = (float) $order->get_total();
			$paid_at = (int) $order->get_meta( Reckon_WC_Order_State::PAID_AT, true );
			$paid   += $paid_at > 0 ? 1 : 0;
			++$count;
			$total += $value;
			$day    = wp_date( 'Y-m-d', $at );
			if ( isset( $series[ $day ] ) ) {
				++$series[ $day ]['count'];
				$series[ $day ]['total'] += $value;
			}
			$company  = trim( (string) $order->get_billing_company() );
			$recent[] = array(
				'id'         => (int) $order->get_id(),
				'number'     => (string) $order->get_order_number(),
				'customer'   => '' !== $company ? $company : trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() ),
				'total'      => $value,
				'currency'   => (string) $order->get_currency(),
				'invoice_id' => (string) $order->get_meta( Reckon_WC_Order_State::INVOICE_ID, true ),
				'state'      => (string) $order->get_meta( Reckon_WC_Order_State::STATE, true ),
				'synced_at'  => $at,
				'paid'       => $paid_at > 0,
			);
		}
		usort(
			$recent,
			function ( $a, $b ) {
				return $b['synced_at'] - $a['synced_at'];
			}
		);

		return array(
			'count'  => $count,
			'total'  => $total,
			'paid'   => $paid,
			'series' => $series,
			'recent' => array_slice( $recent, 0, self::RECENT_ROWS ),
		);
	}

	/**
	 * Render the dashboard tab.
	 */
	public static function render() {
		$steps     = self::setup_steps();
		$done      = count( array_filter( wp_list_pluck( $steps, 'done' ) ) );
		$stats     = self::stats();
		$book      = Reckon_WC_Settings::get( Reckon_WC_Settings::OPTION_BOOK );
		$currency  = '' !== $book['currency'] ? $book['currency'] : get_woocommerce_currency();
		$queued    = Reckon_WC_Sync::count_state( Reckon_WC_Order_State::QUEUED ) + Reckon_WC_Sync::count_state( Reckon_WC_Order_State::IN_PROGRESS ) + Reckon_WC_Sync::count_state( Reckon_WC_Order_State::VERIFY_PENDING );
		$attention = Reckon_WC_Sync::count_state( Reckon_WC_Order_State::FAILED ) + Reckon_WC_Sync::count_state( Reckon_WC_Order_State::NEEDS_REVIEW );

		echo '<div class="sxs-grid">';
		echo '<div class="sxs-main">';

		if ( $done < count( $steps ) ) {
			self::render_setup( $steps, $done );
		}

		echo '<div class="sxs-kpis">';
		$sent_hint = __( 'Last 30 days', 'sparxsync-accounting-integration-for-reckon-one' );
		if ( Reckon_WC_Payment_Status::enabled() && $stats['count'] > 0 ) {
			/* translators: %s: number of paid invoices. */
			$sent_hint = sprintf( __( 'Last 30 days · %s paid in Reckon', 'sparxsync-accounting-integration-for-reckon-one' ), number_format_i18n( isset( $stats['paid'] ) ? $stats['paid'] : 0 ) );
		}
		self::kpi( __( 'Invoices sent', 'sparxsync-accounting-integration-for-reckon-one' ), number_format_i18n( $stats['count'] ), $sent_hint, 'media-text' );
		self::kpi( __( 'Sales sent to Reckon', 'sparxsync-accounting-integration-for-reckon-one' ), wp_strip_all_tags( wc_price( $stats['total'], array( 'currency' => $currency ) ) ), __( 'Last 30 days, incl. tax', 'sparxsync-accounting-integration-for-reckon-one' ), 'chart-line' );
		self::kpi( __( 'In the queue', 'sparxsync-accounting-integration-for-reckon-one' ), number_format_i18n( $queued ), __( 'Queued, in progress or verifying', 'sparxsync-accounting-integration-for-reckon-one' ), 'clock' );
		self::kpi( __( 'Need attention', 'sparxsync-accounting-integration-for-reckon-one' ), number_format_i18n( $attention ), __( 'Failed or needs review', 'sparxsync-accounting-integration-for-reckon-one' ), 'warning', $attention > 0 ? 'is-alert' : '' );
		echo '</div>';

		self::render_chart( $stats );
		self::render_recent( $stats['recent'] );

		echo '</div><aside class="sxs-side">';
		self::render_status( $book, $stats );
		Reckon_WC_Admin::render_help_box();
		echo '</aside></div>';
	}

	/**
	 * Setup checklist.
	 *
	 * @param array $steps Steps.
	 * @param int   $done  Completed steps.
	 */
	private static function render_setup( $steps, $done ) {
		$percent = (int) round( 100 * $done / max( 1, count( $steps ) ) );
		echo '<section class="sxs-card sxs-setup">';
		echo '<div class="sxs-card-head"><h2>' . esc_html__( 'Finish setting up', 'sparxsync-accounting-integration-for-reckon-one' ) . '</h2>';
		/* translators: 1: completed steps, 2: total steps. */
		echo '<span class="sxs-muted">' . esc_html( sprintf( __( '%1$d of %2$d done', 'sparxsync-accounting-integration-for-reckon-one' ), $done, count( $steps ) ) ) . '</span></div>';
		echo '<div class="sxs-progress" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="' . esc_attr( $percent ) . '"><span style="width:' . esc_attr( $percent ) . '%"></span></div>';
		echo '<ol class="sxs-steps">';
		$next_found = false;
		foreach ( $steps as $step ) {
			$is_next    = ! $step['done'] && ! $next_found;
			$next_found = $next_found || $is_next;
			echo '<li class="' . esc_attr( $step['done'] ? 'is-done' : ( $is_next ? 'is-next' : '' ) ) . '">';
			echo '<span class="sxs-step-icon dashicons dashicons-' . esc_attr( $step['done'] ? 'yes' : 'marker' ) . '" aria-hidden="true"></span>';
			echo '<span class="sxs-step-label">' . esc_html( $step['label'] ) . '</span>';
			if ( $is_next ) {
				echo '<a class="button button-primary button-small" href="' . esc_url( Reckon_WC_Settings::page_url( $step['tab'] ) ) . '">' . esc_html__( 'Do this now', 'sparxsync-accounting-integration-for-reckon-one' ) . '</a>';
			} elseif ( $step['done'] ) {
				echo '<span class="screen-reader-text">' . esc_html__( '(done)', 'sparxsync-accounting-integration-for-reckon-one' ) . '</span>';
			}
			echo '</li>';
		}
		echo '</ol></section>';
	}

	/**
	 * One KPI card.
	 *
	 * @param string $label Label.
	 * @param string $value Display value (plain text).
	 * @param string $hint  Small caption.
	 * @param string $icon  Dashicon name.
	 * @param string $class Extra class.
	 */
	private static function kpi( $label, $value, $hint, $icon, $class = '' ) {
		echo '<div class="sxs-card sxs-kpi ' . esc_attr( $class ) . '">';
		echo '<span class="sxs-kpi-icon dashicons dashicons-' . esc_attr( $icon ) . '" aria-hidden="true"></span>';
		echo '<span class="sxs-kpi-label">' . esc_html( $label ) . '</span>';
		echo '<strong class="sxs-kpi-value">' . esc_html( $value ) . '</strong>';
		echo '<span class="sxs-kpi-hint">' . esc_html( $hint ) . '</span>';
		echo '</div>';
	}

	/**
	 * Daily invoices bar chart (plain HTML and CSS, no script).
	 *
	 * @param array $stats Stats.
	 */
	private static function render_chart( $stats ) {
		$max = 0;
		foreach ( $stats['series'] as $day ) {
			$max = max( $max, $day['count'] );
		}
		echo '<section class="sxs-card">';
		echo '<div class="sxs-card-head"><h2>' . esc_html__( 'Invoices created per day', 'sparxsync-accounting-integration-for-reckon-one' ) . '</h2>';
		/* translators: %s: number of invoices. */
		echo '<span class="sxs-muted">' . esc_html( sprintf( _n( '%s invoice in the last 30 days', '%s invoices in the last 30 days', $stats['count'], 'sparxsync-accounting-integration-for-reckon-one' ), number_format_i18n( $stats['count'] ) ) ) . '</span></div>';

		if ( 0 === $max ) {
			echo '<p class="sxs-empty">' . esc_html__( 'No invoices in the last 30 days yet. Once orders are synchronized, daily totals appear here.', 'sparxsync-accounting-integration-for-reckon-one' ) . '</p></section>';
			return;
		}

		/* translators: %s: number of invoices on the busiest day. */
		echo '<div class="sxs-chart" role="img" aria-label="' . esc_attr( sprintf( __( 'Bar chart of invoices per day for the last 30 days. Busiest day: %s invoices.', 'sparxsync-accounting-integration-for-reckon-one' ), number_format_i18n( $max ) ) ) . '">';
		echo '<span class="sxs-chart-max">' . esc_html( number_format_i18n( $max ) ) . '</span>';
		$i = 0;
		foreach ( $stats['series'] as $date => $day ) {
			$height = $day['count'] > 0 ? max( 4, (int) round( 100 * $day['count'] / $max ) ) : 0;
			$label  = wp_date( get_option( 'date_format' ), strtotime( $date . ' 12:00:00' ) );
			/* translators: 1: date, 2: number of invoices. */
			$title = sprintf( __( '%1$s: %2$s invoices', 'sparxsync-accounting-integration-for-reckon-one' ), $label, number_format_i18n( $day['count'] ) );
			echo '<div class="sxs-bar" title="' . esc_attr( $title ) . '"><span style="height:' . esc_attr( $height ) . '%"></span>';
			// A label every 7 days, plus today at the right edge (skipping a weekly label that would collide with it).
			$last = self::DAYS - 1 === $i;
			if ( $last || ( 0 === $i % 7 && $i < self::DAYS - 4 ) ) {
				echo '<em' . ( $last ? ' class="is-last"' : '' ) . '>' . esc_html( wp_date( 'j M', strtotime( $date . ' 12:00:00' ) ) ) . '</em>';
			}
			echo '</div>';
			++$i;
		}
		echo '</div></section>';
	}

	/**
	 * Recently invoiced orders.
	 *
	 * @param array $rows Rows from aggregate().
	 */
	private static function render_recent( $rows ) {
		$labels = Reckon_WC_Order_State::labels();
		echo '<section class="sxs-card">';
		echo '<div class="sxs-card-head"><h2>' . esc_html__( 'Recent invoices', 'sparxsync-accounting-integration-for-reckon-one' ) . '</h2>';
		echo '<a href="' . esc_url( Reckon_WC_Settings::page_url( 'orders' ) ) . '">' . esc_html__( 'View all orders', 'sparxsync-accounting-integration-for-reckon-one' ) . '</a></div>';
		if ( empty( $rows ) ) {
			echo '<p class="sxs-empty">' . esc_html__( 'No invoices yet.', 'sparxsync-accounting-integration-for-reckon-one' ) . '</p></section>';
			return;
		}
		echo '<div class="sxs-table-wrap"><table class="sxs-table"><thead><tr>';
		foreach ( array( __( 'Order', 'sparxsync-accounting-integration-for-reckon-one' ), __( 'Customer', 'sparxsync-accounting-integration-for-reckon-one' ), __( 'Total', 'sparxsync-accounting-integration-for-reckon-one' ), __( 'Status', 'sparxsync-accounting-integration-for-reckon-one' ), __( 'Sent', 'sparxsync-accounting-integration-for-reckon-one' ) ) as $heading ) {
			echo '<th scope="col">' . esc_html( $heading ) . '</th>';
		}
		echo '</tr></thead><tbody>';
		foreach ( $rows as $row ) {
			$order = wc_get_order( $row['id'] );
			$url   = $order ? $order->get_edit_order_url() : '';
			$state = isset( $labels[ $row['state'] ] ) ? $labels[ $row['state'] ] : $row['state'];
			$tone  = Reckon_WC_Order_State::SYNCED === $row['state'] ? 'ok' : ( Reckon_WC_Order_State::VERIFY_PENDING === $row['state'] ? 'wait' : 'info' );
			if ( ! empty( $row['paid'] ) ) {
				$state = __( 'Paid in Reckon', 'sparxsync-accounting-integration-for-reckon-one' );
				$tone  = 'paid';
			}
			echo '<tr>';
			echo '<td>' . ( '' !== $url ? '<a href="' . esc_url( $url ) . '">#' . esc_html( $row['number'] ) . '</a>' : '#' . esc_html( $row['number'] ) ) . '</td>';
			echo '<td>' . esc_html( '' !== $row['customer'] ? $row['customer'] : '—' ) . '</td>';
			echo '<td>' . esc_html( wp_strip_all_tags( wc_price( $row['total'], array( 'currency' => $row['currency'] ) ) ) ) . '</td>';
			echo '<td><span class="sxs-badge is-' . esc_attr( $tone ) . '">' . esc_html( $state ) . '</span></td>';
			/* translators: %s: human-readable time difference, e.g. "5 mins". */
			echo '<td>' . esc_html( sprintf( __( '%s ago', 'sparxsync-accounting-integration-for-reckon-one' ), human_time_diff( $row['synced_at'] ) ) ) . '</td>';
			echo '</tr>';
		}
		echo '</tbody></table></div></section>';
	}

	/**
	 * Connection and book summary.
	 *
	 * @param array $book  Book settings.
	 * @param array $stats Stats.
	 */
	private static function render_status( $book, $stats ) {
		$conn = Reckon_WC_OAuth::get_connection();
		$sync = Reckon_WC_Settings::get( Reckon_WC_Settings::OPTION_SYNC );
		if ( 'connected' === $conn['status'] && Reckon_WC_OAuth::has_tokens() ) {
			$status = array( 'ok', __( 'Connected', 'sparxsync-accounting-integration-for-reckon-one' ) );
		} elseif ( 'reconnect_required' === $conn['status'] ) {
			$status = array( 'error', __( 'Reconnect needed', 'sparxsync-accounting-integration-for-reckon-one' ) );
		} else {
			$status = array( 'info', __( 'Not connected', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}

		echo '<section class="sxs-card">';
		echo '<h2>' . esc_html__( 'Status', 'sparxsync-accounting-integration-for-reckon-one' ) . '</h2>';
		echo '<dl class="sxs-facts">';
		echo '<dt>' . esc_html__( 'Reckon One', 'sparxsync-accounting-integration-for-reckon-one' ) . '</dt><dd><span class="sxs-badge is-' . esc_attr( $status[0] ) . '">' . esc_html( $status[1] ) . '</span></dd>';
		echo '<dt>' . esc_html__( 'Automatic sync', 'sparxsync-accounting-integration-for-reckon-one' ) . '</dt><dd><span class="sxs-badge is-' . esc_attr( $sync['enabled'] ? 'ok' : 'info' ) . '">' . esc_html( $sync['enabled'] ? __( 'On', 'sparxsync-accounting-integration-for-reckon-one' ) : __( 'Off', 'sparxsync-accounting-integration-for-reckon-one' ) ) . '</span></dd>';
		echo '<dt>' . esc_html__( 'Book', 'sparxsync-accounting-integration-for-reckon-one' ) . '</dt><dd>' . esc_html( '' !== $book['book_name'] ? $book['book_name'] : ( '' !== $book['book_id'] ? $book['book_id'] : '—' ) ) . '</dd>';
		echo '<dt>' . esc_html__( 'Last API call', 'sparxsync-accounting-integration-for-reckon-one' ) . '</dt><dd>' . esc_html( Reckon_WC_Admin::format_time( $conn['last_verified_at'] ) ) . '</dd>';
		echo '<dt>' . esc_html__( 'Invoices, all time', 'sparxsync-accounting-integration-for-reckon-one' ) . '</dt><dd>' . esc_html( number_format_i18n( $stats['all_time'] ) ) . '</dd>';
		echo '</dl>';
		if ( ! empty( $stats['truncated'] ) ) {
			/* translators: %s: number of orders. */
			echo '<p class="sxs-muted">' . esc_html( sprintf( __( '30-day figures are based on the latest %s invoiced orders.', 'sparxsync-accounting-integration-for-reckon-one' ), number_format_i18n( self::SCAN_LIMIT ) ) ) . '</p>';
		}
		echo '</section>';
	}
}
