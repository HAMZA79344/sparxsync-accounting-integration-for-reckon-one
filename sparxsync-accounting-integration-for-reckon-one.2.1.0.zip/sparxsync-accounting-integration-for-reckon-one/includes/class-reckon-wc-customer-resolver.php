<?php
/**
 * Finds or creates the Reckon customer for an order.
 *
 * Matching policy (the API documents filtering by name, not by email):
 * 1. The order must have a valid billing email; there is no matching on blank emails.
 * 2. Customer name = billing company, or billing first + last name when there is no company.
 * 3. Registered WooCommerce customers: a Reckon customer ID remembered for this
 *    user and book is reused after confirming it still exists.
 * 4. Otherwise Reckon customers with exactly that name are fetched and one is
 *    accepted only if it has an electronic address equal to the billing email
 *    (case-insensitive). The alternate name "Name (email)" is also checked, because
 *    that is the name used when a different customer already has the plain name.
 * 5. Exactly one match is used. Several matches, or a matching inactive customer,
 *    stop synchronization for an administrator to resolve.
 * 6. A customer is created only after every lookup succeeded and found nothing.
 *    A failed lookup never leads to creation.
 * Guest orders follow the same rules without step 3.
 *
 * @package Reckon_WC
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Reckon_WC_Customer_Resolver {

	const USER_META_PREFIX = '_reckon_wc_customer_';
	const MAX_CANDIDATES   = 10;
	const LOCK_PREFIX      = 'customer_';
	const LOCK_TTL         = 600;
	const SHARED_PREFIX    = '_reckon_wc_cust_attempt_';

	/**
	 * Resolve the Reckon customer ID for an order.
	 *
	 * @param WC_Order $order    Order.
	 * @param string   $book_id  Book ID.
	 * @param array    $mappings Mappings (billing address type).
	 * @return string|WP_Error
	 */
	public static function resolve( $order, $book_id, $mappings ) {
		$email = strtolower( trim( (string) $order->get_billing_email() ) );
		if ( '' === $email || ! is_email( $email ) ) {
			return self::fail( 'customer_email_missing', __( 'The order has no valid billing email address. Customers are only matched or created in Reckon by name and email.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}
		$name = self::display_name( $order );
		if ( '' === $name ) {
			return self::fail( 'customer_name_missing', __( 'The order has no billing company or billing name to use as the Reckon customer name.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}

		// Serialize customer resolution per destination book and customer identity.
		// Two orders for the same new customer must not both create a customer.
		// The lock name is a hash, so no email address appears in the options table.
		$lock_name = self::customer_lock_name( $book_id, $email );
		$lock      = Reckon_WC_Lock::acquire( $lock_name, self::LOCK_TTL );
		if ( false === $lock ) {
			return new WP_Error(
				'reckon_wc_customer_locked',
				__( 'Another order for this customer is being processed in Reckon. This order will be retried shortly.', 'sparxsync-accounting-integration-for-reckon-one' ),
				array(
					'retryable'   => true,
					'retry_after' => 30,
					'outcome'     => 'not_sent',
				)
			);
		}

		try {
			return self::resolve_locked( $order, $book_id, $mappings, $email, $name, $lock_name, $lock );
		} finally {
			Reckon_WC_Lock::release( $lock_name, $lock );
		}
	}

	/**
	 * Resolve while holding the customer lock.
	 *
	 * @param WC_Order $order     Order.
	 * @param string   $book_id   Book ID.
	 * @param array    $mappings  Mappings.
	 * @param string   $email     Normalized email.
	 * @param string   $name      Display name.
	 * @param string   $lock_name Customer lock name.
	 * @param string   $lock      Customer lock token.
	 * @return string|WP_Error
	 */
	private static function resolve_locked( $order, $book_id, $mappings, $email, $name, $lock_name, $lock ) {
		$user_id = (int) $order->get_customer_id();

		// A deliberate, validated manual mapping wins before anything else, so a
		// still-unresolved shared attempt can never block an order that was already
		// recovered by an administrator. It is honoured only while the billing
		// identity still matches the identity that was mapped.
		$manual = $order->get_meta( Reckon_WC_Order_State::CUSTOMER_MAPPING, true );
		if ( is_array( $manual ) && ! empty( $manual['customer_id'] ) && strtolower( (string) $manual['book_id'] ) === strtolower( (string) $book_id ) ) {
			$mapped_email = isset( $manual['email'] ) ? strtolower( (string) $manual['email'] ) : '';
			$mapped_name  = isset( $manual['name'] ) ? (string) $manual['name'] : '';
			$stale        = ( '' !== $mapped_email && $mapped_email !== $email ) || ( '' !== $mapped_name && $mapped_name !== $name );
			if ( ! $stale ) {
				$customer = Reckon_WC_API::get_customer( $book_id, $manual['customer_id'] );
				if ( is_wp_error( $customer ) ) {
					return $customer;
				}
				if ( self::is_inactive( $customer ) ) {
					return self::fail( 'customer_inactive', __( 'The manually selected Reckon customer is inactive. Reactivate it in Reckon, then retry.', 'sparxsync-accounting-integration-for-reckon-one' ) );
				}
				return strtolower( $manual['customer_id'] );
			}
			// The order's billing identity changed since the mapping: do not reuse it.
			$order->delete_meta_data( Reckon_WC_Order_State::CUSTOMER_MAPPING );
			$order->save();
		}

		// Honour a shared unresolved customer-create attempt. Reconcile the original
		// identity first, then resolve the current order's identity separately.
		$shared = self::get_shared_attempt( $book_id, $email );
		if ( null !== $shared && 'unresolved' === ( isset( $shared['status'] ) ? $shared['status'] : 'unresolved' ) ) {
			$outcome = self::reconcile_shared( $book_id, $shared );
			if ( is_wp_error( $outcome ) ) {
				return $outcome;
			}
			if ( 'not_found' === $outcome ) {
				// Save the blocking attempt on this order so a later confirmation can
				// guard against a newer attempt appearing in the meantime.
				$order->update_meta_data( Reckon_WC_Order_State::CUSTOMER_ATTEMPT, $shared );
				$order->save();
				// Keep the shared attempt so every order for this identity stays blocked.
				return self::review_fail(
					'customer_create_unknown',
					__( 'The outcome of an earlier Reckon customer request is unknown, and no matching customer could be found. Check Reckon for the customer. If one exists, link it with "Link a Reckon customer"; if none exists, use "confirm no customer exists and retry".', 'sparxsync-accounting-integration-for-reckon-one' )
				);
			}

			$resolved_id = $outcome;
			self::clear_shared_attempt( $book_id, $email );
			$order->delete_meta_data( Reckon_WC_Order_State::CUSTOMER_ATTEMPT );

			if ( self::customer_matches( $book_id, $resolved_id, $email, $name ) ) {
				self::remember( $user_id, $book_id, $resolved_id, 'auto' );
				$order->save();
				return $resolved_id;
			}
			$order->save();
		}

		// Reconcile this order's own uncertain attempt if the shared record is gone.
		$attempt = $order->get_meta( Reckon_WC_Order_State::CUSTOMER_ATTEMPT, true );
		if ( is_array( $attempt ) && isset( $attempt['book_id'] ) && strtolower( (string) $attempt['book_id'] ) === strtolower( (string) $book_id ) ) {
			$outcome = self::reconcile_shared( $book_id, $attempt );
			if ( is_wp_error( $outcome ) ) {
				return $outcome;
			}
			if ( 'not_found' === $outcome ) {
				return self::review_fail(
					'customer_create_unknown',
					__( 'The outcome of an earlier Reckon customer request is unknown, and no matching customer could be found. Check Reckon for the customer, then link it or confirm none exists.', 'sparxsync-accounting-integration-for-reckon-one' )
				);
			}
			$resolved_id = $outcome;
			$order->delete_meta_data( Reckon_WC_Order_State::CUSTOMER_ATTEMPT );
			if ( self::customer_matches( $book_id, $resolved_id, $email, $name ) ) {
				self::remember( $user_id, $book_id, $resolved_id, 'auto' );
				$order->save();
				return $resolved_id;
			}
			$order->save();
		}

		if ( $user_id > 0 ) {
			$remembered = self::remembered_customer( $user_id, $book_id );
			if ( '' !== $remembered ) {
				$customer = Reckon_WC_API::get_customer( $book_id, $remembered );
				if ( is_wp_error( $customer ) ) {
					if ( 'reckon_wc_not_found' !== $customer->get_error_code() ) {
						return $customer; // Lookup failed: do not create.
					}
					self::forget( $user_id, $book_id );
				} elseif ( self::is_inactive( $customer ) ) {
					return self::fail( 'customer_inactive', __( 'The Reckon customer linked to this WooCommerce customer is inactive. Reactivate it in Reckon, then retry.', 'sparxsync-accounting-integration-for-reckon-one' ) );
				} elseif ( self::identity_matches( $customer, $email, $name ) ) {
					return $remembered;
				}
			}
		}

		$alternate  = self::alternate_name( $name, $email );
		$primary    = self::search( $book_id, $name, $email );
		if ( is_wp_error( $primary ) ) {
			return $primary;
		}
		$matches      = $primary['matches'];
		$name_taken   = $primary['count'] > 0;
		$alt_searched = false;
		if ( empty( $matches ) && $alternate !== $name ) {
			$secondary = self::search( $book_id, $alternate, $email );
			if ( is_wp_error( $secondary ) ) {
				return $secondary;
			}
			$matches      = $secondary['matches'];
			$alt_searched = true;
			if ( empty( $matches ) && $secondary['count'] > 0 ) {
				return self::fail( 'customer_name_conflict', __( 'Reckon customers with this name exist but none has the billing email address. Add the email to the correct Reckon customer, then retry.', 'sparxsync-accounting-integration-for-reckon-one' ) );
			}
		}

		if ( count( $matches ) > 1 ) {
			return self::fail( 'customer_ambiguous', __( 'More than one Reckon customer has this name and billing email. Merge or deactivate the duplicates in Reckon, then retry.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}
		if ( 1 === count( $matches ) ) {
			if ( self::is_inactive( $matches[0] ) ) {
				return self::fail( 'customer_inactive', __( 'The matching Reckon customer is inactive. Reactivate it in Reckon, then retry.', 'sparxsync-accounting-integration-for-reckon-one' ) );
			}
			$id = strtolower( $matches[0]['id'] );
			self::remember( $user_id, $book_id, $id, 'auto' );
			return $id;
		}

		// All lookups succeeded and found nothing: create under the customer lock.
		$create_name = ( $name_taken && $alt_searched ) ? $alternate : $name;
		$email_type  = Reckon_WC_Reference_Data::email_type_id( $book_id );
		if ( null === $email_type ) {
			return self::fail( 'email_type_missing', __( 'The Reckon book has no "Email" electronic address type, so a customer cannot be created with an email address. Refresh Reckon data after adding it.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}
		$body = array(
			'name'                => $create_name,
			'electronicAddresses' => array(
				array(
					'type'    => $email_type,
					'address' => $email,
				),
			),
			'entityTypes'         => array( 'isCustomer' => true ),
		);
		$company = self::clip( $order->get_billing_company(), 100 );
		if ( '' !== $company ) {
			$body['organisationName'] = $company;
		}
		if ( ! empty( $mappings['billing_address_type'] ) ) {
			$body['addresses'] = array(
				array(
					'type'     => $mappings['billing_address_type'],
					'line1'    => self::clip( $order->get_billing_address_1(), 80 ),
					'line2'    => self::clip( $order->get_billing_address_2(), 80 ),
					'suburb'   => self::clip( $order->get_billing_city(), 80 ),
					'state'    => self::clip( $order->get_billing_state(), 80 ),
					'postcode' => self::clip( $order->get_billing_postcode(), 30 ),
					'country'  => self::clip( $order->get_billing_country(), 30 ),
				),
			);
		}

		// Record the attempt before sending, so every order for this identity sees it.
		$attempt = array(
			'book_id'    => $book_id,
			'name'       => $create_name,
			'email'      => $email,
			'order_id'   => $order->get_id(),
			'attempt_id' => self::attempt_id(),
			'started_at' => time(),
			'status'     => 'unresolved',
		);
		$order->update_meta_data( Reckon_WC_Order_State::CUSTOMER_ATTEMPT, $attempt );
		$order->save();
		self::set_shared_attempt( $book_id, $email, $attempt );
		if ( null === self::get_shared_attempt( $book_id, $email ) ) {
			return self::fail( 'customer_marker_not_saved', __( 'The customer create attempt could not be recorded, so no customer was created. Retry.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}

		// Re-confirm ownership before the POST after potentially lengthy lookups.
		if ( ! Reckon_WC_Lock::refresh( $lock_name, $lock, self::LOCK_TTL ) ) {
			return new WP_Error(
				'reckon_wc_customer_lock_lost',
				__( 'The customer lock was lost before sending, so no customer was created.', 'sparxsync-accounting-integration-for-reckon-one' ),
				array(
					'retryable' => true,
					'outcome'   => 'not_sent',
				)
			);
		}

		$id = Reckon_WC_API::create_customer( $book_id, $body );
		if ( is_wp_error( $id ) ) {
			$outcome = Reckon_WC_API::error_data( $id, 'outcome', 'unknown' );
			if ( 'unknown' !== $outcome ) {
				// Not sent, or rejected: nothing was created, so both markers are cleared.
				$order->delete_meta_data( Reckon_WC_Order_State::CUSTOMER_ATTEMPT );
				$order->save();
				self::clear_shared_attempt( $book_id, $email );
			}
			return $id;
		}

		self::remember( $user_id, $book_id, $id, 'auto' );
		$order->delete_meta_data( Reckon_WC_Order_State::CUSTOMER_ATTEMPT );
		$order->save();
		self::clear_shared_attempt( $book_id, $email );
		Reckon_WC_Logger::info( 'Created Reckon customer ' . $id . '.', array( 'operation' => 'customer_create', 'order_id' => $order->get_id() ) );
		return $id;
	}

	/**
	 * Reconcile an uncertain create by searching the original identity. Returns a
	 * customer ID, the string "not_found", or a WP_Error.
	 *
	 * @param string $book_id Book ID.
	 * @param array  $attempt Attempt record (shared or per-order).
	 * @return string|WP_Error Customer ID or "not_found".
	 */
	private static function reconcile_shared( $book_id, $attempt ) {
		$search_name  = isset( $attempt['name'] ) && is_string( $attempt['name'] ) && '' !== $attempt['name'] ? $attempt['name'] : '';
		$search_email = isset( $attempt['email'] ) && is_string( $attempt['email'] ) && '' !== $attempt['email'] ? strtolower( $attempt['email'] ) : '';
		if ( '' === $search_name || '' === $search_email ) {
			return self::fail( 'customer_attempt_invalid', __( 'The earlier customer attempt record is incomplete.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}

		foreach ( array_unique( array( $search_name, self::alternate_name( $search_name, $search_email ) ) ) as $candidate_name ) {
			$found = self::search( $book_id, $candidate_name, $search_email );
			if ( is_wp_error( $found ) ) {
				return $found;
			}
			if ( count( $found['matches'] ) > 1 ) {
				return self::fail( 'customer_ambiguous', __( 'More than one Reckon customer matches after an earlier customer request had an unknown outcome. Merge or deactivate the duplicates in Reckon, then retry.', 'sparxsync-accounting-integration-for-reckon-one' ) );
			}
			if ( 1 === count( $found['matches'] ) ) {
				if ( self::is_inactive( $found['matches'][0] ) ) {
					return self::fail( 'customer_inactive', __( 'The Reckon customer created by an earlier request is inactive. Reactivate it in Reckon, then retry.', 'sparxsync-accounting-integration-for-reckon-one' ) );
				}
				return strtolower( $found['matches'][0]['id'] );
			}
		}
		return 'not_found';
	}

	/**
	 * Whether a resolved customer still matches the current order's billing identity.
	 *
	 * @param string $book_id     Book ID.
	 * @param string $customer_id Customer ID.
	 * @param string $email       Normalized email.
	 * @param string $name        Display name.
	 * @return bool
	 */
	private static function customer_matches( $book_id, $customer_id, $email, $name ) {
		$customer = Reckon_WC_API::get_customer( $book_id, $customer_id );
		if ( is_wp_error( $customer ) ) {
			return false;
		}
		return self::identity_matches( $customer, $email, $name );
	}

	/**
	 * Customer display name.
	 *
	 * @param WC_Order $order Order.
	 * @return string
	 */
	public static function display_name( $order ) {
		$company = trim( (string) $order->get_billing_company() );
		$name    = '' !== $company ? $company : trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() );
		return self::clip( preg_replace( '/\s+/', ' ', $name ), 100 );
	}

	/**
	 * Name used when another customer already has the plain name.
	 *
	 * @param string $name  Name.
	 * @param string $email Email.
	 * @return string
	 */
	public static function alternate_name( $name, $email ) {
		$suffix = ' (' . $email . ')';
		if ( strlen( $suffix ) >= 90 ) {
			return self::clip( $email, 100 );
		}
		return self::clip( $name, 100 - strlen( $suffix ) ) . $suffix;
	}

	/**
	 * Search by exact name and keep candidates carrying the email.
	 *
	 * @param string $book_id Book ID.
	 * @param string $name    Name.
	 * @param string $email   Email (lowercase).
	 * @return array|WP_Error count (name matches) and matches (email matches).
	 */
	private static function search( $book_id, $name, $email ) {
		$candidates = Reckon_WC_API::find_customers_by_name( $book_id, $name );
		if ( is_wp_error( $candidates ) ) {
			return $candidates;
		}
		// The API filter is case-sensitive equality; re-check locally in case it matched loosely.
		$candidates = array_values(
			array_filter(
				$candidates,
				function ( $c ) use ( $name ) {
					return isset( $c['id'], $c['name'] ) && Reckon_WC_API::is_guid( $c['id'] ) && is_string( $c['name'] ) && $c['name'] === $name;
				}
			)
		);
		if ( count( $candidates ) > self::MAX_CANDIDATES ) {
			return self::fail( 'customer_too_many_candidates', __( 'Too many Reckon customers share this name to match safely. Link the correct customer manually or make the names distinct.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}

		$matches = array();
		foreach ( $candidates as $candidate ) {
			if ( ! isset( $candidate['electronicAddresses'] ) || ! is_array( $candidate['electronicAddresses'] ) ) {
				// Lists may omit nested collections; fetch the full record before deciding.
				$candidate = Reckon_WC_API::get_customer( $book_id, $candidate['id'] );
				if ( is_wp_error( $candidate ) ) {
					return $candidate;
				}
			}
			foreach ( (array) ( isset( $candidate['electronicAddresses'] ) ? $candidate['electronicAddresses'] : array() ) as $address ) {
				if ( is_array( $address ) && isset( $address['address'] ) && is_string( $address['address'] ) && strtolower( trim( $address['address'] ) ) === $email ) {
					$matches[] = $candidate;
					break;
				}
			}
		}
		return array(
			'count'   => count( $candidates ),
			'matches' => $matches,
		);
	}

	/**
	 * Remember a customer for a registered user and book.
	 *
	 * The mapping is recorded as an automatic match (never an administrator-approved
	 * account mapping, which is a separate future workflow). The type is retained so
	 * the two can be treated differently: automatic mappings are re-checked against
	 * the order's billing identity before reuse.
	 *
	 * @param int    $user_id     User ID.
	 * @param string $book_id     Book ID.
	 * @param string $customer_id Customer ID.
	 * @param string $type        auto|manual.
	 */
	private static function remember( $user_id, $book_id, $customer_id, $type = 'auto' ) {
		if ( $user_id > 0 ) {
			update_user_meta(
				$user_id,
				self::user_meta_key( $book_id ),
				array(
					'id'   => strtolower( $customer_id ),
					'type' => in_array( $type, array( 'auto', 'manual' ), true ) ? $type : 'auto',
					'at'   => time(),
				)
			);
		}
	}

	/**
	 * Read a remembered customer ID, accepting both the legacy plain-GUID form and
	 * the structured form written by newer versions.
	 *
	 * @param int    $user_id User ID.
	 * @param string $book_id Book ID.
	 * @return string Empty when none is remembered.
	 */
	private static function remembered_customer( $user_id, $book_id ) {
		$value = get_user_meta( $user_id, self::user_meta_key( $book_id ), true );
		if ( ! is_array( $value ) && ! ( is_string( $value ) && Reckon_WC_API::is_guid( $value ) ) && is_multisite() ) {
			// Fall back to a legacy unscoped mapping on multisite, without deleting it.
			$value = get_user_meta( $user_id, self::legacy_user_meta_key( $book_id ), true );
		}
		if ( is_array( $value ) && isset( $value['id'] ) && Reckon_WC_API::is_guid( $value['id'] ) ) {
			return strtolower( (string) $value['id'] );
		}
		if ( is_string( $value ) && Reckon_WC_API::is_guid( $value ) ) {
			return strtolower( $value );
		}
		return '';
	}

	/**
	 * Forget a remembered customer mapping for a user and book.
	 *
	 * @param int    $user_id User ID.
	 * @param string $book_id Book ID.
	 */
	private static function forget( $user_id, $book_id ) {
		delete_user_meta( $user_id, self::user_meta_key( $book_id ) );
	}

	/**
	 * Whether a stored Reckon customer still matches the order's billing identity.
	 *
	 * @param array  $customer Customer record from Reckon.
	 * @param string $email    Normalized billing email.
	 * @param string $name     Order display name (company or first + last name).
	 * @return bool
	 */
	private static function identity_matches( $customer, $email, $name ) {
		$email_match = false;
		foreach ( (array) ( isset( $customer['electronicAddresses'] ) ? $customer['electronicAddresses'] : array() ) as $address ) {
			if ( is_array( $address ) && isset( $address['address'] ) && is_string( $address['address'] ) && strtolower( trim( $address['address'] ) ) === $email ) {
				$email_match = true;
				break;
			}
		}
		if ( ! $email_match ) {
			return false;
		}
		$customer_name = isset( $customer['name'] ) && is_string( $customer['name'] ) ? trim( $customer['name'] ) : '';
		return '' !== $customer_name && ( $customer_name === $name || $customer_name === self::alternate_name( $name, $email ) );
	}

	/**
	 * Customer lock name: a hash of the book and email, so no personal data leaks
	 * into the options table. The lock name is stable for a given book and identity.
	 *
	 * @param string $book_id Book ID.
	 * @param string $email   Normalized email.
	 * @return string
	 */
	public static function customer_lock_name( $book_id, $email ) {
		return self::LOCK_PREFIX . hash( 'sha256', strtolower( (string) $book_id ) . '|' . $email );
	}

	/**
	 * Clear a shared customer-create attempt only if it is still the expected one.
	 * Runs under the customer lock so it cannot clear a newer attempt.
	 *
	 * @param string $book_id    Book ID.
	 * @param string $email      Normalized email.
	 * @param string $attempt_id Expected attempt identifier (empty to match any).
	 * @return true|WP_Error
	 */
	public static function clear_shared_attempt_if_owned( $book_id, $email, $attempt_id ) {
		$lock = Reckon_WC_Lock::acquire( self::customer_lock_name( $book_id, $email ), self::LOCK_TTL );
		if ( false === $lock ) {
			return new WP_Error( 'reckon_wc_customer_locked', __( 'Another order for this customer is being processed. Try again shortly.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}
		try {
			$shared = self::get_shared_attempt( $book_id, $email );
			if ( null === $shared ) {
				return true;
			}
			// Ownership must match exactly: a missing expected id cannot clear a newer
			// attempt that carries an id, and vice versa.
			$shared_id = isset( $shared['attempt_id'] ) ? (string) $shared['attempt_id'] : '';
			if ( $shared_id !== (string) $attempt_id ) {
				return new WP_Error( 'reckon_wc_customer_attempt_mismatch', __( 'A newer customer attempt exists, so the earlier attempt was not cleared.', 'sparxsync-accounting-integration-for-reckon-one' ) );
			}
			self::clear_shared_attempt( $book_id, $email );
			return true;
		} finally {
			Reckon_WC_Lock::release( self::customer_lock_name( $book_id, $email ), $lock );
		}
	}

	/**
	 * Generate an attempt identifier.
	 *
	 * @return string
	 */
	private static function attempt_id() {
		try {
			return bin2hex( random_bytes( 16 ) );
		} catch ( Exception $e ) {
			return uniqid( '', true );
		}
	}

	/**
	 * Shared customer-create attempt option name (site + book + identity scoped).
	 *
	 * @param string $book_id Book ID.
	 * @param string $email   Normalized email.
	 * @return string
	 */
	private static function shared_option( $book_id, $email ) {
		return self::SHARED_PREFIX . hash( 'sha256', strtolower( (string) $book_id ) . '|' . $email );
	}

	/**
	 * Read the shared customer-create attempt, if any.
	 *
	 * @param string $book_id Book ID.
	 * @param string $email   Normalized email.
	 * @return array|null
	 */
	public static function get_shared_attempt( $book_id, $email ) {
		$value = get_option( self::shared_option( $book_id, $email ), null );
		return is_array( $value ) ? $value : null;
	}

	/**
	 * Store the shared customer-create attempt.
	 *
	 * @param string $book_id Book ID.
	 * @param string $email   Normalized email.
	 * @param array  $data    Attempt data.
	 */
	private static function set_shared_attempt( $book_id, $email, $data ) {
		update_option( self::shared_option( $book_id, $email ), $data, false );
	}

	/**
	 * Clear the shared customer-create attempt.
	 *
	 * @param string $book_id Book ID.
	 * @param string $email   Normalized email.
	 */
	public static function clear_shared_attempt( $book_id, $email ) {
		delete_option( self::shared_option( $book_id, $email ) );
	}

	/**
	 * User meta key for a book.
	 *
	 * @param string $book_id Book ID.
	 * @return string
	 */
	public static function user_meta_key( $book_id ) {
		$slug = str_replace( '-', '', strtolower( $book_id ) );
		if ( is_multisite() ) {
			// Scope mappings per site so one site's settings cannot read another's.
			return self::USER_META_PREFIX . 'site_' . get_current_blog_id() . '_' . $slug;
		}
		return self::USER_META_PREFIX . $slug;
	}

	/**
	 * Legacy unscoped user meta key, used only for a read-only migration fallback.
	 *
	 * @param string $book_id Book ID.
	 * @return string
	 */
	private static function legacy_user_meta_key( $book_id ) {
		return self::USER_META_PREFIX . str_replace( '-', '', strtolower( $book_id ) );
	}

	/**
	 * Whether a customer record is inactive.
	 *
	 * @param array $customer Customer.
	 * @return bool
	 */
	private static function is_inactive( $customer ) {
		return isset( $customer['status'] ) && is_string( $customer['status'] ) && 'inactive' === strtolower( $customer['status'] );
	}

	/**
	 * Trim and shorten text.
	 *
	 * @param string $text Text.
	 * @param int    $max  Maximum characters.
	 * @return string
	 */
	private static function clip( $text, $max ) {
		$text = trim( (string) $text );
		return function_exists( 'mb_substr' ) ? mb_substr( $text, 0, $max ) : substr( $text, 0, $max );
	}

	/**
	 * Permanent resolver error.
	 *
	 * @param string $code    Code.
	 * @param string $message Message.
	 * @return WP_Error
	 */
	private static function fail( $code, $message ) {
		return new WP_Error(
			'reckon_wc_' . $code,
			$message,
			array(
				'retryable' => false,
				'outcome'   => 'not_sent',
			)
		);
	}

	/**
	 * Error that must stop the order for administrator review rather than fail it.
	 *
	 * @param string $code    Code suffix.
	 * @param string $message Message.
	 * @return WP_Error
	 */
	private static function review_fail( $code, $message ) {
		return new WP_Error(
			'reckon_wc_' . $code,
			$message,
			array(
				'retryable'    => false,
				'outcome'      => 'unknown',
				'review'       => true,
				'review_reason' => $code,
			)
		);
	}
}
