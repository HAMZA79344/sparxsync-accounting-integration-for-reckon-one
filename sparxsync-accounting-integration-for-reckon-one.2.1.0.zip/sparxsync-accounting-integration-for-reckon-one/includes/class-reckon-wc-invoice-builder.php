<?php
/**
 * Builds a Reckon InvoiceInput payload from a WooCommerce order's saved totals.
 *
 * Amounts come from the order line items as stored at checkout (after discounts),
 * never from current catalogue prices. All arithmetic is done in integer minor
 * units. Before a payload is produced the lines are reconciled with the order:
 * the sum of line net amounts, line taxes and gross amounts must equal the order
 * totals exactly. Rounding differences caused by WooCommerce rounding at subtotal
 * level may be allocated across lines, at most one minor unit per line; larger
 * differences stop synchronization with an error.
 *
 * Each line carries an explicit taxAmount equal to the WooCommerce line tax, and
 * one Reckon tax code. Lines with more than one non-zero tax rate are refused
 * because a Reckon invoice line accepts a single tax rate.
 *
 * @package Reckon_WC
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Reckon_WC_Invoice_Builder {

	// InvoiceInput.lineItems: "Note that the maximum items is 200."
	const MAX_LINES = 200;

	// Highest unit-price precision tried when quantity does not divide the line amount.
	const MAX_PRICE_DECIMALS = 6;

	/**
	 * Minor units for a currency (ISO 4217).
	 *
	 * @param string $currency Currency code.
	 * @return int
	 */
	public static function currency_decimals( $currency ) {
		$zero  = array( 'BIF', 'CLP', 'DJF', 'GNF', 'ISK', 'JPY', 'KMF', 'KRW', 'PYG', 'RWF', 'UGX', 'UYI', 'VND', 'VUV', 'XAF', 'XOF', 'XPF' );
		$three = array( 'BHD', 'IQD', 'JOD', 'KWD', 'LYD', 'OMR', 'TND' );
		$currency = strtoupper( (string) $currency );
		$decimals = in_array( $currency, $zero, true ) ? 0 : ( in_array( $currency, $three, true ) ? 3 : 2 );
		return (int) apply_filters( 'reckon_wc_currency_decimals', $decimals, $currency );
	}

	/**
	 * Error helper. Builder errors are permanent: retrying without changes cannot succeed.
	 *
	 * @param string $code    Code.
	 * @param string $message Message.
	 * @return WP_Error
	 */
	private static function fail( $code, $message ) {
		return new WP_Error(
			'reckon_wc_' . $code,
			$message,
			array(
				'retryable' => false,
				'outcome'   => 'not_sent',
			)
		);
	}

	/**
	 * Read the order's lines, map tax codes and reconcile totals.
	 *
	 * @param WC_Order $order        Order.
	 * @param array    $mappings     Mappings option.
	 * @param array    $book         Book option (currency).
	 * @param array    $tax_settings Cached Reckon tax settings.
	 * @return array|WP_Error Prepared data: lines, status, dp, totals, adjustments.
	 */
	public static function prepare( $order, $mappings, $book, $tax_settings ) {
		$currency = strtoupper( (string) $order->get_currency() );
		if ( '' === $book['currency'] ) {
			return self::fail( 'book_currency_unknown', __( "The Reckon book's currency is unknown. Refresh Reckon data.", 'sparxsync-accounting-integration-for-reckon-one' ) );
		}
		if ( $currency !== strtoupper( $book['currency'] ) ) {
			/* translators: 1: order currency, 2: book currency. */
			return self::fail( 'currency_mismatch', sprintf( __( 'The order currency (%1$s) does not match the Reckon book currency (%2$s). Multi-currency invoices are not supported.', 'sparxsync-accounting-integration-for-reckon-one' ), $currency, strtoupper( $book['currency'] ) ) );
		}

		$dp    = self::currency_decimals( $currency );
		$scale = pow( 10, $dp );

		$status = self::amount_tax_status( $order, $tax_settings );

		$raw = array();
		foreach ( $order->get_items( 'line_item' ) as $item_id => $item ) {
			$qty = (float) $item->get_quantity();
			if ( $qty <= 0 ) {
				/* translators: %s: line name. */
				return self::fail( 'invalid_quantity', sprintf( __( 'Line "%s" has a zero or negative quantity.', 'sparxsync-accounting-integration-for-reckon-one' ), $item->get_name() ) );
			}
			$product = $item->get_product();
			$raw[]   = array(
				'kind'           => 'product',
				'item_id'        => (int) $item_id,
				'name'           => (string) $item->get_name(),
				'quantity'       => $qty,
				'net'            => (float) $item->get_total(),
				'tax'            => (float) $item->get_total_tax(),
				'taxes'          => self::tax_breakdown( $item ),
				'sku'            => $product ? trim( (string) $product->get_sku() ) : '',
				'product_exists' => (bool) $product,
			);
		}
		foreach ( array( 'shipping', 'fee' ) as $type ) {
			foreach ( $order->get_items( $type ) as $item_id => $item ) {
				$net = (float) $item->get_total();
				$tax = (float) $item->get_total_tax();
				if ( abs( $net ) < 1e-9 && abs( $tax ) < 1e-9 ) {
					continue;
				}
				$raw[] = array(
					'kind'           => $type,
					'item_id'        => (int) $item_id,
					'name'           => (string) $item->get_name(),
					'quantity'       => 1.0,
					'net'            => $net,
					'tax'            => $tax,
					'taxes'          => self::tax_breakdown( $item ),
					'sku'            => '',
					'product_exists' => false,
				);
			}
		}

		if ( empty( $raw ) ) {
			return self::fail( 'no_lines', __( 'The order has no lines to invoice.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}
		if ( count( $raw ) > self::MAX_LINES ) {
			/* translators: %d: maximum number of lines. */
			return self::fail( 'too_many_lines', sprintf( __( 'The order has more than %d lines, the maximum Reckon accepts on one invoice.', 'sparxsync-accounting-integration-for-reckon-one' ), self::MAX_LINES ) );
		}

		// Tax codes.
		foreach ( $raw as $i => $line ) {
			$code = self::line_tax_code( $order, $line, $mappings, $status );
			if ( is_wp_error( $code ) ) {
				return $code;
			}
			$raw[ $i ]['tax_rate'] = $code;
		}

		// Order totals in minor units; they must already be representable in the currency.
		$order_total = (float) $order->get_total();
		$order_tax   = (float) $order->get_total_tax();
		foreach ( array( $order_total, $order_tax ) as $amount ) {
			if ( abs( $amount * $scale - round( $amount * $scale ) ) > 1e-6 ) {
				/* translators: %s: currency code. */
				return self::fail( 'amount_precision', sprintf( __( 'The order total has more decimal places than %s supports.', 'sparxsync-accounting-integration-for-reckon-one' ), $currency ) );
			}
		}
		$order_total_c = (int) round( $order_total * $scale );
		$order_tax_c   = (int) round( $order_tax * $scale );
		$order_net_c   = $order_total_c - $order_tax_c;

		if ( $order_total_c < 0 ) {
			return self::fail( 'negative_total', __( 'The order total is negative.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}
		if ( 'NonTaxed' === $status && 0 !== $order_tax_c ) {
			return self::fail( 'book_not_tax_registered', __( 'The Reckon book is not registered for tax, but the order includes tax.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}

		$net_c   = array();
		$tax_c   = array();
		$net_res = array();
		$tax_res = array();
		foreach ( $raw as $i => $line ) {
			$net_c[ $i ]   = (int) round( $line['net'] * $scale );
			$tax_c[ $i ]   = (int) round( $line['tax'] * $scale );
			$net_res[ $i ] = $line['net'] * $scale - $net_c[ $i ];
			$tax_res[ $i ] = $line['tax'] * $scale - $tax_c[ $i ];
		}

		$adjustments = 0;
		$tax_diff    = $order_tax_c - array_sum( $tax_c );
		if ( 0 !== $tax_diff ) {
			$eligible = array_keys(
				array_filter(
					$raw,
					function ( $line ) {
						return abs( $line['tax'] ) > 1e-9;
					}
				)
			);
			$tax_c = self::allocate( $tax_c, $tax_res, $eligible, $tax_diff );
			if ( null === $tax_c ) {
				return self::mismatch( 'tax_total_mismatch', __( 'tax', 'sparxsync-accounting-integration-for-reckon-one' ), $order_tax_c, $order_tax_c - $tax_diff, $dp );
			}
			$adjustments += abs( $tax_diff );
		}
		$net_diff = $order_net_c - array_sum( $net_c );
		if ( 0 !== $net_diff ) {
			$eligible = array_keys(
				array_filter(
					$raw,
					function ( $line ) {
						return abs( $line['net'] ) > 1e-9;
					}
				)
			);
			$net_c = self::allocate( $net_c, $net_res, $eligible, $net_diff );
			if ( null === $net_c ) {
				return self::mismatch( 'net_total_mismatch', __( 'net', 'sparxsync-accounting-integration-for-reckon-one' ), $order_net_c, $order_net_c - $net_diff, $dp );
			}
			$adjustments += abs( $net_diff );
		}
		if ( array_sum( $tax_c ) !== $order_tax_c || array_sum( $net_c ) + array_sum( $tax_c ) !== $order_total_c ) {
			return self::mismatch( 'gross_total_mismatch', __( 'gross', 'sparxsync-accounting-integration-for-reckon-one' ), $order_total_c, array_sum( $net_c ) + array_sum( $tax_c ), $dp );
		}

		$lines = array();
		foreach ( $raw as $i => $line ) {
			if ( 'fee' !== $line['kind'] && $net_c[ $i ] < 0 ) {
				/* translators: %s: line name. */
				return self::fail( 'negative_line', sprintf( __( 'Line "%s" has a negative amount. Only fee lines may be negative.', 'sparxsync-accounting-integration-for-reckon-one' ), $line['name'] ) );
			}
			unset( $line['net'], $line['tax'], $line['taxes'] );
			$line['net_c']    = $net_c[ $i ];
			$line['tax_c']    = $tax_c[ $i ];
			$line['amount_c'] = 'Inclusive' === $status ? $net_c[ $i ] + $tax_c[ $i ] : $net_c[ $i ];
			$lines[]          = $line;
		}

		return array(
			'lines'       => $lines,
			'status'      => $status,
			'dp'          => $dp,
			'currency'    => $currency,
			'totals'      => array(
				'net_c'   => $order_net_c,
				'tax_c'   => $order_tax_c,
				'gross_c' => $order_total_c,
			),
			'adjustments' => $adjustments,
		);
	}

	/**
	 * Build the InvoiceInput payload.
	 *
	 * @param array    $prepared    Output of prepare().
	 * @param WC_Order $order       Order.
	 * @param string   $customer_id Reckon customer ID.
	 * @param array    $item_ids    WooCommerce item ID => Reckon item ID for lines posted as items.
	 * @param string   $reference   External reference.
	 * @param array    $mappings    Mappings option.
	 * @return array|WP_Error
	 */
	public static function build_payload( $prepared, $order, $customer_id, $item_ids, $reference, $mappings ) {
		$scale    = pow( 10, $prepared['dp'] );
		$accounts = array(
			'product'  => $mappings['sales_account'],
			'shipping' => $mappings['shipping_account'],
			'fee'      => $mappings['fee_account'],
		);
		$labels   = array(
			'product'  => __( 'sales', 'sparxsync-accounting-integration-for-reckon-one' ),
			'shipping' => __( 'shipping', 'sparxsync-accounting-integration-for-reckon-one' ),
			'fee'      => __( 'fee', 'sparxsync-accounting-integration-for-reckon-one' ),
		);

		$line_items = array();
		$number     = 1;
		foreach ( $prepared['lines'] as $line ) {
			$entry = array(
				'lineNumber'  => $number++,
				'description' => self::description( $line['name'] ),
			);
			if ( 'NonTaxed' !== $prepared['status'] ) {
				$entry['taxRate']   = $line['tax_rate'];
				$entry['taxAmount'] = $line['tax_c'] / $scale;
			}

			$item_id = 'product' === $line['kind'] && isset( $item_ids[ $line['item_id'] ] ) ? $item_ids[ $line['item_id'] ] : '';
			if ( '' !== $item_id ) {
				$price = self::unit_price( $line['amount_c'], $line['quantity'], $prepared['dp'] );
				if ( is_wp_error( $price ) ) {
					return $price;
				}
				$entry['itemDetails'] = array(
					'item'     => $item_id,
					'price'    => $price,
					'quantity' => self::number( $line['quantity'] ),
				);
			} else {
				$account = $accounts[ $line['kind'] ];
				if ( '' === $account ) {
					/* translators: %s: account purpose (sales, shipping or fee). */
					return self::fail( 'account_not_mapped', sprintf( __( 'No %s ledger account is selected in the Reckon mappings.', 'sparxsync-accounting-integration-for-reckon-one' ), $labels[ $line['kind'] ] ) );
				}
				if ( 'product' === $line['kind'] ) {
					// Quantity is shown in the description; the amount is the full line amount.
					$entry['description'] = self::description( sprintf( '%s × %s', $line['name'], self::number( $line['quantity'] ) ) );
				}
				$entry['accountDetails'] = array(
					'ledgerAccount' => $account,
					'quantity'      => 1,
					'amount'        => $line['amount_c'] / $scale,
				);
			}
			$line_items[] = $entry;
		}

		$created = $order->get_date_created();
		$date    = ( $created ? $created->format( 'Y-m-d' ) : wp_date( 'Y-m-d' ) ) . 'T00:00:00';

		return array(
			'customer'        => $customer_id,
			'invoiceDate'     => $date,
			'dueDate'         => $date,
			'amountTaxStatus' => $prepared['status'],
			'reference'       => $reference,
			/* translators: %s: order number. */
			'notes'           => sprintf( __( 'WooCommerce order #%s', 'sparxsync-accounting-integration-for-reckon-one' ), $order->get_order_number() ),
			'lineItems'       => $line_items,
		);
	}

	/**
	 * Sum a payload the way Reckon is expected to: line amount = price × quantity
	 * (item lines) or amount (account lines), plus the explicit tax amount.
	 * Used to double-check the payload before sending.
	 *
	 * @param array $payload  Payload.
	 * @param int   $dp       Decimals.
	 * @return array net_c, tax_c, gross_c.
	 */
	public static function payload_totals( $payload, $dp ) {
		$scale = pow( 10, $dp );
		$amt   = 0;
		$tax   = 0;
		foreach ( $payload['lineItems'] as $line ) {
			if ( isset( $line['itemDetails'] ) ) {
				$amt += (int) round( $line['itemDetails']['price'] * $line['itemDetails']['quantity'] * $scale );
			} else {
				$amt += (int) round( $line['accountDetails']['amount'] * $line['accountDetails']['quantity'] * $scale );
			}
			$tax += isset( $line['taxAmount'] ) ? (int) round( $line['taxAmount'] * $scale ) : 0;
		}
		$inclusive = 'Inclusive' === $payload['amountTaxStatus'];
		return array(
			'net_c'   => $inclusive ? $amt - $tax : $amt,
			'tax_c'   => $tax,
			'gross_c' => $inclusive ? $amt : $amt + $tax,
		);
	}

	/**
	 * Unit price that reproduces the line amount exactly at currency precision.
	 *
	 * @param int   $amount_c Line amount in minor units.
	 * @param float $qty      Quantity.
	 * @param int   $dp       Currency decimals.
	 * @return float|int|WP_Error
	 */
	public static function unit_price( $amount_c, $qty, $dp ) {
		if ( 0 === $amount_c ) {
			return 0;
		}
		$scale = pow( 10, $dp );
		for ( $d = $dp; $d <= max( $dp, self::MAX_PRICE_DECIMALS ); $d++ ) {
			$price = round( $amount_c / $scale / $qty, $d );
			if ( (int) round( $price * $qty * $scale ) === $amount_c ) {
				return $price;
			}
		}
		return self::fail(
			'unit_price_precision',
			/* translators: 1: line amount, 2: quantity. */
			sprintf( __( 'A line amount of %1$s cannot be expressed as a unit price for quantity %2$s without changing the total.', 'sparxsync-accounting-integration-for-reckon-one' ), number_format( $amount_c / $scale, $dp, '.', '' ), self::number( $qty ) )
		);
	}

	/**
	 * Choose the invoice amount tax status.
	 *
	 * @param WC_Order $order        Order.
	 * @param array    $tax_settings Reckon tax settings.
	 * @return string NonTaxed|Inclusive|Exclusive
	 */
	private static function amount_tax_status( $order, $tax_settings ) {
		if ( isset( $tax_settings['tax_registered'] ) && false === $tax_settings['tax_registered'] ) {
			return 'NonTaxed';
		}
		if ( isset( $tax_settings['choose_amount_tax_status'] ) && false === $tax_settings['choose_amount_tax_status'] && ! empty( $tax_settings['amount_tax_status'] ) ) {
			return $tax_settings['amount_tax_status'];
		}
		return $order->get_prices_include_tax() ? 'Inclusive' : 'Exclusive';
	}

	/**
	 * Per-rate tax amounts for an order item.
	 *
	 * @param WC_Order_Item $item Item.
	 * @return array rate_id => float.
	 */
	private static function tax_breakdown( $item ) {
		$taxes = $item->get_taxes();
		$out   = array();
		if ( isset( $taxes['total'] ) && is_array( $taxes['total'] ) ) {
			foreach ( $taxes['total'] as $rate_id => $amount ) {
				$out[ (int) $rate_id ] = is_numeric( $amount ) ? (float) $amount : 0.0;
			}
		}
		return $out;
	}

	/**
	 * Reckon tax code for a line.
	 *
	 * @param WC_Order $order    Order.
	 * @param array    $line     Raw line.
	 * @param array    $mappings Mappings.
	 * @param string   $status   Amount tax status.
	 * @return string|null|WP_Error
	 */
	private static function line_tax_code( $order, $line, $mappings, $status ) {
		$nonzero = array_filter(
			$line['taxes'],
			function ( $amount ) {
				return abs( $amount ) > 1e-9;
			}
		);
		if ( abs( $line['tax'] ) > 1e-9 && empty( $nonzero ) ) {
			/* translators: %s: line name. */
			return self::fail( 'tax_breakdown_missing', sprintf( __( 'Line "%s" has tax without a per-rate breakdown, so its tax code cannot be determined.', 'sparxsync-accounting-integration-for-reckon-one' ), $line['name'] ) );
		}
		if ( count( $nonzero ) > 1 ) {
			$labels = array();
			foreach ( array_keys( $nonzero ) as $rate_id ) {
				$labels[] = self::rate_label( $order, $rate_id );
			}
			/* translators: 1: line name, 2: tax rate list. */
			return self::fail( 'multiple_tax_rates', sprintf( __( 'Line "%1$s" is taxed at more than one rate (%2$s). A Reckon invoice line accepts one tax rate, so this order cannot be synchronized automatically.', 'sparxsync-accounting-integration-for-reckon-one' ), $line['name'], implode( ', ', $labels ) ) );
		}
		if ( 'NonTaxed' === $status ) {
			return null;
		}

		$rate_id = null;
		if ( 1 === count( $nonzero ) ) {
			$rate_id = key( $nonzero );
		} elseif ( 1 === count( $line['taxes'] ) ) {
			$rate_id = key( $line['taxes'] ); // A single zero-amount rate, e.g. a 0% GST-free rate.
		}

		if ( null !== $rate_id ) {
			$mapped = isset( $mappings['tax_rates'][ (string) $rate_id ] ) ? (string) $mappings['tax_rates'][ (string) $rate_id ] : '';
			if ( '' !== $mapped ) {
				return $mapped;
			}
			if ( ! empty( $nonzero ) ) {
				if ( 'fallback' === $mappings['unmapped_tax_policy'] && '' !== $mappings['fallback_tax_rate'] ) {
					return $mappings['fallback_tax_rate'];
				}
				/* translators: 1: tax rate, 2: line name. */
				return self::fail( 'unmapped_tax_rate', sprintf( __( 'WooCommerce tax rate %1$s (line "%2$s") has no Reckon tax code mapping.', 'sparxsync-accounting-integration-for-reckon-one' ), self::rate_label( $order, $rate_id ), $line['name'] ) );
			}
		}

		if ( '' === $mappings['untaxed_tax_rate'] ) {
			/* translators: %s: line name. */
			return self::fail( 'untaxed_rate_not_mapped', sprintf( __( 'Line "%s" is untaxed, but no Reckon tax code for untaxed lines is selected.', 'sparxsync-accounting-integration-for-reckon-one' ), $line['name'] ) );
		}
		return $mappings['untaxed_tax_rate'];
	}

	/**
	 * Label for a WooCommerce tax rate as recorded on the order.
	 *
	 * @param WC_Order $order   Order.
	 * @param int      $rate_id Rate ID.
	 * @return string
	 */
	private static function rate_label( $order, $rate_id ) {
		foreach ( $order->get_items( 'tax' ) as $tax_item ) {
			if ( (int) $tax_item->get_rate_id() === (int) $rate_id ) {
				return sprintf( '#%d %s', $rate_id, $tax_item->get_rate_code() );
			}
		}
		return '#' . (int) $rate_id;
	}

	/**
	 * Allocate a rounding difference across lines, at most one minor unit per line.
	 *
	 * @param int[]   $values    Rounded values.
	 * @param float[] $residuals Unrounded minus rounded values.
	 * @param int[]   $eligible  Line indexes that may be adjusted.
	 * @param int     $diff      Difference to allocate.
	 * @return int[]|null Null when the difference exceeds the tolerance.
	 */
	private static function allocate( $values, $residuals, $eligible, $diff ) {
		if ( abs( $diff ) > count( $eligible ) ) {
			return null;
		}
		$step = $diff > 0 ? 1 : -1;
		usort(
			$eligible,
			function ( $a, $b ) use ( $residuals, $step ) {
				// Lines rounded furthest in the opposite direction are adjusted first.
				$cmp = ( $residuals[ $b ] - $residuals[ $a ] ) * $step;
				return $cmp > 0 ? 1 : ( $cmp < 0 ? -1 : $a - $b );
			}
		);
		for ( $i = 0; $i < abs( $diff ); $i++ ) {
			$values[ $eligible[ $i ] ] += $step;
		}
		return $values;
	}

	/**
	 * Mismatch error.
	 *
	 * @param string $code     Code.
	 * @param string $what     Which total.
	 * @param int    $expected Expected minor units.
	 * @param int    $actual   Actual minor units.
	 * @param int    $dp       Decimals.
	 * @return WP_Error
	 */
	private static function mismatch( $code, $what, $expected, $actual, $dp ) {
		$scale = pow( 10, $dp );
		return self::fail(
			$code,
			/* translators: 1: total type, 2: order amount, 3: line sum. */
			sprintf( __( 'The order %1$s total (%2$s) does not match the sum of its lines (%3$s) within the rounding tolerance of one minor unit per line. The order may contain amounts added outside line items.', 'sparxsync-accounting-integration-for-reckon-one' ), $what, number_format( $expected / $scale, $dp, '.', '' ), number_format( $actual / $scale, $dp, '.', '' ) )
		);
	}

	/**
	 * Integer when whole, float otherwise.
	 *
	 * @param float $value Value.
	 * @return int|float
	 */
	private static function number( $value ) {
		return abs( $value - round( $value ) ) < 1e-9 ? (int) round( $value ) : (float) $value;
	}

	/**
	 * Plain-text line description.
	 *
	 * @param string $text Text.
	 * @return string
	 */
	private static function description( $text ) {
		$text = trim( wp_strip_all_tags( html_entity_decode( (string) $text, ENT_QUOTES, 'UTF-8' ) ) );
		return function_exists( 'mb_substr' ) ? mb_substr( $text, 0, 500 ) : substr( $text, 0, 500 );
	}
}
