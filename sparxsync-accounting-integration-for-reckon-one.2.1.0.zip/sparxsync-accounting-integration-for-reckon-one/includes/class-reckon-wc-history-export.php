<?php
/**
 * Send past orders: queue existing orders from a date range in small batches.
 *
 * The administrator first runs a read-only check that counts matching orders and
 * those that already have a Reckon invoice. Starting the export only queues orders
 * through Reckon_WC_Sync::queue_order(), so every normal safeguard applies: orders
 * with an invoice are never sent again, and failed or needs-review orders are left
 * for the administrator instead of being retried.
 *
 * @package Reckon_WC
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Reckon_WC_History_Export {

	const OPTION     = 'reckon_wc_history_export';
	const HOOK       = 'reckon_wc_history_export_batch';
	const BATCH      = 25;
	const BATCH_GAP  = 30;
	const MAX_ORDERS = 5000;

	/**
	 * Register hooks.
	 */
	public static function init() {
		add_action( self::HOOK, array( __CLASS__, 'run_batch' ) );
		add_action( 'admin_post_reckon_wc_history_start', array( __CLASS__, 'handle_start' ) );
		add_action( 'admin_post_reckon_wc_history_cancel', array( __CLASS__, 'handle_cancel' ) );
	}

	/**
	 * Current or last export job, or null.
	 *
	 * @return array|null
	 */
	public static function job() {
		$job = get_option( self::OPTION, null );
		return is_array( $job ) && isset( $job['status'] ) ? $job : null;
	}

	/**
	 * Validate a Y-m-d date string.
	 *
	 * @param string $date Date.
	 * @return bool
	 */
	public static function valid_date( $date ) {
		if ( ! is_string( $date ) || ! preg_match( '/^(\d{4})-(\d{2})-(\d{2})$/', $date, $m ) ) {
			return false;
		}
		return checkdate( (int) $m[2], (int) $m[3], (int) $m[1] );
	}

	/**
	 * wc_get_orders() arguments for a date range and the configured statuses.
	 *
	 * @param string $from     Y-m-d.
	 * @param string $to       Y-m-d.
	 * @param array  $statuses Statuses without the wc- prefix.
	 * @return array
	 */
	private static function range_args( $from, $to, $statuses ) {
		return array(
			'type'         => 'shop_order',
			'status'       => array_values( $statuses ),
			'date_created' => $from . '...' . $to,
		);
	}

	/**
	 * Read-only check of what an export would do.
	 *
	 * @param string $from Y-m-d.
	 * @param string $to   Y-m-d.
	 * @return array|WP_Error total, invoiced, to_queue, statuses.
	 */
	public static function check( $from, $to ) {
		if ( ! self::valid_date( $from ) || ! self::valid_date( $to ) ) {
			return new WP_Error( 'reckon_wc_history_dates', __( 'Enter a valid start and end date.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}
		if ( $from > $to ) {
			return new WP_Error( 'reckon_wc_history_dates', __( 'The start date must be on or before the end date.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}
		$statuses = Reckon_WC_Settings::get( Reckon_WC_Settings::OPTION_SYNC )['order_statuses'];
		if ( empty( $statuses ) ) {
			return new WP_Error( 'reckon_wc_history_statuses', __( 'Select at least one order status on the Synchronization tab first.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}

		$base     = self::range_args( $from, $to, $statuses );
		$total    = self::count( $base );
		$invoiced = self::count(
			array_merge(
				$base,
				array(
					'meta_query' => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
						array(
							'key'     => Reckon_WC_Order_State::INVOICE_ID,
							'compare' => 'EXISTS',
						),
					),
				)
			)
		);
		return array(
			'from'     => $from,
			'to'       => $to,
			'statuses' => array_values( $statuses ),
			'total'    => $total,
			'invoiced' => min( $invoiced, $total ),
			'to_queue' => max( 0, $total - $invoiced ),
		);
	}

	/**
	 * Count orders matching arguments.
	 *
	 * @param array $args wc_get_orders() arguments.
	 * @return int
	 */
	private static function count( $args ) {
		$result = Reckon_WC_Sync::query_orders(
			array_merge(
				$args,
				array(
					'limit'    => 1,
					'paginate' => true,
					'return'   => 'ids',
				)
			)
		);
		return is_object( $result ) && isset( $result->total ) ? (int) $result->total : 0;
	}

	/**
	 * Start an export.
	 *
	 * @param string $from Y-m-d.
	 * @param string $to   Y-m-d.
	 * @return array|WP_Error The new job.
	 */
	public static function start( $from, $to ) {
		$job = self::job();
		if ( null !== $job && 'running' === $job['status'] ) {
			return new WP_Error( 'reckon_wc_history_running', __( 'An export is already running. Wait for it to finish or cancel it.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}
		if ( ! Reckon_WC_Integration::scheduler_available() ) {
			return new WP_Error( 'reckon_wc_scheduler_unavailable', __( 'Action Scheduler is not available, so orders cannot be queued.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}
		if ( ! Reckon_WC_Settings::get( Reckon_WC_Settings::OPTION_SYNC )['enabled'] ) {
			return new WP_Error( 'reckon_wc_sync_disabled', __( 'Turn on automatic synchronization before sending past orders.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}
		$blocker = Reckon_WC_Settings::sync_blocker();
		if ( null !== $blocker ) {
			return $blocker;
		}
		$check = self::check( $from, $to );
		if ( is_wp_error( $check ) ) {
			return $check;
		}
		if ( 0 === $check['to_queue'] ) {
			return new WP_Error( 'reckon_wc_history_empty', __( 'There are no orders in that range that still need a Reckon invoice.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}
		if ( $check['total'] > self::MAX_ORDERS ) {
			/* translators: %s: maximum number of orders. */
			return new WP_Error( 'reckon_wc_history_too_many', sprintf( __( 'That range has more than %s orders. Choose a shorter date range and send it in parts.', 'sparxsync-accounting-integration-for-reckon-one' ), number_format_i18n( self::MAX_ORDERS ) ) );
		}

		$job = array(
			'status'      => 'running',
			'from'        => $check['from'],
			'to'          => $check['to'],
			'statuses'    => $check['statuses'],
			'total'       => $check['total'],
			'offset'      => 0,
			'queued'      => 0,
			'skipped'     => 0,
			'attention'   => 0,
			'errors'      => 0,
			'started_at'  => time(),
			'finished_at' => 0,
			'message'     => '',
		);
		update_option( self::OPTION, $job, false );
		as_enqueue_async_action( self::HOOK, array(), Reckon_WC_Sync::GROUP );
		Reckon_WC_Logger::info( 'Past-order export started.', array( 'operation' => 'history_export', 'total' => $check['total'] ) );
		return $job;
	}

	/**
	 * Process one batch. Action Scheduler callback.
	 */
	public static function run_batch() {
		$job = self::job();
		if ( null === $job || 'running' !== $job['status'] ) {
			return;
		}
		if ( ! Reckon_WC_Settings::get( Reckon_WC_Settings::OPTION_SYNC )['enabled'] ) {
			self::finish( $job, 'stopped', __( 'Stopped because automatic synchronization was turned off.', 'sparxsync-accounting-integration-for-reckon-one' ) );
			return;
		}

		$orders = Reckon_WC_Sync::query_orders(
			array_merge(
				self::range_args( $job['from'], $job['to'], $job['statuses'] ),
				array(
					'limit'   => self::BATCH,
					'offset'  => (int) $job['offset'],
					'orderby' => 'date',
					'order'   => 'ASC',
				)
			)
		);
		$orders = is_array( $orders ) ? $orders : array();

		foreach ( $orders as $order ) {
			$state = Reckon_WC_Order_State::get_state( $order );
			if ( '' !== Reckon_WC_Order_State::get_invoice_id( $order ) ) {
				++$job['skipped'];
				continue;
			}
			if ( in_array( $state, array( Reckon_WC_Order_State::FAILED, Reckon_WC_Order_State::NEEDS_REVIEW ), true ) ) {
				// Leave these for the administrator; the Orders tab lists them.
				++$job['attention'];
				continue;
			}
			$result = Reckon_WC_Sync::queue_order( $order, 'history' );
			if ( 'queued' === $result ) {
				++$job['queued'];
			} elseif ( is_wp_error( $result ) ) {
				++$job['errors'];
			} else {
				++$job['skipped'];
			}
		}
		$job['offset'] = (int) $job['offset'] + count( $orders );

		if ( count( $orders ) < self::BATCH ) {
			self::finish( $job, 'done', '' );
			return;
		}
		update_option( self::OPTION, $job, false );
		if ( ! as_has_scheduled_action( self::HOOK, array(), Reckon_WC_Sync::GROUP ) ) {
			as_schedule_single_action( time() + self::BATCH_GAP, self::HOOK, array(), Reckon_WC_Sync::GROUP );
		}
	}

	/**
	 * Mark the job finished.
	 *
	 * @param array  $job     Job.
	 * @param string $status  done|stopped|cancelled.
	 * @param string $message Optional message.
	 */
	private static function finish( $job, $status, $message ) {
		$job['status']      = $status;
		$job['finished_at'] = time();
		$job['message']     = $message;
		update_option( self::OPTION, $job, false );
		Reckon_WC_Logger::info(
			'Past-order export ' . $status . '.',
			array(
				'operation' => 'history_export',
				'queued'    => $job['queued'],
				'skipped'   => $job['skipped'],
				'errors'    => $job['errors'],
			)
		);
	}

	/**
	 * Cancel a running export. Orders already queued stay queued.
	 */
	public static function cancel() {
		$job = self::job();
		if ( function_exists( 'as_unschedule_all_actions' ) ) {
			as_unschedule_all_actions( self::HOOK );
		}
		if ( null !== $job && 'running' === $job['status'] ) {
			self::finish( $job, 'cancelled', __( 'Cancelled. Orders that were already queued will still be sent.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}
	}

	/**
	 * Capability and nonce check for the admin-post handlers.
	 *
	 * @param string $action Nonce action.
	 */
	private static function verify( $action ) {
		if ( ! current_user_can( Reckon_WC_Settings::capability() ) ) {
			wp_die( esc_html__( 'You do not have permission to manage the Reckon One integration.', 'sparxsync-accounting-integration-for-reckon-one' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( $action );
	}

	/**
	 * Start handler.
	 */
	public static function handle_start() {
		self::verify( 'reckon_wc_history_start' );
		$from = isset( $_POST['from'] ) ? sanitize_text_field( wp_unslash( $_POST['from'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- verified in verify().
		$to   = isset( $_POST['to'] ) ? sanitize_text_field( wp_unslash( $_POST['to'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- verified in verify().
		$job  = self::start( $from, $to );
		if ( is_wp_error( $job ) ) {
			Reckon_WC_Settings::add_notice( 'error', $job->get_error_message() );
		} else {
			/* translators: %s: number of orders. */
			Reckon_WC_Settings::add_notice( 'success', sprintf( __( 'Sending past orders has started. %s orders will be checked in small batches in the background.', 'sparxsync-accounting-integration-for-reckon-one' ), number_format_i18n( $job['total'] ) ) );
		}
		wp_safe_redirect( Reckon_WC_Settings::page_url( 'orders' ) );
		exit;
	}

	/**
	 * Cancel handler.
	 */
	public static function handle_cancel() {
		self::verify( 'reckon_wc_history_cancel' );
		self::cancel();
		Reckon_WC_Settings::add_notice( 'info', __( 'Sending past orders was cancelled. Orders that were already queued will still be sent.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		wp_safe_redirect( Reckon_WC_Settings::page_url( 'orders' ) );
		exit;
	}

	/**
	 * "Send past orders" card on the Orders tab.
	 */
	public static function render() {
		echo '<h2>' . esc_html__( 'Send past orders to Reckon', 'sparxsync-accounting-integration-for-reckon-one' ) . '</h2>';
		$job = self::job();

		if ( null !== $job && 'running' === $job['status'] ) {
			// Deactivation cancels scheduled actions; pick the job up again where it stopped.
			if ( Reckon_WC_Integration::scheduler_available() && ! as_has_scheduled_action( self::HOOK, array(), Reckon_WC_Sync::GROUP ) ) {
				as_enqueue_async_action( self::HOOK, array(), Reckon_WC_Sync::GROUP );
			}
			$percent = $job['total'] > 0 ? (int) min( 100, round( 100 * $job['offset'] / $job['total'] ) ) : 0;
			/* translators: 1: start date, 2: end date. */
			echo '<p>' . esc_html( sprintf( __( 'Sending orders from %1$s to %2$s in the background.', 'sparxsync-accounting-integration-for-reckon-one' ), $job['from'], $job['to'] ) ) . '</p>';
			echo '<div class="sxs-progress" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="' . esc_attr( $percent ) . '"><span style="width:' . esc_attr( $percent ) . '%"></span></div>';
			self::render_counts( $job );
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
			echo '<input type="hidden" name="action" value="reckon_wc_history_cancel" />';
			wp_nonce_field( 'reckon_wc_history_cancel' );
			echo '<button type="submit" class="button">' . esc_html__( 'Cancel', 'sparxsync-accounting-integration-for-reckon-one' ) . '</button>';
			echo '</form>';
			return;
		}

		if ( null !== $job ) {
			$titles = array(
				'done'      => __( 'Last export finished.', 'sparxsync-accounting-integration-for-reckon-one' ),
				'stopped'   => __( 'Last export stopped.', 'sparxsync-accounting-integration-for-reckon-one' ),
				'cancelled' => __( 'Last export was cancelled.', 'sparxsync-accounting-integration-for-reckon-one' ),
			);
			echo '<div class="notice inline notice-' . esc_attr( 'done' === $job['status'] ? 'success' : 'warning' ) . '"><p>' . esc_html( isset( $titles[ $job['status'] ] ) ? $titles[ $job['status'] ] : $job['status'] );
			/* translators: 1: start date, 2: end date. */
			echo ' ' . esc_html( sprintf( __( 'Range: %1$s to %2$s.', 'sparxsync-accounting-integration-for-reckon-one' ), $job['from'], $job['to'] ) );
			if ( '' !== $job['message'] ) {
				echo ' ' . esc_html( $job['message'] );
			}
			echo '</p></div>';
			self::render_counts( $job );
		}

		echo '<p>' . esc_html__( 'Create Reckon invoices for orders placed before the integration was set up. Only orders with the statuses selected on the Synchronization tab are included. Orders that already have a Reckon invoice are skipped, and failed or needs-review orders are left for you to handle.', 'sparxsync-accounting-integration-for-reckon-one' ) . '</p>';

		// Step 1: a read-only check (GET). Step 2: start (POST, nonce-protected).
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- The check is read-only; its own nonce is verified below before any count runs.
		$from    = isset( $_GET['reckon_from'] ) ? sanitize_text_field( wp_unslash( $_GET['reckon_from'] ) ) : '';
		$to      = isset( $_GET['reckon_to'] ) ? sanitize_text_field( wp_unslash( $_GET['reckon_to'] ) ) : '';
		$checked = '' !== $from && isset( $_GET['reckon_check'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['reckon_check'] ) ), 'reckon_wc_history_check' );
		// phpcs:enable

		echo '<form method="get" action="' . esc_url( admin_url( 'admin.php' ) ) . '" class="sxs-inline-form">';
		echo '<input type="hidden" name="page" value="' . esc_attr( Reckon_WC_Settings::PAGE_SLUG ) . '" />';
		echo '<input type="hidden" name="tab" value="orders" />';
		echo '<input type="hidden" name="reckon_check" value="' . esc_attr( wp_create_nonce( 'reckon_wc_history_check' ) ) . '" />';
		echo '<label>' . esc_html__( 'From', 'sparxsync-accounting-integration-for-reckon-one' ) . ' <input type="date" name="reckon_from" required value="' . esc_attr( $from ) . '" /></label> ';
		echo '<label>' . esc_html__( 'To', 'sparxsync-accounting-integration-for-reckon-one' ) . ' <input type="date" name="reckon_to" required value="' . esc_attr( '' !== $to ? $to : wp_date( 'Y-m-d' ) ) . '" /></label> ';
		echo '<button type="submit" class="button">' . esc_html__( 'Check orders', 'sparxsync-accounting-integration-for-reckon-one' ) . '</button>';
		echo '</form>';

		if ( ! $checked ) {
			return;
		}
		$check = self::check( $from, $to );
		if ( is_wp_error( $check ) ) {
			echo '<div class="notice inline notice-error"><p>' . esc_html( $check->get_error_message() ) . '</p></div>';
			return;
		}
		echo '<ul class="sxs-check">';
		/* translators: %s: number of orders. */
		echo '<li>' . esc_html( sprintf( __( '%s orders found in this range', 'sparxsync-accounting-integration-for-reckon-one' ), number_format_i18n( $check['total'] ) ) ) . '</li>';
		/* translators: %s: number of orders. */
		echo '<li>' . esc_html( sprintf( __( '%s already have a Reckon invoice and will be skipped', 'sparxsync-accounting-integration-for-reckon-one' ), number_format_i18n( $check['invoiced'] ) ) ) . '</li>';
		/* translators: %s: number of orders. */
		echo '<li><strong>' . esc_html( sprintf( __( 'Up to %s will be queued for a new invoice', 'sparxsync-accounting-integration-for-reckon-one' ), number_format_i18n( $check['to_queue'] ) ) ) . '</strong></li>';
		echo '</ul>';

		if ( $check['total'] > self::MAX_ORDERS ) {
			/* translators: %s: maximum number of orders. */
			echo '<div class="notice inline notice-warning"><p>' . esc_html( sprintf( __( 'One export can include up to %s orders. Choose a shorter date range.', 'sparxsync-accounting-integration-for-reckon-one' ), number_format_i18n( self::MAX_ORDERS ) ) ) . '</p></div>';
			return;
		}
		if ( 0 === $check['to_queue'] ) {
			return;
		}
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		echo '<input type="hidden" name="action" value="reckon_wc_history_start" />';
		echo '<input type="hidden" name="from" value="' . esc_attr( $check['from'] ) . '" />';
		echo '<input type="hidden" name="to" value="' . esc_attr( $check['to'] ) . '" />';
		wp_nonce_field( 'reckon_wc_history_start' );
		/* translators: %s: number of orders. */
		echo '<button type="submit" class="button button-primary">' . esc_html( sprintf( __( 'Send %s orders to Reckon', 'sparxsync-accounting-integration-for-reckon-one' ), number_format_i18n( $check['to_queue'] ) ) ) . '</button>';
		echo '<p class="description">' . esc_html__( 'Orders are queued 25 at a time and sent by the background worker. Each one gets its own invoice, exactly as if it had just been placed.', 'sparxsync-accounting-integration-for-reckon-one' ) . '</p>';
		echo '</form>';
	}

	/**
	 * Progress counts.
	 *
	 * @param array $job Job.
	 */
	private static function render_counts( $job ) {
		/* translators: 1: processed, 2: total, 3: queued, 4: skipped, 5: needing attention, 6: errors. */
		echo '<p class="sxs-muted">' . esc_html( sprintf( __( 'Checked %1$s of %2$s · queued %3$s · skipped %4$s · need attention %5$s · errors %6$s', 'sparxsync-accounting-integration-for-reckon-one' ), number_format_i18n( min( $job['offset'], $job['total'] ) ), number_format_i18n( $job['total'] ), number_format_i18n( $job['queued'] ), number_format_i18n( $job['skipped'] ), number_format_i18n( $job['attention'] ), number_format_i18n( $job['errors'] ) ) ) . '</p>';
	}
}
