<?php
/**
 * Read-only "Paid in Reckon" check.
 *
 * Once an hour, a small batch of recently invoiced orders is checked with
 * GET /{book}/invoices/{id}, the same call verification already uses, and the
 * invoice status (Draft, Approved or Paid) is stored on the order. Nothing is
 * written to Reckon and the WooCommerce order status is never changed; when an
 * invoice is first seen as paid, an order note is added.
 *
 * @package Reckon_WC
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Reckon_WC_Payment_Status {

	const HOOK        = 'reckon_wc_check_payments';
	const INTERVAL    = HOUR_IN_SECONDS;
	const PER_RUN     = 20;
	const WINDOW_DAYS = 120;
	const RECHECK     = 12 * HOUR_IN_SECONDS;
	const NOT_FOUND   = 'NotFound';

	/**
	 * Errors that mean "stop this run and try again later" rather than "skip this order".
	 */
	const STOP_ERRORS = array(
		'reckon_wc_unauthorized',
		'reckon_wc_reconnect_required',
		'reckon_wc_not_connected',
		'reckon_wc_missing_credentials',
		'reckon_wc_refresh_in_progress',
		'reckon_wc_token_rejected',
		'reckon_wc_token_endpoint_unavailable',
		'reckon_wc_rate_limited',
		'reckon_wc_transport',
		'reckon_wc_server_error',
	);

	/**
	 * Register hooks.
	 */
	public static function init() {
		add_action( self::HOOK, array( __CLASS__, 'run' ) );
		if ( is_admin() || wp_doing_cron() ) {
			add_action( 'init', array( __CLASS__, 'maybe_schedule' ) );
		}
	}

	/**
	 * Whether the check is switched on.
	 *
	 * @return bool
	 */
	public static function enabled() {
		return (bool) Reckon_WC_Settings::get( Reckon_WC_Settings::OPTION_SYNC )['check_payment_status'];
	}

	/**
	 * Keep the recurring action in line with the setting.
	 */
	public static function maybe_schedule() {
		if ( ! Reckon_WC_Integration::scheduler_available() || ! function_exists( 'as_schedule_recurring_action' ) ) {
			return;
		}
		$scheduled = as_has_scheduled_action( self::HOOK, array(), Reckon_WC_Sync::GROUP );
		if ( ! self::enabled() ) {
			if ( $scheduled ) {
				as_unschedule_all_actions( self::HOOK );
			}
			return;
		}
		if ( ! $scheduled ) {
			as_schedule_recurring_action( time() + 5 * MINUTE_IN_SECONDS, self::INTERVAL, self::HOOK, array(), Reckon_WC_Sync::GROUP );
		}
	}

	/**
	 * Human-readable label for a stored Reckon status.
	 *
	 * @param string $status Status.
	 * @return string
	 */
	public static function label( $status ) {
		$labels = array(
			'paid'                        => __( 'Paid', 'sparxsync-accounting-integration-for-reckon-one' ),
			'approved'                    => __( 'Approved, not paid', 'sparxsync-accounting-integration-for-reckon-one' ),
			'draft'                       => __( 'Draft', 'sparxsync-accounting-integration-for-reckon-one' ),
			strtolower( self::NOT_FOUND ) => __( 'Not found in Reckon', 'sparxsync-accounting-integration-for-reckon-one' ),
		);
		$key = strtolower( (string) $status );
		return isset( $labels[ $key ] ) ? $labels[ $key ] : (string) $status;
	}

	/**
	 * Orders due for a check: invoiced in the window, not yet paid, not checked recently.
	 *
	 * @param int $now Current time.
	 * @return WC_Order[]
	 */
	public static function due_orders( $now ) {
		$orders = Reckon_WC_Sync::query_orders(
			array(
				'type'       => 'shop_order',
				'limit'      => self::PER_RUN,
				'orderby'    => 'date',
				'order'      => 'ASC',
				'meta_query' => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
					'relation' => 'AND',
					array(
						'key'     => Reckon_WC_Order_State::INVOICE_ID,
						'compare' => 'EXISTS',
					),
					array(
						'key'     => Reckon_WC_Order_State::SYNCED_AT,
						'value'   => $now - self::WINDOW_DAYS * DAY_IN_SECONDS,
						'compare' => '>=',
						'type'    => 'NUMERIC',
					),
					array(
						'key'     => Reckon_WC_Order_State::PAID_AT,
						'compare' => 'NOT EXISTS',
					),
					array(
						'relation' => 'OR',
						array(
							'key'     => Reckon_WC_Order_State::REMOTE_CHECKED_AT,
							'compare' => 'NOT EXISTS',
						),
						array(
							'key'     => Reckon_WC_Order_State::REMOTE_CHECKED_AT,
							'value'   => $now - self::RECHECK,
							'compare' => '<=',
							'type'    => 'NUMERIC',
						),
					),
				),
			)
		);
		return is_array( $orders ) ? $orders : array();
	}

	/**
	 * Recurring action: check a batch of orders.
	 *
	 * @return array Counts: checked, paid, stopped (bool).
	 */
	public static function run() {
		$result = array(
			'checked' => 0,
			'paid'    => 0,
			'stopped' => false,
		);
		if ( ! self::enabled() ) {
			return $result;
		}
		$conn = Reckon_WC_OAuth::get_connection();
		if ( 'connected' !== $conn['status'] || ! Reckon_WC_OAuth::has_tokens() ) {
			return $result;
		}

		$now = time();
		foreach ( self::due_orders( $now ) as $order ) {
			$outcome = self::check_order( $order, $now );
			if ( 'stop' === $outcome ) {
				$result['stopped'] = true;
				break;
			}
			++$result['checked'];
			if ( 'paid' === $outcome ) {
				++$result['paid'];
			}
		}
		if ( $result['paid'] > 0 ) {
			delete_transient( Reckon_WC_Sync::STATS_CACHE );
		}
		Reckon_WC_Logger::debug( 'Payment status check: ' . $result['checked'] . ' checked, ' . $result['paid'] . ' newly paid' . ( $result['stopped'] ? ', stopped early' : '' ) . '.', array( 'operation' => 'payment_status' ) );
		return $result;
	}

	/**
	 * Check one order's invoice.
	 *
	 * Re-checks the order's own state first, so a stale query result cannot act on an
	 * order that was paid, unlinked or re-checked in the meantime.
	 *
	 * @param WC_Order $order Order.
	 * @param int      $now   Current time.
	 * @return string paid|status|skipped|stop.
	 */
	public static function check_order( $order, $now ) {
		$invoice_id = Reckon_WC_Order_State::get_invoice_id( $order );
		$book_id    = (string) $order->get_meta( Reckon_WC_Order_State::BOOK_ID, true );
		if ( '' === $invoice_id || (int) $order->get_meta( Reckon_WC_Order_State::PAID_AT, true ) > 0 ) {
			return 'skipped';
		}
		if ( '' === $book_id ) {
			// Linked by version 1.x: the book is unknown, so there is nothing safe to read.
			$order->update_meta_data( Reckon_WC_Order_State::REMOTE_CHECKED_AT, $now );
			$order->save();
			return 'skipped';
		}

		$invoice = Reckon_WC_API::get_invoice( $book_id, $invoice_id );
		if ( is_wp_error( $invoice ) ) {
			if ( in_array( $invoice->get_error_code(), self::STOP_ERRORS, true ) ) {
				return 'stop';
			}
			if ( 'reckon_wc_not_found' === $invoice->get_error_code() ) {
				$order->update_meta_data( Reckon_WC_Order_State::REMOTE_STATUS, self::NOT_FOUND );
			}
			// Any other error is specific to this invoice: skip it until the next re-check.
			$order->update_meta_data( Reckon_WC_Order_State::REMOTE_CHECKED_AT, $now );
			$order->save();
			return 'skipped';
		}

		$status = isset( $invoice['status'] ) && is_string( $invoice['status'] ) ? trim( $invoice['status'] ) : '';
		$order->update_meta_data( Reckon_WC_Order_State::REMOTE_CHECKED_AT, $now );
		if ( '' !== $status ) {
			$order->update_meta_data( Reckon_WC_Order_State::REMOTE_STATUS, $status );
		}
		$paid = 0 === strcasecmp( $status, 'Paid' );
		if ( $paid ) {
			$order->update_meta_data( Reckon_WC_Order_State::PAID_AT, $now );
		}
		$order->save();

		if ( $paid ) {
			/* translators: %s: Reckon invoice ID. */
			$order->add_order_note( sprintf( __( 'Reckon One: invoice %s is marked as paid in Reckon. The WooCommerce order status was not changed.', 'sparxsync-accounting-integration-for-reckon-one' ), $invoice_id ) );
			return 'paid';
		}
		return 'status';
	}
}
