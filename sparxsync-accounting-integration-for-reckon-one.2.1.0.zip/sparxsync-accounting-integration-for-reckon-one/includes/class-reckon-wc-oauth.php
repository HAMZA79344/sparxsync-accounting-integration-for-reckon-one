<?php
/**
 * OAuth 2.0 authorization code flow and token storage for the Reckon identity server.
 *
 * Verified against Reckon's "Authorisation Services Overview" article and the
 * discovery document at https://identity.reckon.com/.well-known/openid-configuration:
 * - Token requests authenticate the client with HTTP Basic (client_secret_basic).
 * - The refresh request includes redirect_uri, as in Reckon's example.
 * - PKCE is not documented and code_challenge_methods_supported is not
 *   advertised, so it is not used. The flow relies on the client secret and a
 *   single-use state value bound to the initiating administrator.
 * - A revocation endpoint is advertised; it is used best-effort on disconnect.
 *
 * @package Reckon_WC
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Reckon_WC_OAuth {

	const TOKENS_OPTION     = 'reckon_wc_tokens';
	const CONNECTION_OPTION = 'reckon_wc_connection';
	const STATE_PREFIX      = '_reckon_wc_oauth_state_';
	const STATE_TTL         = 600;
	const EXPIRY_MARGIN     = 120;
	const REFRESH_LOCK      = 'token_refresh';
	const REFRESH_LOCK_TTL  = 60;
	const SCOPES            = 'openid read write offline_access';
	const CALLBACK_ACTION   = 'reckon_wc_oauth_callback';

	/**
	 * Register hooks. The callback is only registered for logged-in users.
	 */
	public static function init() {
		add_action( 'wp_ajax_' . self::CALLBACK_ACTION, array( __CLASS__, 'ajax_callback' ) );
	}

	/**
	 * Redirect URI registered with Reckon. Unchanged from 1.x so existing registrations keep working.
	 *
	 * @return string
	 */
	public static function get_redirect_uri() {
		$default = admin_url( 'admin-ajax.php?action=' . self::CALLBACK_ACTION );
		$legacy  = get_option( 'reckon_wc_redirect_uri', '' );
		$uri     = $default;
		if ( is_string( $legacy ) && '' !== $legacy && wp_http_validate_url( $legacy ) && wp_parse_url( $legacy, PHP_URL_HOST ) === wp_parse_url( $default, PHP_URL_HOST ) && false !== strpos( $legacy, self::CALLBACK_ACTION ) ) {
			$uri = $legacy;
		}
		return (string) apply_filters( 'reckon_wc_redirect_uri', $uri );
	}

	/**
	 * Stored tokens.
	 *
	 * @param bool $fresh Bypass the object cache (used inside the refresh lock).
	 * @return array access_token, refresh_token, expires_at, obtained_at.
	 */
	public static function get_tokens( $fresh = false ) {
		if ( $fresh ) {
			wp_cache_delete( self::TOKENS_OPTION, 'options' );
			wp_cache_delete( 'notoptions', 'options' );
		}
		$tokens = get_option( self::TOKENS_OPTION, array() );
		$tokens = is_array( $tokens ) ? $tokens : array();
		return array(
			'access_token'  => isset( $tokens['access_token'] ) && is_string( $tokens['access_token'] ) ? $tokens['access_token'] : '',
			'refresh_token' => isset( $tokens['refresh_token'] ) && is_string( $tokens['refresh_token'] ) ? $tokens['refresh_token'] : '',
			'expires_at'    => isset( $tokens['expires_at'] ) ? (int) $tokens['expires_at'] : 0,
			'obtained_at'   => isset( $tokens['obtained_at'] ) ? (int) $tokens['obtained_at'] : 0,
		);
	}

	/**
	 * Whether usable tokens exist (a refresh token, or an unexpired access token).
	 *
	 * @return bool
	 */
	public static function has_tokens() {
		$tokens = self::get_tokens();
		return '' !== $tokens['refresh_token'] || ( '' !== $tokens['access_token'] && $tokens['expires_at'] > time() );
	}

	/**
	 * Connection record.
	 *
	 * @param bool $fresh Bypass the object cache.
	 * @return array status (disconnected|connected|reconnect_required), connected_at, last_verified_at, last_refreshed_at, last_error, connected_by.
	 */
	public static function get_connection( $fresh = false ) {
		if ( $fresh ) {
			wp_cache_delete( self::CONNECTION_OPTION, 'options' );
		}
		$conn = get_option( self::CONNECTION_OPTION, array() );
		$conn = is_array( $conn ) ? $conn : array();
		$out  = array(
			'status'            => 'disconnected',
			'connected_at'      => 0,
			'last_verified_at'  => 0,
			'last_refreshed_at' => 0,
			'last_error'        => '',
			'connected_by'      => 0,
		);
		foreach ( $out as $key => $default ) {
			if ( isset( $conn[ $key ] ) && is_scalar( $conn[ $key ] ) ) {
				$out[ $key ] = is_int( $default ) ? (int) $conn[ $key ] : (string) $conn[ $key ];
			}
		}
		if ( ! in_array( $out['status'], array( 'disconnected', 'connected', 'reconnect_required' ), true ) ) {
			$out['status'] = 'disconnected';
		}
		return $out;
	}

	/**
	 * Merge changes into the connection record.
	 *
	 * @param array $changes Changes.
	 */
	public static function update_connection( $changes ) {
		update_option( self::CONNECTION_OPTION, array_merge( self::get_connection(), $changes ), false );
	}

	/**
	 * Record a successful authenticated API call.
	 */
	public static function mark_verified() {
		self::update_connection(
			array(
				'last_verified_at' => time(),
				'last_error'       => '',
			)
		);
	}

	/**
	 * Remove local tokens and set the connection status.
	 *
	 * @param string $status disconnected|reconnect_required.
	 * @param string $reason Short machine-readable reason.
	 */
	public static function clear_tokens( $status = 'disconnected', $reason = '' ) {
		delete_option( self::TOKENS_OPTION );
		self::update_connection(
			array(
				'status'     => $status,
				'last_error' => sanitize_key( $reason ),
			)
		);
	}

	/**
	 * Begin authorization: store a single-use state for this administrator and return the Reckon URL.
	 *
	 * @param int $user_id Initiating user.
	 * @return string|WP_Error
	 */
	public static function start_authorization( $user_id ) {
		if ( ! Reckon_WC_Settings::credentials_complete() ) {
			return new WP_Error( 'reckon_wc_missing_credentials', __( 'Save the Client ID, Client Secret and Subscription Key before connecting.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}
		self::purge_expired_states();

		$state  = bin2hex( random_bytes( 32 ) );
		$record = wp_json_encode(
			array(
				'user'    => (int) $user_id,
				'expires' => time() + self::STATE_TTL,
			)
		);
		if ( ! Reckon_WC_Lock::insert_if_absent( self::state_option( $state ), $record ) ) {
			return new WP_Error( 'reckon_wc_state_storage_failed', __( 'Could not start the authorization request. Try again.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}

		$params = array(
			'client_id'     => Reckon_WC_Settings::get_credential( 'client_id' ),
			'response_type' => 'code',
			'scope'         => self::SCOPES,
			'redirect_uri'  => self::get_redirect_uri(),
			'state'         => $state,
			'nonce'         => bin2hex( random_bytes( 16 ) ),
		);
		return Reckon_WC_API::AUTH_URL . '?' . http_build_query( $params, '', '&', PHP_QUERY_RFC3986 );
	}

	/**
	 * Validate callback parameters, consume the state and exchange the code.
	 *
	 * @param array $query   Unslashed query parameters.
	 * @param int   $user_id Current user.
	 * @return true|WP_Error
	 */
	public static function handle_callback( $query, $user_id ) {
		$state = isset( $query['state'] ) && is_string( $query['state'] ) ? $query['state'] : '';
		if ( ! preg_match( '/^[a-f0-9]{64}$/', $state ) ) {
			return new WP_Error( 'reckon_wc_invalid_state', __( 'The authorization response was missing a valid state value. Start the connection again.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}

		$option = self::state_option( $state );
		$raw    = Reckon_WC_Lock::read( $option );
		if ( null === $raw ) {
			return new WP_Error( 'reckon_wc_state_not_found', __( 'This authorization response was not recognised. It may have expired or already been used. Start the connection again.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}
		if ( ! Reckon_WC_Lock::consume( $option, $raw ) ) {
			return new WP_Error( 'reckon_wc_state_used', __( 'This authorization response has already been used. Start the connection again.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}
		$record = json_decode( $raw, true );
		if ( ! is_array( $record ) || ! isset( $record['user'], $record['expires'] ) ) {
			return new WP_Error( 'reckon_wc_invalid_state', __( 'The authorization request could not be verified. Start the connection again.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}
		if ( (int) $record['user'] !== (int) $user_id ) {
			return new WP_Error( 'reckon_wc_state_user_mismatch', __( 'This authorization was started by a different user. Start the connection again from your own account.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}
		if ( (int) $record['expires'] < time() ) {
			return new WP_Error( 'reckon_wc_state_expired', __( 'The authorization request expired. Start the connection again.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}

		if ( isset( $query['error'] ) ) {
			$error = is_string( $query['error'] ) ? preg_replace( '/[^a-z_]/', '', strtolower( substr( $query['error'], 0, 64 ) ) ) : '';
			if ( 'access_denied' === $error ) {
				return new WP_Error( 'reckon_wc_authorization_declined', __( 'Authorization was declined in Reckon. The existing connection, if any, was not changed.', 'sparxsync-accounting-integration-for-reckon-one' ) );
			}
			/* translators: %s: OAuth error code. */
			return new WP_Error( 'reckon_wc_authorization_error', sprintf( __( 'Reckon returned an authorization error (%s). The existing connection, if any, was not changed.', 'sparxsync-accounting-integration-for-reckon-one' ), '' === $error ? 'unknown' : $error ) );
		}

		$code = isset( $query['code'] ) && is_string( $query['code'] ) ? $query['code'] : '';
		if ( ! preg_match( '/^[\x21-\x7E]{1,4096}$/', $code ) ) {
			return new WP_Error( 'reckon_wc_missing_code', __( 'Reckon did not return an authorization code. Start the connection again.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}

		return self::exchange_code( $code, $user_id );
	}

	/**
	 * Exchange an authorization code for tokens.
	 *
	 * @param string $code    Authorization code.
	 * @param int    $user_id User who authorized.
	 * @return true|WP_Error
	 */
	public static function exchange_code( $code, $user_id = 0 ) {
		$body = self::token_request(
			array(
				'grant_type'   => 'authorization_code',
				'code'         => $code,
				'redirect_uri' => self::get_redirect_uri(),
			)
		);
		if ( is_wp_error( $body ) ) {
			return $body;
		}
		$saved = self::save_tokens( $body, '' );
		if ( is_wp_error( $saved ) ) {
			return $saved;
		}
		self::update_connection(
			array(
				'status'            => 'connected',
				'connected_at'      => time(),
				'last_verified_at'  => 0,
				'last_refreshed_at' => time(),
				'last_error'        => '',
				'connected_by'      => (int) $user_id,
			)
		);
		Reckon_WC_Logger::info( 'Connected to Reckon.', array( 'operation' => 'oauth_connect' ) );
		return true;
	}

	/**
	 * A valid access token, refreshing when it is missing, near expiry or was rejected.
	 *
	 * @param string|null $rejected Token the API just rejected with 401.
	 * @return string|WP_Error
	 */
	public static function get_access_token( $rejected = null ) {
		$connection = self::get_connection();
		if ( 'reconnect_required' === $connection['status'] ) {
			return self::reconnect_error();
		}
		$tokens = self::get_tokens();
		if ( '' === $tokens['access_token'] && '' === $tokens['refresh_token'] ) {
			return Reckon_WC_API::error( 'reckon_wc_not_connected', __( 'The store is not connected to Reckon.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}
		if ( self::access_token_usable( $tokens, $rejected ) ) {
			return $tokens['access_token'];
		}
		return self::refresh_access_token( $rejected );
	}

	/**
	 * Refresh the access token. Only one process refreshes at a time; others
	 * receive a retryable error instead of racing with a rotated refresh token.
	 *
	 * @param string|null $rejected Token the API just rejected.
	 * @return string|WP_Error
	 */
	public static function refresh_access_token( $rejected = null ) {
		$lock = Reckon_WC_Lock::acquire( self::REFRESH_LOCK, self::REFRESH_LOCK_TTL );
		if ( false === $lock ) {
			return Reckon_WC_API::error(
				'reckon_wc_refresh_in_progress',
				__( 'Another process is refreshing the Reckon token. The request will be retried.', 'sparxsync-accounting-integration-for-reckon-one' ),
				array(
					'retryable'   => true,
					'retry_after' => 30,
				)
			);
		}

		try {
			// Re-read inside the lock: another worker may have refreshed and rotated the tokens.
			$connection = self::get_connection( true );
			if ( 'reconnect_required' === $connection['status'] ) {
				return self::reconnect_error();
			}
			$tokens = self::get_tokens( true );
			if ( self::access_token_usable( $tokens, $rejected ) ) {
				return $tokens['access_token'];
			}
			if ( '' === $tokens['refresh_token'] ) {
				self::clear_tokens( 'reconnect_required', 'no_refresh_token' );
				Reckon_WC_Logger::warning( 'Access token expired and no refresh token is stored. Reconnection required.', array( 'operation' => 'oauth_refresh' ) );
				return self::reconnect_error();
			}

			$body = self::token_request(
				array(
					'grant_type'    => 'refresh_token',
					'refresh_token' => $tokens['refresh_token'],
					'redirect_uri'  => self::get_redirect_uri(),
				)
			);

			if ( is_wp_error( $body ) ) {
				if ( 'reckon_wc_token_rejected' === $body->get_error_code() ) {
					$oauth_error = (string) Reckon_WC_API::error_data( $body, 'oauth_error', '' );
					self::clear_tokens( 'reconnect_required', '' === $oauth_error ? 'refresh_rejected' : $oauth_error );
					Reckon_WC_Logger::warning(
						'Reckon rejected the refresh token. Reconnection required; synchronization is paused.',
						array(
							'operation'   => 'oauth_refresh',
							'http_status' => Reckon_WC_API::error_data( $body, 'status', 0 ),
							'error_code'  => '' === $oauth_error ? 'refresh_rejected' : $oauth_error,
						)
					);
					return self::reconnect_error();
				}
				self::update_connection( array( 'last_error' => $body->get_error_code() ) );
				Reckon_WC_Logger::warning(
					'Token refresh failed temporarily; tokens were kept.',
					array(
						'operation'   => 'oauth_refresh',
						'http_status' => Reckon_WC_API::error_data( $body, 'status', 0 ),
						'error_code'  => $body->get_error_code(),
					)
				);
				return $body;
			}

			$saved = self::save_tokens( $body, $tokens['refresh_token'] );
			if ( is_wp_error( $saved ) ) {
				return $saved;
			}
			self::update_connection(
				array(
					'last_refreshed_at' => time(),
					'last_error'        => '',
				)
			);
			Reckon_WC_Logger::debug( 'Access token refreshed.', array( 'operation' => 'oauth_refresh' ) );
			return $body['access_token'];
		} finally {
			Reckon_WC_Lock::release( self::REFRESH_LOCK, $lock );
		}
	}

	/**
	 * Whether a stored access token can be used.
	 *
	 * @param array       $tokens   Tokens.
	 * @param string|null $rejected Rejected token.
	 * @return bool
	 */
	private static function access_token_usable( $tokens, $rejected ) {
		return '' !== $tokens['access_token']
			&& $tokens['expires_at'] - self::EXPIRY_MARGIN > time()
			&& ( null === $rejected || ! hash_equals( (string) $rejected, $tokens['access_token'] ) );
	}

	/**
	 * Standard reconnect-required error.
	 *
	 * @return WP_Error
	 */
	private static function reconnect_error() {
		return Reckon_WC_API::error( 'reckon_wc_reconnect_required', __( 'Reckon no longer accepts the saved authorization. An administrator must reconnect the store.', 'sparxsync-accounting-integration-for-reckon-one' ) );
	}

	/**
	 * Send a request to the token endpoint using HTTP Basic client authentication.
	 *
	 * @param array $params Form parameters.
	 * @return array|WP_Error Validated token response.
	 */
	public static function token_request( $params ) {
		$client_id = Reckon_WC_Settings::get_credential( 'client_id' );
		$secret    = Reckon_WC_Settings::get_credential( 'client_secret' );
		if ( '' === $client_id || '' === $secret ) {
			return Reckon_WC_API::error( 'reckon_wc_missing_credentials', __( 'The Reckon Client ID or Client Secret is not configured.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}

		$response = wp_remote_post(
			Reckon_WC_API::TOKEN_URL,
			array(
				'timeout'     => 20,
				'redirection' => 0,
				'headers'     => array(
					// Reckon documents Basic base64(CLIENTID:CLIENTSECRET).
					'Authorization' => 'Basic ' . base64_encode( $client_id . ':' . $secret ), // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
					'Content-Type'  => 'application/x-www-form-urlencoded',
					'Accept'        => 'application/json',
				),
				'body'        => $params,
			)
		);

		if ( is_wp_error( $response ) ) {
			return Reckon_WC_API::error(
				'reckon_wc_token_endpoint_unavailable',
				__( 'Could not reach the Reckon identity server.', 'sparxsync-accounting-integration-for-reckon-one' ),
				array(
					'retryable' => true,
					'outcome'   => 'unknown',
				)
			);
		}

		$status = (int) wp_remote_retrieve_response_code( $response );
		$body   = json_decode( (string) wp_remote_retrieve_body( $response ), true );
		$json   = JSON_ERROR_NONE === json_last_error() && is_array( $body );

		if ( 200 !== $status ) {
			$oauth_error = $json && isset( $body['error'] ) && is_string( $body['error'] ) ? preg_replace( '/[^a-z_]/', '', strtolower( substr( $body['error'], 0, 64 ) ) ) : '';
			if ( in_array( $status, array( 400, 401 ), true ) ) {
				return Reckon_WC_API::error(
					'reckon_wc_token_rejected',
					/* translators: 1: HTTP status, 2: OAuth error code. */
					sprintf( __( 'The Reckon identity server rejected the request (HTTP %1$d, %2$s).', 'sparxsync-accounting-integration-for-reckon-one' ), $status, '' === $oauth_error ? 'no error code' : $oauth_error ),
					array(
						'status'      => $status,
						'outcome'     => 'rejected',
						'oauth_error' => $oauth_error,
					)
				);
			}
			return Reckon_WC_API::error(
				'reckon_wc_token_endpoint_unavailable',
				/* translators: %d: HTTP status. */
				sprintf( __( 'The Reckon identity server returned HTTP %d.', 'sparxsync-accounting-integration-for-reckon-one' ), $status ),
				array(
					'status'      => $status,
					'retryable'   => 429 === $status || $status >= 500,
					'outcome'     => 'unknown',
					'retry_after' => Reckon_WC_API::parse_retry_after( (string) wp_remote_retrieve_header( $response, 'retry-after' ) ),
				)
			);
		}

		$valid = $json
			&& isset( $body['access_token'] ) && is_string( $body['access_token'] ) && '' !== $body['access_token'] && strlen( $body['access_token'] ) <= 16384
			&& isset( $body['expires_in'] ) && is_numeric( $body['expires_in'] ) && (int) $body['expires_in'] > 0 && (int) $body['expires_in'] <= 31536000
			&& ( ! isset( $body['token_type'] ) || ( is_string( $body['token_type'] ) && 'bearer' === strtolower( $body['token_type'] ) ) )
			&& ( ! isset( $body['refresh_token'] ) || ( is_string( $body['refresh_token'] ) && strlen( $body['refresh_token'] ) <= 16384 ) );
		if ( ! $valid ) {
			return Reckon_WC_API::error(
				'reckon_wc_token_invalid_response',
				__( 'The Reckon identity server returned an incomplete token response.', 'sparxsync-accounting-integration-for-reckon-one' ),
				array(
					'status'    => $status,
					'retryable' => true,
					'outcome'   => 'unknown',
				)
			);
		}
		return $body;
	}

	/**
	 * Store a validated token response. A rotated refresh token replaces the old one;
	 * when none is returned the previous refresh token is kept.
	 *
	 * @param array  $body             Token response.
	 * @param string $previous_refresh Previous refresh token.
	 * @return true|WP_Error
	 */
	public static function save_tokens( $body, $previous_refresh ) {
		$refresh = isset( $body['refresh_token'] ) && is_string( $body['refresh_token'] ) && '' !== $body['refresh_token'] ? $body['refresh_token'] : (string) $previous_refresh;
		$tokens  = array(
			'access_token'  => (string) $body['access_token'],
			'refresh_token' => $refresh,
			'expires_at'    => time() + (int) $body['expires_in'],
			'obtained_at'   => time(),
		);
		if ( false === get_option( self::TOKENS_OPTION, false ) ) {
			$ok = add_option( self::TOKENS_OPTION, $tokens, '', false );
		} else {
			$ok = update_option( self::TOKENS_OPTION, $tokens, false );
		}
		if ( ! $ok && self::get_tokens( true )['access_token'] !== $tokens['access_token'] ) {
			return Reckon_WC_API::error( 'reckon_wc_token_storage_failed', __( 'The Reckon tokens could not be saved.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}
		if ( '' === $refresh ) {
			Reckon_WC_Logger::warning( 'Reckon did not return a refresh token. The connection will stop working when the access token expires.', array( 'operation' => 'oauth_tokens' ) );
		}
		return true;
	}

	/**
	 * Remove local tokens and, optionally, ask Reckon to revoke the refresh token.
	 *
	 * @param bool $revoke Send a revocation request to the advertised endpoint.
	 * @return string skipped|accepted|failed
	 */
	public static function disconnect( $revoke = true ) {
		$tokens = self::get_tokens( true );
		self::clear_tokens( 'disconnected', 'admin_disconnect' );

		$result = 'skipped';
		if ( $revoke && '' !== $tokens['refresh_token'] && Reckon_WC_Settings::credentials_complete() ) {
			$response = wp_remote_post(
				Reckon_WC_API::REVOCATION_URL,
				array(
					'timeout'     => 15,
					'redirection' => 0,
					'headers'     => array(
						'Authorization' => 'Basic ' . base64_encode( Reckon_WC_Settings::get_credential( 'client_id' ) . ':' . Reckon_WC_Settings::get_credential( 'client_secret' ) ), // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
						'Content-Type'  => 'application/x-www-form-urlencoded',
					),
					'body'        => array(
						'token'           => $tokens['refresh_token'],
						'token_type_hint' => 'refresh_token',
					),
				)
			);
			$result = ( ! is_wp_error( $response ) && 200 === (int) wp_remote_retrieve_response_code( $response ) ) ? 'accepted' : 'failed';
		}
		Reckon_WC_Logger::info( 'Disconnected from Reckon. Local tokens removed; revocation request: ' . $result . '.', array( 'operation' => 'oauth_disconnect' ) );
		return $result;
	}

	/**
	 * admin-ajax callback handler. Requires a logged-in administrator.
	 */
	public static function ajax_callback() {
		if ( ! is_user_logged_in() || ! current_user_can( Reckon_WC_Settings::capability() ) ) {
			wp_die( esc_html__( 'You do not have permission to connect this store to Reckon.', 'sparxsync-accounting-integration-for-reckon-one' ), '', array( 'response' => 403 ) );
		}

		$query = array();
		foreach ( array( 'state', 'code', 'error' ) as $key ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- The single-use OAuth state is the CSRF protection for this redirect.
			if ( isset( $_GET[ $key ] ) && is_string( $_GET[ $key ] ) ) {
				$query[ $key ] = wp_unslash( $_GET[ $key ] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized,WordPress.Security.NonceVerification.Recommended -- Validated in handle_callback().
			}
		}

		$result = self::handle_callback( $query, get_current_user_id() );
		if ( is_wp_error( $result ) ) {
			Reckon_WC_Logger::warning( 'OAuth callback rejected.', array( 'operation' => 'oauth_callback', 'error_code' => $result->get_error_code() ) );
			Reckon_WC_Settings::add_notice( 'error', $result->get_error_message() );
		} else {
			$books = class_exists( 'Reckon_WC_Reference_Data' ) ? Reckon_WC_Reference_Data::refresh_books() : true;
			if ( is_wp_error( $books ) ) {
				Reckon_WC_Settings::add_notice( 'warning', __( 'Connected to Reckon, but the list of books could not be loaded:', 'sparxsync-accounting-integration-for-reckon-one' ) . ' ' . $books->get_error_message() );
			} else {
				Reckon_WC_Settings::add_notice( 'success', __( 'Connected to Reckon. Select a book to continue.', 'sparxsync-accounting-integration-for-reckon-one' ) );
			}
		}
		wp_safe_redirect( Reckon_WC_Settings::page_url( 'connection' ) );
		exit;
	}

	/**
	 * Option name for a state value (the raw state is never stored).
	 *
	 * @param string $state State.
	 * @return string
	 */
	private static function state_option( $state ) {
		return self::STATE_PREFIX . hash( 'sha256', $state );
	}

	/**
	 * Delete expired state rows.
	 */
	private static function purge_expired_states() {
		global $wpdb;
		// State rows have hashed names and are never read through get_option(); see Reckon_WC_Lock.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = $wpdb->get_results(
			$wpdb->prepare( "SELECT option_name, option_value FROM {$wpdb->options} WHERE option_name LIKE %s LIMIT 50", $wpdb->esc_like( self::STATE_PREFIX ) . '%' )
		);
		foreach ( (array) $rows as $row ) {
			$record = json_decode( (string) $row->option_value, true );
			if ( ! is_array( $record ) || ! isset( $record['expires'] ) || (int) $record['expires'] < time() ) {
				Reckon_WC_Lock::consume( $row->option_name, $row->option_value );
			}
		}
	}
}
