<?php
/**
 * Order screen integration for both HPOS (woocommerce_page_wc-orders) and
 * legacy post storage (shop_order): a Reckon One meta box, entries in the
 * native "Order actions" menu, a list column and a bulk action.
 *
 * @package Reckon_WC
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Reckon_WC_Order_Admin {

	const HPOS_SCREEN = 'woocommerce_page_wc-orders';
	const CAPABILITY  = 'edit_shop_orders';

	/**
	 * Register hooks.
	 */
	public static function init() {
		add_action( 'add_meta_boxes', array( __CLASS__, 'add_meta_box' ) );
		add_filter( 'woocommerce_order_actions', array( __CLASS__, 'order_actions' ), 10, 2 );
		add_action( 'woocommerce_order_action_reckon_wc_queue', array( __CLASS__, 'action_queue' ) );
		add_action( 'woocommerce_order_action_reckon_wc_confirm_retry', array( __CLASS__, 'action_confirm_retry' ) );
		add_action( 'woocommerce_order_action_reckon_wc_confirm_customer_retry', array( __CLASS__, 'action_confirm_customer_retry' ) );
		add_action( 'woocommerce_order_action_reckon_wc_mark_reviewed', array( __CLASS__, 'action_mark_reviewed' ) );
		add_action( 'woocommerce_order_action_reckon_wc_retry_verification', array( __CLASS__, 'action_retry_verification' ) );
		add_action( 'woocommerce_process_shop_order_meta', array( __CLASS__, 'save_link_invoice' ), 60, 2 );
		add_action( 'woocommerce_process_shop_order_meta', array( __CLASS__, 'save_link_customer' ), 60, 2 );

		// Orders list: HPOS and legacy screens.
		add_filter( 'manage_' . self::HPOS_SCREEN . '_columns', array( __CLASS__, 'add_column' ) );
		add_action( 'manage_' . self::HPOS_SCREEN . '_custom_column', array( __CLASS__, 'render_column' ), 10, 2 );
		add_filter( 'manage_edit-shop_order_columns', array( __CLASS__, 'add_column' ) );
		add_action( 'manage_shop_order_posts_custom_column', array( __CLASS__, 'render_column' ), 10, 2 );
		add_filter( 'bulk_actions-' . self::HPOS_SCREEN, array( __CLASS__, 'bulk_actions' ) );
		add_filter( 'handle_bulk_actions-' . self::HPOS_SCREEN, array( __CLASS__, 'handle_bulk' ), 10, 3 );
		add_filter( 'bulk_actions-edit-shop_order', array( __CLASS__, 'bulk_actions' ) );
		add_filter( 'handle_bulk_actions-edit-shop_order', array( __CLASS__, 'handle_bulk' ), 10, 3 );

		add_action( 'admin_notices', array( __CLASS__, 'notices' ) );
	}

	/**
	 * Whether HPOS is the active order storage.
	 *
	 * @return bool
	 */
	public static function hpos_enabled() {
		return class_exists( '\Automattic\WooCommerce\Utilities\OrderUtil' ) && \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled();
	}

	/**
	 * Order edit screen ID for the active storage.
	 *
	 * @return string
	 */
	public static function order_screen() {
		return self::hpos_enabled() && function_exists( 'wc_get_page_screen_id' ) ? wc_get_page_screen_id( 'shop-order' ) : 'shop_order';
	}

	/**
	 * Resolve an order from a post, an order or an ID.
	 *
	 * @param mixed $object Post, order or ID.
	 * @return WC_Order|false
	 */
	private static function to_order( $object ) {
		if ( $object instanceof WC_Order ) {
			return $object;
		}
		if ( is_object( $object ) && isset( $object->ID ) ) {
			return wc_get_order( $object->ID );
		}
		return is_numeric( $object ) ? wc_get_order( (int) $object ) : false;
	}

	/**
	 * Register the meta box.
	 */
	public static function add_meta_box() {
		add_meta_box( 'reckon-wc-order', __( 'Reckon One', 'sparxsync-accounting-integration-for-reckon-one' ), array( __CLASS__, 'render_meta_box' ), self::order_screen(), 'side', 'default' );
	}

	/**
	 * Meta box content.
	 *
	 * @param WP_Post|WC_Order $object Order or post.
	 */
	public static function render_meta_box( $object ) {
		$order = self::to_order( $object );
		if ( ! $order || ! current_user_can( self::CAPABILITY ) ) {
			return;
		}
		$s      = Reckon_WC_Order_State::summary( $order );
		$labels = Reckon_WC_Order_State::labels();
		$book   = Reckon_WC_Settings::get( Reckon_WC_Settings::OPTION_BOOK );

		$rows = array(
			__( 'Status', 'sparxsync-accounting-integration-for-reckon-one' ) => $labels[ $s['state'] ],
		);
		if ( '' !== $s['invoice_id'] ) {
			$rows[ __( 'Reckon invoice ID', 'sparxsync-accounting-integration-for-reckon-one' ) ] = $s['invoice_id'];
		}
		if ( '' !== $s['book_id'] ) {
			$rows[ __( 'Destination book', 'sparxsync-accounting-integration-for-reckon-one' ) ] = $s['book_id'] === $book['book_id'] && '' !== $book['book_name'] ? $book['book_name'] : $s['book_id'];
		} elseif ( '' !== $s['invoice_id'] ) {
			$rows[ __( 'Destination book', 'sparxsync-accounting-integration-for-reckon-one' ) ] = __( 'Unknown (synchronized by version 1.x)', 'sparxsync-accounting-integration-for-reckon-one' );
		}
		if ( '' !== $s['reference'] ) {
			$rows[ __( 'Reference', 'sparxsync-accounting-integration-for-reckon-one' ) ] = $s['reference'];
		}
		if ( '' !== $s['customer_id'] ) {
			$rows[ __( 'Reckon customer ID', 'sparxsync-accounting-integration-for-reckon-one' ) ] = $s['customer_id'];
		}
		if ( $s['attempts'] > 0 ) {
			/* translators: 1: attempts, 2: maximum. */
			$rows[ __( 'Attempts', 'sparxsync-accounting-integration-for-reckon-one' ) ]     = sprintf( __( '%1$d of %2$d', 'sparxsync-accounting-integration-for-reckon-one' ), $s['attempts'], Reckon_WC_Sync::MAX_ATTEMPTS );
			$rows[ __( 'Last attempt', 'sparxsync-accounting-integration-for-reckon-one' ) ] = Reckon_WC_Admin::format_time( $s['last_attempt_at'] );
		}
		if ( $s['next_attempt_at'] > 0 && in_array( $s['state'], array( Reckon_WC_Order_State::QUEUED, Reckon_WC_Order_State::IN_PROGRESS ), true ) ) {
			$rows[ __( 'Next attempt', 'sparxsync-accounting-integration-for-reckon-one' ) ] = Reckon_WC_Admin::format_time( $s['next_attempt_at'] ) . ' ' . __( '(when the site scheduler runs)', 'sparxsync-accounting-integration-for-reckon-one' );
		}
		if ( $s['synced_at'] > 0 ) {
			$rows[ __( 'Synchronized', 'sparxsync-accounting-integration-for-reckon-one' ) ] = Reckon_WC_Admin::format_time( $s['synced_at'] );
		}
		if ( '' !== $s['remote_status'] ) {
			/* translators: 1: Reckon invoice status, 2: date and time. */
			$rows[ __( 'Status in Reckon', 'sparxsync-accounting-integration-for-reckon-one' ) ] = sprintf( __( '%1$s (checked %2$s)', 'sparxsync-accounting-integration-for-reckon-one' ), Reckon_WC_Payment_Status::label( $s['remote_status'] ), Reckon_WC_Admin::format_time( $s['remote_checked_at'] ) );
		}
		if ( '' !== $s['totals_verified'] ) {
			$verified                                   = array(
				'yes'        => __( 'Totals match Reckon', 'sparxsync-accounting-integration-for-reckon-one' ),
				'mismatch'   => __( 'Totals differ from Reckon', 'sparxsync-accounting-integration-for-reckon-one' ),
				'unverified' => __( 'Totals not verified', 'sparxsync-accounting-integration-for-reckon-one' ),
			);
			$rows[ __( 'Verification', 'sparxsync-accounting-integration-for-reckon-one' ) ] = isset( $verified[ $s['totals_verified'] ] ) ? $verified[ $s['totals_verified'] ] : $s['totals_verified'];
		}
		if ( ! empty( $s['last_error']['message'] ) && Reckon_WC_Order_State::SYNCED !== $s['state'] ) {
			$rows[ __( 'Last error', 'sparxsync-accounting-integration-for-reckon-one' ) ] = $s['last_error']['message'] . ( ! empty( $s['last_error']['http_status'] ) ? ' (HTTP ' . (int) $s['last_error']['http_status'] . ')' : '' );
		}
		if ( ! empty( $s['accounting_review']['reason'] ) ) {
			$rows[ __( 'Accounting review', 'sparxsync-accounting-integration-for-reckon-one' ) ] = __( 'Refunded or cancelled after synchronization. Review the invoice in Reckon.', 'sparxsync-accounting-integration-for-reckon-one' );
		}

		echo '<dl class="reckon-wc-summary">';
		foreach ( $rows as $label => $value ) {
			echo '<dt><strong>' . esc_html( $label ) . '</strong></dt><dd style="margin:0 0 6px;word-break:break-word;">' . esc_html( $value ) . '</dd>';
		}
		echo '</dl>';

		if ( '' === $s['invoice_id'] && in_array( $s['state'], array( Reckon_WC_Order_State::NEEDS_REVIEW, Reckon_WC_Order_State::FAILED ), true ) ) {
			wp_nonce_field( 'reckon_wc_link_invoice_' . $order->get_id(), 'reckon_wc_link_nonce' );
			echo '<p><label for="reckon-wc-link-invoice">' . esc_html__( 'Link an existing Reckon invoice ID', 'sparxsync-accounting-integration-for-reckon-one' ) . '</label>';
			echo '<input type="text" id="reckon-wc-link-invoice" name="reckon_wc_link_invoice_id" class="widefat" autocomplete="off" placeholder="00000000-0000-0000-0000-000000000000" /></p>';
			echo '<p class="description">' . esc_html__( 'Use this when the invoice already exists in Reckon. It is verified with Reckon when the order is updated.', 'sparxsync-accounting-integration-for-reckon-one' ) . '</p>';
		}
		if ( Reckon_WC_Order_State::NEEDS_REVIEW === $s['state'] && 'customer_create_unknown' === (string) $order->get_meta( Reckon_WC_Order_State::REVIEW_REASON, true ) ) {
			wp_nonce_field( 'reckon_wc_link_customer_' . $order->get_id(), 'reckon_wc_link_customer_nonce' );
			echo '<p><label for="reckon-wc-link-customer">' . esc_html__( 'Link a Reckon customer ID', 'sparxsync-accounting-integration-for-reckon-one' ) . '</label>';
			echo '<input type="text" id="reckon-wc-link-customer" name="reckon_wc_link_customer_id" class="widefat" autocomplete="off" placeholder="00000000-0000-0000-0000-000000000000" /></p>';
			echo '<p class="description">' . esc_html__( 'Use this when the customer was already created in Reckon. It is verified with Reckon when the order is updated.', 'sparxsync-accounting-integration-for-reckon-one' ) . '</p>';
		}
		if ( '' === $s['invoice_id'] ) {
			Reckon_WC_Invoice_Preview::render( $order );
		}
		echo '<p class="description">' . esc_html__( 'Use the "Order actions" menu to queue, retry or resolve synchronization.', 'sparxsync-accounting-integration-for-reckon-one' ) . '</p>';
	}

	/**
	 * Add entries to the native Order actions menu.
	 *
	 * @param array         $actions Actions.
	 * @param WC_Order|null $order   Order.
	 * @return array
	 */
	public static function order_actions( $actions, $order = null ) {
		if ( ! $order instanceof WC_Order ) {
			global $theorder;
			$order = $theorder instanceof WC_Order ? $theorder : null;
		}
		if ( ! $order || ! current_user_can( self::CAPABILITY ) ) {
			return $actions;
		}
		$state   = Reckon_WC_Order_State::get_state( $order );
		$invoice = Reckon_WC_Order_State::get_invoice_id( $order );
		if ( in_array( $state, array( Reckon_WC_Order_State::NOT_QUEUED, Reckon_WC_Order_State::FAILED ), true ) ) {
			$actions['reckon_wc_queue'] = Reckon_WC_Order_State::FAILED === $state ? __( 'Reckon One: retry invoice sync', 'sparxsync-accounting-integration-for-reckon-one' ) : __( 'Reckon One: queue invoice sync', 'sparxsync-accounting-integration-for-reckon-one' );
		}
		if ( Reckon_WC_Order_State::NEEDS_REVIEW === $state && '' === $invoice ) {
			if ( 'customer_create_unknown' === (string) $order->get_meta( Reckon_WC_Order_State::REVIEW_REASON, true ) ) {
				$actions['reckon_wc_confirm_customer_retry'] = __( 'Reckon One: confirm no customer was created and retry', 'sparxsync-accounting-integration-for-reckon-one' );
			} else {
				$actions['reckon_wc_confirm_retry'] = __( 'Reckon One: confirm no Reckon invoice exists and retry', 'sparxsync-accounting-integration-for-reckon-one' );
			}
		}
		if ( ( Reckon_WC_Order_State::NEEDS_REVIEW === $state && '' !== $invoice ) || $order->get_meta( Reckon_WC_Order_State::ACCOUNTING_REVIEW, true ) ) {
			$actions['reckon_wc_mark_reviewed'] = __( 'Reckon One: mark review complete', 'sparxsync-accounting-integration-for-reckon-one' );
		}
		if ( '' !== $invoice && is_array( $order->get_meta( Reckon_WC_Order_State::EXPORT_RECORD, true ) ) && in_array( $state, array( Reckon_WC_Order_State::VERIFY_PENDING, Reckon_WC_Order_State::NEEDS_REVIEW, Reckon_WC_Order_State::LINKED_UNVERIFIED ), true ) ) {
			$actions['reckon_wc_retry_verification'] = __( 'Reckon One: retry invoice verification', 'sparxsync-accounting-integration-for-reckon-one' );
		}
		return $actions;
	}

	/**
	 * Order action: queue or retry.
	 *
	 * @param WC_Order $order Order.
	 */
	public static function action_queue( $order ) {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			return;
		}
		Reckon_WC_Admin::notice_for_queue_result( $order, Reckon_WC_Sync::queue_order( $order, 'manual' ) );
	}

	/**
	 * Order action: administrator confirmed no invoice exists.
	 *
	 * @param WC_Order $order Order.
	 */
	public static function action_confirm_retry( $order ) {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			return;
		}
		Reckon_WC_Admin::notice_for_queue_result( $order, Reckon_WC_Sync::confirm_no_invoice_and_retry( $order ) );
	}

	/**
	 * Order action: administrator confirmed no customer was created.
	 *
	 * @param WC_Order $order Order.
	 */
	public static function action_confirm_customer_retry( $order ) {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			return;
		}
		Reckon_WC_Admin::notice_for_queue_result( $order, Reckon_WC_Sync::confirm_no_customer_and_retry( $order ) );
	}

	/**
	 * Order action: mark review complete.
	 *
	 * @param WC_Order $order Order.
	 */
	public static function action_mark_reviewed( $order ) {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			return;
		}
		$result = Reckon_WC_Sync::mark_reviewed( $order );
		if ( is_wp_error( $result ) ) {
			Reckon_WC_Settings::add_notice( 'error', $result->get_error_message() );
		} else {
			Reckon_WC_Settings::add_notice( 'success', __( 'Reckon review marked complete.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}
	}

	/**
	 * Order action: read-only verification retry.
	 *
	 * @param WC_Order $order Order.
	 */
	public static function action_retry_verification( $order ) {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			return;
		}
		$result = Reckon_WC_Sync::retry_verification( $order );
		if ( is_wp_error( $result ) ) {
			Reckon_WC_Settings::add_notice( 'error', $result->get_error_message() );
		} else {
			Reckon_WC_Settings::add_notice( 'success', __( 'Invoice verification was re-run.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}
	}

	/**
	 * Save handler for the "link existing invoice" field.
	 *
	 * @param int   $order_id Order ID.
	 * @param mixed $object   Post or order.
	 */
	public static function save_link_invoice( $order_id, $object = null ) {
		if ( empty( $_POST['reckon_wc_link_invoice_id'] ) || ! current_user_can( self::CAPABILITY ) ) {
			return;
		}
		$nonce = isset( $_POST['reckon_wc_link_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['reckon_wc_link_nonce'] ) ) : '';
		if ( ! wp_verify_nonce( $nonce, 'reckon_wc_link_invoice_' . (int) $order_id ) ) {
			return;
		}
		$invoice_id = sanitize_text_field( wp_unslash( $_POST['reckon_wc_link_invoice_id'] ) );
		$order      = wc_get_order( $order_id );
		if ( ! $order ) {
			return;
		}
		$result = Reckon_WC_Sync::link_existing_invoice( $order, $invoice_id );
		if ( is_wp_error( $result ) ) {
			Reckon_WC_Settings::add_notice( 'error', __( 'The Reckon invoice was not linked:', 'sparxsync-accounting-integration-for-reckon-one' ) . ' ' . $result->get_error_message() );
		} else {
			Reckon_WC_Settings::add_notice( 'success', __( 'The Reckon invoice was verified and linked.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}
	}

	/**
	 * Save handler for the "link existing customer" field.
	 *
	 * @param int   $order_id Order ID.
	 * @param mixed $object   Post or order.
	 */
	public static function save_link_customer( $order_id, $object = null ) {
		if ( empty( $_POST['reckon_wc_link_customer_id'] ) || ! current_user_can( self::CAPABILITY ) ) {
			return;
		}
		$nonce = isset( $_POST['reckon_wc_link_customer_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['reckon_wc_link_customer_nonce'] ) ) : '';
		if ( ! wp_verify_nonce( $nonce, 'reckon_wc_link_customer_' . (int) $order_id ) ) {
			return;
		}
		$customer_id = sanitize_text_field( wp_unslash( $_POST['reckon_wc_link_customer_id'] ) );
		$order       = wc_get_order( $order_id );
		if ( ! $order ) {
			return;
		}
		$result = Reckon_WC_Sync::link_existing_customer( $order, $customer_id );
		if ( is_wp_error( $result ) ) {
			Reckon_WC_Settings::add_notice( 'error', __( 'The Reckon customer was not linked:', 'sparxsync-accounting-integration-for-reckon-one' ) . ' ' . $result->get_error_message() );
		} else {
			Reckon_WC_Settings::add_notice( 'success', __( 'The Reckon customer was verified and linked. Queue the order again to continue.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}
	}

	/**
	 * Add the list column.
	 *
	 * @param array $columns Columns.
	 * @return array
	 */
	public static function add_column( $columns ) {
		$out = array();
		foreach ( $columns as $key => $label ) {
			if ( 'wc_actions' === $key ) {
				$out['reckon_wc'] = __( 'Reckon', 'sparxsync-accounting-integration-for-reckon-one' );
			}
			$out[ $key ] = $label;
		}
		if ( ! isset( $out['reckon_wc'] ) ) {
			$out['reckon_wc'] = __( 'Reckon', 'sparxsync-accounting-integration-for-reckon-one' );
		}
		return $out;
	}

	/**
	 * Render the list column (HPOS passes an order, legacy passes a post ID).
	 *
	 * @param string $column Column.
	 * @param mixed  $object Order or post ID.
	 */
	public static function render_column( $column, $object ) {
		if ( 'reckon_wc' !== $column ) {
			return;
		}
		$order = self::to_order( $object );
		if ( ! $order ) {
			return;
		}
		$state   = Reckon_WC_Order_State::get_state( $order );
		$classes = array(
			Reckon_WC_Order_State::NOT_QUEUED        => '',
			Reckon_WC_Order_State::QUEUED            => 'status-processing',
			Reckon_WC_Order_State::IN_PROGRESS       => 'status-processing',
			Reckon_WC_Order_State::VERIFY_PENDING    => 'status-processing',
			Reckon_WC_Order_State::SYNCED            => 'status-completed',
			Reckon_WC_Order_State::LINKED_UNVERIFIED => 'status-on-hold',
			Reckon_WC_Order_State::MANUAL_REVIEWED   => 'status-on-hold',
			Reckon_WC_Order_State::FAILED            => 'status-failed',
			Reckon_WC_Order_State::NEEDS_REVIEW      => 'status-on-hold',
		);
		if ( Reckon_WC_Order_State::NOT_QUEUED === $state ) {
			echo '<span aria-hidden="true">–</span>';
			return;
		}
		$labels = Reckon_WC_Order_State::labels();
		echo '<mark class="order-status ' . esc_attr( $classes[ $state ] ) . '"><span>' . esc_html( $labels[ $state ] ) . '</span></mark>';
		if ( (int) $order->get_meta( Reckon_WC_Order_State::PAID_AT, true ) > 0 ) {
			echo '<br /><small style="color:#1e6b2a;font-weight:600;">' . esc_html__( 'Paid in Reckon', 'sparxsync-accounting-integration-for-reckon-one' ) . '</small>';
		}
	}

	/**
	 * Add the bulk action.
	 *
	 * @param array $actions Actions.
	 * @return array
	 */
	public static function bulk_actions( $actions ) {
		if ( current_user_can( self::CAPABILITY ) ) {
			$actions['reckon_wc_queue'] = __( 'Queue Reckon One sync', 'sparxsync-accounting-integration-for-reckon-one' );
		}
		return $actions;
	}

	/**
	 * Handle the bulk action. The list table verifies its own nonce before this filter runs.
	 *
	 * @param string $redirect Redirect URL.
	 * @param string $action   Action.
	 * @param int[]  $ids      Order IDs.
	 * @return string
	 */
	public static function handle_bulk( $redirect, $action, $ids ) {
		if ( 'reckon_wc_queue' !== $action || ! current_user_can( self::CAPABILITY ) ) {
			return $redirect;
		}
		$counts = array(
			'queued'  => 0,
			'skipped' => 0,
			'errors'  => 0,
		);
		foreach ( array_slice( array_map( 'absint', (array) $ids ), 0, 100 ) as $id ) {
			$order = wc_get_order( $id );
			if ( ! $order ) {
				continue;
			}
			$result = Reckon_WC_Sync::queue_order( $order, 'manual' );
			if ( is_wp_error( $result ) ) {
				++$counts['errors'];
			} elseif ( 'queued' === $result ) {
				++$counts['queued'];
			} else {
				++$counts['skipped'];
			}
		}
		/* translators: 1: queued, 2: skipped, 3: errors. */
		Reckon_WC_Settings::add_notice( $counts['errors'] ? 'warning' : 'success', sprintf( __( 'Reckon One: %1$d orders queued, %2$d already queued or synchronized, %3$d could not be queued (open the orders for details).', 'sparxsync-accounting-integration-for-reckon-one' ), $counts['queued'], $counts['skipped'], $counts['errors'] ) );
		return $redirect;
	}

	/**
	 * Show queued notices on order screens.
	 */
	public static function notices() {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen || ! in_array( $screen->id, array( self::HPOS_SCREEN, 'shop_order', 'edit-shop_order' ), true ) ) {
			return;
		}
		foreach ( Reckon_WC_Settings::pop_notices() as $notice ) {
			printf( '<div class="notice notice-%1$s is-dismissible"><p>%2$s</p></div>', esc_attr( $notice['type'] ), esc_html( $notice['message'] ) );
		}
	}
}
