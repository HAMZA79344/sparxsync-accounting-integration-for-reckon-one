<?php
/**
 * Reckon API Handler Class
 *
 * HTTP client for the Reckon One API v2. Contract source: the official Swagger
 * specification at https://api-v2.reckonone.com/swagger/V2/swagger.json and the
 * Reckon help centre articles on paging, filtering and subscription keys.
 *
 * Every method returns data or a WP_Error. WP_Error data always contains:
 * - status      int  HTTP status (0 for transport errors or local failures).
 * - retryable   bool Whether the same request may succeed later.
 * - outcome     string "not_sent" (request never reached Reckon), "rejected"
 *               (Reckon refused it without creating anything) or "unknown"
 *               (Reckon may have processed it).
 * - retry_after int|null Seconds from a Retry-After header.
 *
 * @package Reckon_WC
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Reckon_WC_API {

	/**
	 * Identity server endpoints (from https://identity.reckon.com/.well-known/openid-configuration).
	 */
	const AUTH_URL       = 'https://identity.reckon.com/connect/authorize';
	const TOKEN_URL      = 'https://identity.reckon.com/connect/token';
	const REVOCATION_URL = 'https://identity.reckon.com/connect/revocation';

	/**
	 * API base URL (Swagger "servers").
	 */
	const API_BASE_URL = 'https://api-v2.reckonone.com';

	/**
	 * Header name for the Azure API Management subscription key, as shown in
	 * Reckon's "Subscription key" help article.
	 */
	const SUBSCRIPTION_HEADER = 'Ocp-Apim-Subscription-Key';

	const DEFAULT_TIMEOUT = 20;
	const CREATE_TIMEOUT  = 30;
	const PER_PAGE        = 100;

	/**
	 * cURL errors raised before any request bytes reach the server.
	 *
	 * @var int[]
	 */
	const NOT_SENT_CURL_ERRORS = array( 6, 7, 35, 60 );

	/**
	 * Whether a value is a GUID.
	 *
	 * @param mixed $value Value.
	 * @return bool
	 */
	public static function is_guid( $value ) {
		return Reckon_WC_Settings::is_guid( $value );
	}

	/**
	 * Build a WP_Error with the standard data keys.
	 *
	 * @param string $code    Code.
	 * @param string $message Message.
	 * @param array  $data    Data overrides.
	 * @return WP_Error
	 */
	public static function error( $code, $message, $data = array() ) {
		return new WP_Error(
			$code,
			$message,
			array_merge(
				array(
					'status'            => 0,
					'retryable'         => false,
					'outcome'           => 'not_sent',
					'retry_after'       => null,
					'reckon_error_code' => '',
				),
				$data
			)
		);
	}

	/**
	 * Read one data key from an error produced by this client.
	 *
	 * @param WP_Error $error Error.
	 * @param string   $key   Key.
	 * @param mixed    $default Default.
	 * @return mixed
	 */
	public static function error_data( $error, $key, $default = null ) {
		$data = is_wp_error( $error ) ? $error->get_error_data() : null;
		return is_array( $data ) && array_key_exists( $key, $data ) ? $data[ $key ] : $default;
	}

	/**
	 * Make an API request.
	 *
	 * @param string $method HTTP method.
	 * @param string $path   Path beginning with "/".
	 * @param array  $args   query (array), body (array|null), timeout (int).
	 * @return array|WP_Error Array with status, data and headers (link, x-total-count).
	 */
	public static function request( $method, $path, $args = array() ) {
		$args   = array_merge(
			array(
				'query'      => array(),
				'body'       => null,
				'timeout'    => self::DEFAULT_TIMEOUT,
				'retry_auth' => true,
			),
			is_array( $args ) ? $args : array()
		);
		$method = strtoupper( (string) $method );

		if ( ! in_array( $method, array( 'GET', 'POST', 'PUT', 'PATCH', 'DELETE' ), true ) ) {
			return self::error( 'reckon_wc_invalid_request', 'Unsupported HTTP method.' );
		}
		if ( ! is_string( $path ) || '' === $path || '/' !== $path[0] || preg_match( '#\s|\.\.|//|[?\#]#', $path ) ) {
			return self::error( 'reckon_wc_invalid_request', 'Invalid API path.' );
		}

		$subscription_key = Reckon_WC_Settings::get_credential( 'subscription_key' );
		if ( '' === $subscription_key ) {
			return self::error( 'reckon_wc_missing_credentials', __( 'The Reckon subscription key is not configured.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}

		$token = Reckon_WC_OAuth::get_access_token( isset( $args['rejected_token'] ) ? $args['rejected_token'] : null );
		if ( is_wp_error( $token ) ) {
			return $token;
		}

		$url = self::API_BASE_URL . $path;
		if ( ! empty( $args['query'] ) ) {
			$url .= '?' . http_build_query( $args['query'], '', '&', PHP_QUERY_RFC3986 );
		}

		$headers = array(
			'Authorization'           => 'Bearer ' . $token,
			self::SUBSCRIPTION_HEADER => $subscription_key,
			'Accept'                  => 'application/json',
		);
		$request = array(
			'method'      => $method,
			'timeout'     => max( 1, (int) $args['timeout'] ),
			'redirection' => 0,
			'headers'     => $headers,
		);
		if ( null !== $args['body'] ) {
			$json = wp_json_encode( $args['body'] );
			if ( false === $json ) {
				return self::error( 'reckon_wc_json_encode_failed', __( 'The request could not be encoded as JSON.', 'sparxsync-accounting-integration-for-reckon-one' ) );
			}
			$request['headers']['Content-Type'] = 'application/json';
			$request['body']                    = $json;
		}

		$result = self::parse_response( wp_remote_request( $url, $request ) );

		if ( is_wp_error( $result ) && 'reckon_wc_unauthorized' === $result->get_error_code() && $args['retry_auth'] ) {
			// A 401 is returned before the request is processed, so one retry with a refreshed token is safe.
			$args['retry_auth']     = false;
			$args['rejected_token'] = $token;
			return self::request( $method, $path, $args );
		}

		return $result;
	}

	/**
	 * Convert a wp_remote_request() result into data or a classified WP_Error.
	 *
	 * @param array|WP_Error $response Response.
	 * @return array|WP_Error
	 */
	public static function parse_response( $response ) {
		if ( is_wp_error( $response ) ) {
			$message = $response->get_error_message();
			$errno   = preg_match( '/cURL error (\d+)/', $message, $m ) ? (int) $m[1] : 0;
			$outcome = in_array( $errno, self::NOT_SENT_CURL_ERRORS, true ) ? 'not_sent' : 'unknown';
			return self::error(
				'reckon_wc_transport',
				/* translators: %s: network error text. */
				sprintf( __( 'Network error while contacting Reckon: %s', 'sparxsync-accounting-integration-for-reckon-one' ), Reckon_WC_Logger::redact( self::truncate( $message ) ) ),
				array(
					'retryable' => true,
					'outcome'   => $outcome,
				)
			);
		}

		$status  = (int) wp_remote_retrieve_response_code( $response );
		$body    = (string) wp_remote_retrieve_body( $response );
		$headers = array(
			'link'          => (string) wp_remote_retrieve_header( $response, 'link' ),
			'x-total-count' => (string) wp_remote_retrieve_header( $response, 'x-total-count' ),
			'retry-after'   => (string) wp_remote_retrieve_header( $response, 'retry-after' ),
		);

		$data       = null;
		$json_valid = true;
		if ( '' !== trim( $body ) ) {
			$data       = json_decode( $body, true );
			$json_valid = JSON_ERROR_NONE === json_last_error();
		}

		if ( $status >= 200 && $status < 300 ) {
			if ( ! $json_valid ) {
				return self::error(
					'reckon_wc_invalid_json',
					__( 'Reckon returned a response that is not valid JSON.', 'sparxsync-accounting-integration-for-reckon-one' ),
					array(
						'status'    => $status,
						'retryable' => true,
						'outcome'   => 'unknown',
					)
				);
			}
			return array(
				'status'  => $status,
				'data'    => $data,
				'headers' => $headers,
			);
		}

		$reckon_code = '';
		$detail      = '';
		if ( $json_valid && is_array( $data ) ) {
			$reckon_code = isset( $data['errorCode'] ) && is_scalar( $data['errorCode'] ) ? sanitize_key( (string) $data['errorCode'] ) : '';
			$parts       = array();
			if ( isset( $data['message'] ) && is_scalar( $data['message'] ) ) {
				$parts[] = (string) $data['message'];
			}
			if ( isset( $data['errors'] ) && is_array( $data['errors'] ) ) {
				foreach ( array_slice( $data['errors'], 0, 5 ) as $err ) {
					if ( is_array( $err ) ) {
						$location = isset( $err['location'] ) && is_scalar( $err['location'] ) ? (string) $err['location'] : '';
						$msg      = isset( $err['message'] ) && is_scalar( $err['message'] ) ? (string) $err['message'] : '';
						$parts[]  = trim( $location . ': ' . $msg, ': ' );
					}
				}
			}
			$detail = Reckon_WC_Logger::redact( self::truncate( implode( ' | ', array_filter( $parts ) ) ) );
		}

		$retry_after = self::parse_retry_after( $headers['retry-after'] );
		$base        = array(
			'status'            => $status,
			'retry_after'       => $retry_after,
			'reckon_error_code' => $reckon_code,
		);
		$suffix      = '' === $detail ? '' : ' ' . $detail;

		if ( 401 === $status ) {
			return self::error( 'reckon_wc_unauthorized', __( 'Reckon rejected the credentials (HTTP 401). Check the subscription key or reconnect.', 'sparxsync-accounting-integration-for-reckon-one' ) . $suffix, array_merge( $base, array( 'outcome' => 'rejected' ) ) );
		}
		if ( 403 === $status ) {
			return self::error( 'reckon_wc_forbidden', __( 'The connected Reckon user does not have permission for this action (HTTP 403).', 'sparxsync-accounting-integration-for-reckon-one' ) . $suffix, array_merge( $base, array( 'outcome' => 'rejected' ) ) );
		}
		if ( 404 === $status ) {
			return self::error( 'reckon_wc_not_found', __( 'Reckon could not find the requested record (HTTP 404).', 'sparxsync-accounting-integration-for-reckon-one' ) . $suffix, array_merge( $base, array( 'outcome' => 'rejected' ) ) );
		}
		if ( in_array( $status, array( 400, 409, 422 ), true ) ) {
			/* translators: %d: HTTP status. */
			return self::error( 'reckon_wc_validation', sprintf( __( 'Reckon rejected the request as invalid (HTTP %d).', 'sparxsync-accounting-integration-for-reckon-one' ), $status ) . $suffix, array_merge( $base, array( 'outcome' => 'rejected' ) ) );
		}
		if ( 429 === $status ) {
			return self::error(
				'reckon_wc_rate_limited',
				__( 'Reckon is rate limiting requests (HTTP 429).', 'sparxsync-accounting-integration-for-reckon-one' ),
				array_merge(
					$base,
					array(
						'retryable' => true,
						'outcome'   => 'rejected',
					)
				)
			);
		}
		if ( 408 === $status || $status >= 500 ) {
			return self::error(
				'reckon_wc_server_error',
				/* translators: %d: HTTP status. */
				sprintf( __( 'Reckon returned a server error (HTTP %d).', 'sparxsync-accounting-integration-for-reckon-one' ), $status ) . $suffix,
				array_merge(
					$base,
					array(
						'retryable' => true,
						'outcome'   => 'unknown',
					)
				)
			);
		}
		/* translators: %d: HTTP status. */
		return self::error( 'reckon_wc_unexpected_status', sprintf( __( 'Reckon returned an unexpected HTTP status (%d).', 'sparxsync-accounting-integration-for-reckon-one' ), $status ), array_merge( $base, array( 'outcome' => 'unknown' ) ) );
	}

	/**
	 * Parse a Retry-After header (seconds or HTTP date).
	 *
	 * @param string $value Header value.
	 * @return int|null
	 */
	public static function parse_retry_after( $value ) {
		$value = trim( (string) $value );
		if ( '' === $value ) {
			return null;
		}
		if ( ctype_digit( $value ) ) {
			return min( 86400, (int) $value );
		}
		$time = strtotime( $value );
		if ( false === $time ) {
			return null;
		}
		return max( 0, min( 86400, $time - time() ) );
	}

	/**
	 * Fetch every page of a list endpoint.
	 *
	 * Paging follows the documented page/perpage parameters and the Link header.
	 * When no Link header is returned, a short page ends the list. Returns an
	 * error rather than a partial list when the page limit is reached.
	 *
	 * @param string $path          Path.
	 * @param array  $query         Query parameters.
	 * @param int    $max_pages     Page limit.
	 * @param bool   $empty_on_404  Treat 404 on the first page as an empty list.
	 * @return array|WP_Error List of records.
	 */
	public static function get_list( $path, $query = array(), $max_pages = 20, $empty_on_404 = false ) {
		$items = array();
		$seen  = array();
		for ( $page = 1; $page <= $max_pages; $page++ ) {
			$response = self::request(
				'GET',
				$path,
				array(
					'query' => array_merge(
						$query,
						array(
							'page'    => $page,
							'perpage' => self::PER_PAGE,
						)
					),
				)
			);
			if ( is_wp_error( $response ) ) {
				if ( $empty_on_404 && 1 === $page && 'reckon_wc_not_found' === $response->get_error_code() ) {
					return array();
				}
				return $response;
			}
			$data = $response['data'];
			if ( null === $data ) {
				// A 2xx response with no body is malformed, not an empty collection.
				return self::error( 'reckon_wc_invalid_response', __( 'Reckon returned an empty response body for a list request.', 'sparxsync-accounting-integration-for-reckon-one' ), array( 'status' => $response['status'], 'retryable' => true, 'outcome' => 'rejected' ) );
			}
			if ( ! is_array( $data ) || ! array_key_exists( 'list', $data ) || ( null !== $data['list'] && ! is_array( $data['list'] ) ) ) {
				return self::error( 'reckon_wc_invalid_response', __( 'Reckon returned a list response in an unexpected format.', 'sparxsync-accounting-integration-for-reckon-one' ), array( 'status' => $response['status'], 'retryable' => true, 'outcome' => 'rejected' ) );
			}
			$list  = null === $data['list'] ? array() : $data['list'];
			$added = 0;
			foreach ( $list as $record ) {
				if ( ! is_array( $record ) ) {
					return self::error( 'reckon_wc_invalid_response', __( 'Reckon returned a list entry in an unexpected format.', 'sparxsync-accounting-integration-for-reckon-one' ), array( 'status' => $response['status'], 'retryable' => true, 'outcome' => 'rejected' ) );
				}
				$key = isset( $record['id'] ) && is_scalar( $record['id'] ) ? strtolower( (string) $record['id'] ) : md5( serialize( $record ) ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.serialize_serialize
				if ( isset( $seen[ $key ] ) ) {
					continue;
				}
				$seen[ $key ] = true;
				$items[]      = $record;
				++$added;
			}

			$link     = $response['headers']['link'];
			$has_next = '' !== $link && preg_match( '/rel\s*=\s*"?next"?/i', $link );
			$total    = self::parse_total_count( $response['headers']['x-total-count'] );

			if ( $has_next ) {
				if ( 0 === $added && count( $list ) > 0 ) {
					// The endpoint promised more results but repeated records already
					// seen; completeness cannot be established.
					return self::error( 'reckon_wc_repeated_page', __( 'Reckon repeated records across pages, so the list could not be read completely.', 'sparxsync-accounting-integration-for-reckon-one' ), array( 'status' => $response['status'], 'retryable' => true, 'outcome' => 'rejected' ) );
				}
				continue;
			}

			// No next page link. Prefer the documented total count when present.
			if ( false === $total ) {
				return self::error( 'reckon_wc_invalid_total_count', __( 'Reckon returned an invalid total-count header.', 'sparxsync-accounting-integration-for-reckon-one' ), array( 'status' => $response['status'], 'retryable' => true, 'outcome' => 'rejected' ) );
			}
			if ( null !== $total ) {
				if ( count( $items ) !== $total ) {
					return self::error( 'reckon_wc_incomplete_pagination', __( 'Reckon returned a number of records that does not match its reported total, so the list is incomplete.', 'sparxsync-accounting-integration-for-reckon-one' ), array( 'status' => $response['status'], 'retryable' => true, 'outcome' => 'rejected' ) );
				}
				return $items;
			}

			// Without a total count or next link, a short page is the completion signal.
			if ( count( $list ) < self::PER_PAGE ) {
				return $items;
			}
			return self::error( 'reckon_wc_incomplete_pagination', __( 'Reckon returned a full page without indicating that it is complete, so the list may be incomplete.', 'sparxsync-accounting-integration-for-reckon-one' ), array( 'status' => $response['status'], 'retryable' => true, 'outcome' => 'rejected' ) );
		}
		return self::error( 'reckon_wc_too_many_results', __( 'Reckon returned more records than this operation can safely page through.', 'sparxsync-accounting-integration-for-reckon-one' ), array( 'retryable' => false, 'outcome' => 'rejected' ) );
	}

	/**
	 * Parse the X-Total-Count header. Returns null when absent, false when present
	 * but invalid, and an integer otherwise.
	 *
	 * @param string $value Header value.
	 * @return int|false|null
	 */
	private static function parse_total_count( $value ) {
		$value = trim( (string) $value );
		if ( '' === $value ) {
			return null; // Absent.
		}
		if ( ! ctype_digit( $value ) ) {
			return false; // Present but invalid.
		}
		return (int) $value;
	}

	/**
	 * Quote a value for a Reckon filter expression.
	 *
	 * The filtering article documents single-quoted strings and the Swagger
	 * examples use double quotes. No escape syntax is documented, so a value is
	 * wrapped in whichever quote it does not contain, and values containing both
	 * quote characters, backslashes or control characters are refused.
	 *
	 * @param string $value Value.
	 * @return string|WP_Error
	 */
	public static function quote_filter_value( $value ) {
		$value = (string) $value;
		if ( '' === $value ) {
			return self::error( 'reckon_wc_unsafe_filter_value', __( 'An empty value cannot be used to search Reckon.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}
		if ( preg_match( '/[\x00-\x1F\x7F\\\\]/', $value ) ) {
			return self::error( 'reckon_wc_unsafe_filter_value', __( 'The value contains characters that cannot be used safely in a Reckon search.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}
		$single = false !== strpos( $value, "'" );
		$double = false !== strpos( $value, '"' );
		if ( $single && $double ) {
			return self::error( 'reckon_wc_unsafe_filter_value', __( 'The value contains both single and double quotes and cannot be used safely in a Reckon search.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}
		return $single ? '"' . $value . '"' : "'" . $value . "'";
	}

	/**
	 * Build an equality filter expression.
	 *
	 * @param string $field Field name.
	 * @param string $value Value.
	 * @return string|WP_Error
	 */
	public static function filter_eq( $field, $value ) {
		if ( ! preg_match( '/^[A-Za-z][A-Za-z0-9_.]*$/', (string) $field ) ) {
			return self::error( 'reckon_wc_invalid_request', 'Invalid filter field.' );
		}
		$quoted = self::quote_filter_value( $value );
		if ( is_wp_error( $quoted ) ) {
			return $quoted;
		}
		return $field . ' eq ' . $quoted;
	}

	/**
	 * Build a path under a book, validating the book ID.
	 *
	 * @param string $book_id Book ID.
	 * @param string $suffix  Suffix beginning with "/".
	 * @return string|WP_Error
	 */
	private static function book_path( $book_id, $suffix ) {
		if ( ! self::is_guid( $book_id ) ) {
			return self::error( 'reckon_wc_invalid_book', __( 'The Reckon book ID is not valid.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}
		return '/' . strtolower( $book_id ) . $suffix;
	}

	/**
	 * Validate the id in a create response.
	 *
	 * @param array|WP_Error $response Response.
	 * @param string         $what     Record type for messages.
	 * @return string|WP_Error
	 */
	private static function created_id( $response, $what ) {
		if ( is_wp_error( $response ) ) {
			return $response;
		}
		$id = is_array( $response['data'] ) && isset( $response['data']['id'] ) && is_string( $response['data']['id'] ) ? $response['data']['id'] : '';
		if ( ! self::is_guid( $id ) ) {
			return self::error(
				'reckon_wc_invalid_response_id',
				/* translators: %s: record type. */
				sprintf( __( 'Reckon accepted the %s request but did not return a valid record ID. The record may exist in Reckon.', 'sparxsync-accounting-integration-for-reckon-one' ), $what ),
				array(
					'status'    => $response['status'],
					'retryable' => false,
					'outcome'   => 'unknown',
				)
			);
		}
		return strtolower( $id );
	}

	/**
	 * Books the connected user can access. Reckon documents 404 as "no books".
	 *
	 * @return array|WP_Error
	 */
	public static function get_books() {
		return self::get_list( '/books', array(), 5, true );
	}

	/**
	 * Countries with currency codes.
	 *
	 * @return array|WP_Error
	 */
	public static function get_countries() {
		return self::get_list( '/countries', array(), 10 );
	}

	public static function get_ledger_accounts( $book_id ) {
		$path = self::book_path( $book_id, '/ledgeraccounts' );
		return is_wp_error( $path ) ? $path : self::get_list( $path, array(), 30 );
	}

	/**
	 * Tax rates effective on a date.
	 *
	 * @param string $book_id Book ID.
	 * @param string $date    Y-m-d.
	 * @return array|WP_Error
	 */
	public static function get_tax_rates( $book_id, $date ) {
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $date ) ) {
			return self::error( 'reckon_wc_invalid_request', 'Invalid effective date.' );
		}
		$path = self::book_path( $book_id, '/taxrates/' . $date );
		return is_wp_error( $path ) ? $path : self::get_list( $path, array(), 10 );
	}

	public static function get_tax_settings( $book_id ) {
		$path = self::book_path( $book_id, '/settings/tax' );
		if ( is_wp_error( $path ) ) {
			return $path;
		}
		$response = self::request( 'GET', $path );
		if ( is_wp_error( $response ) ) {
			return $response;
		}
		if ( ! is_array( $response['data'] ) ) {
			return self::error( 'reckon_wc_invalid_response', __( 'Reckon returned tax settings in an unexpected format.', 'sparxsync-accounting-integration-for-reckon-one' ), array( 'status' => $response['status'], 'retryable' => true, 'outcome' => 'rejected' ) );
		}
		return $response['data'];
	}

	public static function get_address_types( $book_id ) {
		$path = self::book_path( $book_id, '/addresstypes' );
		return is_wp_error( $path ) ? $path : self::get_list( $path, array(), 5 );
	}

	public static function get_electronic_address_types( $book_id ) {
		$path = self::book_path( $book_id, '/electronicaddresstypes' );
		return is_wp_error( $path ) ? $path : self::get_list( $path, array(), 5 );
	}

	/**
	 * Customers whose display name equals the given name (case-sensitive, as documented).
	 *
	 * @param string $book_id Book ID.
	 * @param string $name    Name.
	 * @return array|WP_Error
	 */
	public static function find_customers_by_name( $book_id, $name ) {
		$path   = self::book_path( $book_id, '/customers' );
		$filter = self::filter_eq( 'name', $name );
		if ( is_wp_error( $path ) ) {
			return $path;
		}
		if ( is_wp_error( $filter ) ) {
			return $filter;
		}
		return self::get_list( $path, array( 'filter' => $filter ), 5 );
	}

	/**
	 * Get one customer.
	 *
	 * @param string $book_id     Book ID.
	 * @param string $customer_id Customer ID.
	 * @return array|WP_Error
	 */
	public static function get_customer( $book_id, $customer_id ) {
		if ( ! self::is_guid( $customer_id ) ) {
			return self::error( 'reckon_wc_invalid_request', 'Invalid customer ID.' );
		}
		$path = self::book_path( $book_id, '/customers/' . strtolower( $customer_id ) );
		if ( is_wp_error( $path ) ) {
			return $path;
		}
		$response = self::request( 'GET', $path );
		if ( is_wp_error( $response ) ) {
			return $response;
		}
		if ( ! is_array( $response['data'] ) || ! isset( $response['data']['id'] ) || strtolower( (string) $response['data']['id'] ) !== strtolower( $customer_id ) ) {
			return self::error( 'reckon_wc_invalid_response', __( 'Reckon returned a customer in an unexpected format.', 'sparxsync-accounting-integration-for-reckon-one' ), array( 'status' => $response['status'], 'retryable' => true, 'outcome' => 'rejected' ) );
		}
		return $response['data'];
	}

	/**
	 * Create a customer.
	 *
	 * @param string $book_id Book ID.
	 * @param array  $body    CustomerInput.
	 * @return string|WP_Error New customer ID.
	 */
	public static function create_customer( $book_id, $body ) {
		$path = self::book_path( $book_id, '/customers' );
		if ( is_wp_error( $path ) ) {
			return $path;
		}
		return self::created_id(
			self::request(
				'POST',
				$path,
				array(
					'body'    => $body,
					'timeout' => self::CREATE_TIMEOUT,
				)
			),
			__( 'customer', 'sparxsync-accounting-integration-for-reckon-one' )
		);
	}

	/**
	 * Items whose item code equals the given code.
	 *
	 * @param string $book_id Book ID.
	 * @param string $code    Item code (WooCommerce SKU).
	 * @return array|WP_Error
	 */
	public static function find_items_by_code( $book_id, $code ) {
		$path   = self::book_path( $book_id, '/items' );
		$filter = self::filter_eq( 'itemCode', $code );
		if ( is_wp_error( $path ) ) {
			return $path;
		}
		if ( is_wp_error( $filter ) ) {
			return $filter;
		}
		return self::get_list( $path, array( 'filter' => $filter ), 3 );
	}

	/**
	 * Create an invoice. No idempotency key is documented for this endpoint.
	 *
	 * @param string $book_id Book ID.
	 * @param array  $payload InvoiceInput.
	 * @return string|WP_Error New invoice ID.
	 */
	public static function create_invoice( $book_id, $payload ) {
		$path = self::book_path( $book_id, '/invoices' );
		if ( is_wp_error( $path ) ) {
			return $path;
		}
		return self::created_id(
			self::request(
				'POST',
				$path,
				array(
					'body'    => $payload,
					'timeout' => self::CREATE_TIMEOUT,
				)
			),
			__( 'invoice', 'sparxsync-accounting-integration-for-reckon-one' )
		);
	}

	/**
	 * Get one invoice.
	 *
	 * @param string $book_id    Book ID.
	 * @param string $invoice_id Invoice ID.
	 * @return array|WP_Error
	 */
	public static function get_invoice( $book_id, $invoice_id ) {
		if ( ! self::is_guid( $invoice_id ) ) {
			return self::error( 'reckon_wc_invalid_request', 'Invalid invoice ID.' );
		}
		$path = self::book_path( $book_id, '/invoices/' . strtolower( $invoice_id ) );
		if ( is_wp_error( $path ) ) {
			return $path;
		}
		$response = self::request( 'GET', $path );
		if ( is_wp_error( $response ) ) {
			return $response;
		}
		if ( ! is_array( $response['data'] ) || ! isset( $response['data']['id'] ) || strtolower( (string) $response['data']['id'] ) !== strtolower( $invoice_id ) ) {
			return self::error( 'reckon_wc_invalid_response', __( 'Reckon returned an invoice in an unexpected format.', 'sparxsync-accounting-integration-for-reckon-one' ), array( 'status' => $response['status'], 'retryable' => true, 'outcome' => 'rejected' ) );
		}
		return $response['data'];
	}

	/**
	 * Invoices whose reference exactly equals the given reference.
	 *
	 * Results are re-checked locally, so a filter that matched loosely cannot
	 * link the wrong invoice.
	 *
	 * @param string $book_id   Book ID.
	 * @param string $reference Reference.
	 * @return array|WP_Error Matching invoices.
	 */
	public static function find_invoices_by_reference( $book_id, $reference ) {
		$path   = self::book_path( $book_id, '/invoices' );
		$filter = self::filter_eq( 'reference', $reference );
		if ( is_wp_error( $path ) ) {
			return $path;
		}
		if ( is_wp_error( $filter ) ) {
			return $filter;
		}
		$list = self::get_list( $path, array( 'filter' => $filter ), 3 );
		if ( is_wp_error( $list ) ) {
			return $list;
		}
		$matches = array();
		foreach ( $list as $invoice ) {
			if ( ! isset( $invoice['reference'] ) || ! is_string( $invoice['reference'] ) || $invoice['reference'] !== $reference ) {
				continue;
			}
			// A matching reference must carry a usable ID. Silently dropping it could
			// turn an unsafe lookup into "nothing found" and permit a duplicate.
			if ( ! isset( $invoice['id'] ) || ! self::is_guid( $invoice['id'] ) ) {
				return self::error( 'reckon_wc_invalid_response', __( 'Reckon returned an invoice with this reference but without a valid ID.', 'sparxsync-accounting-integration-for-reckon-one' ), array( 'retryable' => true, 'outcome' => 'rejected' ) );
			}
			$matches[] = $invoice;
		}
		return $matches;
	}

	/**
	 * Shorten text.
	 *
	 * @param string $text Text.
	 * @return string
	 */
	private static function truncate( $text ) {
		$text = trim( preg_replace( '/\s+/', ' ', (string) $text ) );
		return strlen( $text ) > 300 ? substr( $text, 0, 297 ) . '...' : $text;
	}
}
