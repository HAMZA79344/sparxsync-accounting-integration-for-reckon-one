<?php
/**
 * Reckon Logger Handler Class
 *
 * Writes to the WooCommerce logger under the "reckon-wc" source. Messages are
 * redacted before they are written: known secrets, bearer tokens, OAuth values,
 * email addresses and long token-like strings are replaced. Context is limited
 * to a fixed list of non-personal keys.
 *
 * @package Reckon_WC
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Reckon_WC_Logger {

	const SOURCE = 'reckon-wc';

	/**
	 * Context keys that may be written to the log.
	 *
	 * @var string[]
	 */
	const CONTEXT_KEYS = array( 'operation', 'order_id', 'attempt', 'http_status', 'error_code', 'book_id', 'state', 'retry_in' );

	/**
	 * Log a message. Kept for backward compatibility with 1.x callers.
	 *
	 * @param mixed  $message Message. Arrays and objects are not dumped; only their type is noted.
	 * @param string $level   PSR-3 level understood by WC_Logger.
	 * @param array  $context Context; only CONTEXT_KEYS are kept.
	 */
	public static function log( $message, $level = 'info', $context = array() ) {
		if ( ! function_exists( 'wc_get_logger' ) ) {
			return;
		}
		if ( 'debug' === $level && ! self::debug_enabled() ) {
			return;
		}
		if ( ! in_array( $level, array( 'emergency', 'alert', 'critical', 'error', 'warning', 'notice', 'info', 'debug' ), true ) ) {
			$level = 'info';
		}
		if ( ! is_scalar( $message ) ) {
			// Never dump structures: they may hold request bodies with customer data.
			$message = sprintf( '[%s omitted from log]', is_object( $message ) ? get_class( $message ) : gettype( $message ) );
		}

		$clean_context = array( 'source' => self::SOURCE );
		foreach ( self::CONTEXT_KEYS as $key ) {
			if ( isset( $context[ $key ] ) && is_scalar( $context[ $key ] ) ) {
				$clean_context[ $key ] = self::redact( (string) $context[ $key ] );
			}
		}

		$prefix = '';
		foreach ( array( 'operation', 'order_id', 'attempt', 'http_status', 'error_code' ) as $key ) {
			if ( isset( $clean_context[ $key ] ) ) {
				$prefix .= '[' . $key . '=' . $clean_context[ $key ] . '] ';
			}
		}

		wc_get_logger()->log( $level, $prefix . self::redact( (string) $message ), $clean_context );
	}

	public static function debug( $message, $context = array() ) {
		self::log( $message, 'debug', $context );
	}

	public static function info( $message, $context = array() ) {
		self::log( $message, 'info', $context );
	}

	public static function warning( $message, $context = array() ) {
		self::log( $message, 'warning', $context );
	}

	public static function error( $message, $context = array() ) {
		self::log( $message, 'error', $context );
	}

	/**
	 * Whether debug-level entries are enabled in the plugin settings.
	 *
	 * @return bool
	 */
	public static function debug_enabled() {
		$settings = Reckon_WC_Settings::get( Reckon_WC_Settings::OPTION_SYNC );
		return ! empty( $settings['debug_logging'] );
	}

	/**
	 * Remove secrets and personal data from a string.
	 *
	 * @param string $text Text.
	 * @return string
	 */
	public static function redact( $text ) {
		$text = (string) $text;

		foreach ( self::known_secrets() as $secret ) {
			$text = str_replace( $secret, '[redacted]', $text );
		}

		$patterns = array(
			// Authorization headers and bearer/basic credentials.
			'/\b(Bearer|Basic)\s+[A-Za-z0-9\-\._~\+\/]+=*/i'                            => '$1 [redacted]',
			// key=value / "key": "value" pairs for sensitive names.
			'/\b(access_token|refresh_token|id_token|client_secret|client_id|code|state|nonce|subscription[-_]?key|ocp-apim-subscription-key|password|authorization)\b(["\']?\s*[:=]\s*["\']?)[^\s&"\',}]+/i' => '$1$2[redacted]',
			// JSON Web Tokens.
			'/\beyJ[A-Za-z0-9_\-]+\.[A-Za-z0-9_\-]+\.[A-Za-z0-9_\-]*/'                  => '[redacted-jwt]',
			// Email addresses.
			'/[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}/'                         => '[redacted-email]',
			// Long opaque token-like strings (GUIDs are protected below).
			'/\b[A-Za-z0-9_\-\.\/+]{32,}={0,2}/'                                         => '[redacted-token]',
		);

		$guids = array();
		// Protect GUIDs (Reckon ids) from the long-string rule; they identify records, not people.
		$text = preg_replace_callback(
			'/\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b/i',
			function ( $m ) use ( &$guids ) {
				$guids[] = $m[0];
				return '@@GUID' . ( count( $guids ) - 1 ) . '@@';
			},
			$text
		);
		foreach ( $patterns as $pattern => $replacement ) {
			$text = preg_replace( $pattern, $replacement, $text );
		}
		// Phone-number-like digit runs (9+ digits); ISO dates are left alone.
		$text = preg_replace_callback(
			'/\+?\d[\d\s\-()]{7,}\d/',
			function ( $m ) {
				if ( preg_match( '/^\d{4}-\d{2}-\d{2}/', $m[0] ) || strlen( preg_replace( '/\D/', '', $m[0] ) ) < 9 ) {
					return $m[0];
				}
				return '[redacted-number]';
			},
			$text
		);
		foreach ( $guids as $i => $guid ) {
			$text = str_replace( '@@GUID' . $i . '@@', $guid, $text );
		}

		return $text;
	}

	/**
	 * Currently stored secrets, so exact occurrences can be removed from any text.
	 *
	 * @return string[]
	 */
	private static function known_secrets() {
		$secrets = array();
		foreach ( array( 'client_secret', 'subscription_key' ) as $key ) {
			$secrets[] = Reckon_WC_Settings::get_credential( $key );
		}
		$tokens = get_option( 'reckon_wc_tokens', array() );
		if ( is_array( $tokens ) ) {
			foreach ( array( 'access_token', 'refresh_token' ) as $key ) {
				if ( isset( $tokens[ $key ] ) && is_string( $tokens[ $key ] ) ) {
					$secrets[] = $tokens[ $key ];
				}
			}
		}
		return array_values(
			array_filter(
				$secrets,
				function ( $s ) {
					return is_string( $s ) && strlen( $s ) >= 6;
				}
			)
		);
	}
}
