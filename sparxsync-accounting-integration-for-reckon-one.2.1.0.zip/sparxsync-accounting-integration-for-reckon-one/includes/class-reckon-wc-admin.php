<?php
/**
 * Settings page (WooCommerce > Reckon One) and its administrator actions.
 *
 * Every action requires the manage capability and a nonce, and is handled
 * through admin-post.php. The page never calls the Reckon API while rendering
 * and never prints stored secrets or tokens.
 *
 * @package Reckon_WC
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Reckon_WC_Admin {

	const TABS = array( 'dashboard', 'connection', 'book', 'sync', 'orders' );

	/**
	 * Hook suffix of the settings page, used to load the stylesheet only there.
	 *
	 * @var string
	 */
	private static $page_hook = '';

	/**
	 * Where "get help" links go. Plain links only: nothing is sent unless the
	 * administrator clicks one.
	 */
	const HELP_URL     = 'https://skillssparx.com/contact/';
	const SERVICES_URL = 'https://skillssparx.com/services/';

	/**
	 * Register hooks.
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'add_menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
		add_action( 'admin_notices', array( __CLASS__, 'global_notices' ) );
		foreach ( array( 'connect', 'disconnect', 'test_connection', 'refresh_data', 'retry_order', 'retry_failed', 'dismiss_upgrade' ) as $action ) {
			add_action( 'admin_post_reckon_wc_' . $action, array( __CLASS__, 'handle_' . $action ) );
		}
		add_action( 'update_option_' . Reckon_WC_Settings::OPTION_SYNC, array( __CLASS__, 'sync_settings_saved' ) );
		add_filter( 'plugin_action_links_' . RECKON_WC_BASENAME, array( __CLASS__, 'plugin_links' ) );
		add_filter( 'plugin_row_meta', array( __CLASS__, 'plugin_row_meta' ), 10, 2 );
	}

	/**
	 * Add the submenu under WooCommerce.
	 */
	public static function add_menu() {
		self::$page_hook = (string) add_submenu_page(
			'woocommerce',
			__( 'SparxSync for Reckon One', 'sparxsync-accounting-integration-for-reckon-one' ),
			__( 'Reckon One', 'sparxsync-accounting-integration-for-reckon-one' ),
			Reckon_WC_Settings::capability(),
			Reckon_WC_Settings::PAGE_SLUG,
			array( __CLASS__, 'render_page' )
		);
	}

	/**
	 * Load the admin stylesheet on the settings page only.
	 *
	 * @param string $hook_suffix Current admin page.
	 */
	public static function enqueue_assets( $hook_suffix ) {
		if ( '' === self::$page_hook || $hook_suffix !== self::$page_hook ) {
			return;
		}
		wp_enqueue_style( 'reckon-wc-admin', RECKON_WC_URL . 'assets/css/admin.css', array(), RECKON_WC_VERSION );
	}

	/**
	 * Settings link on the Plugins screen.
	 *
	 * @param array $links Links.
	 * @return array
	 */
	public static function plugin_links( $links ) {
		array_unshift( $links, '<a href="' . esc_url( Reckon_WC_Settings::page_url( 'dashboard' ) ) . '">' . esc_html__( 'Settings', 'sparxsync-accounting-integration-for-reckon-one' ) . '</a>' );
		return $links;
	}

	/**
	 * Help links under the plugin description on the Plugins screen.
	 *
	 * @param array  $links Links.
	 * @param string $file  Plugin basename.
	 * @return array
	 */
	public static function plugin_row_meta( $links, $file ) {
		if ( RECKON_WC_BASENAME !== $file ) {
			return $links;
		}
		$links[] = self::external_link( self::help_url( self::HELP_URL, 'plugins-row' ), __( 'Get help', 'sparxsync-accounting-integration-for-reckon-one' ) );
		$links[] = self::external_link( self::help_url( self::SERVICES_URL, 'plugins-row' ), __( 'Hire a WooCommerce developer', 'sparxsync-accounting-integration-for-reckon-one' ) );
		return $links;
	}

	/**
	 * A SkillsSparx URL tagged with where in the plugin the click came from.
	 *
	 * @param string $url      Base URL.
	 * @param string $location Short placement name.
	 * @return string
	 */
	private static function help_url( $url, $location ) {
		return add_query_arg(
			array(
				'utm_source'   => 'reckon-one-plugin',
				'utm_medium'   => 'wp-admin',
				'utm_campaign' => $location,
			),
			$url
		);
	}

	/**
	 * Link that opens in a new tab, with a screen-reader hint.
	 *
	 * @param string $url   URL.
	 * @param string $label Link text.
	 * @param string $class Optional class attribute.
	 * @return string
	 */
	private static function external_link( $url, $label, $class = '' ) {
		return '<a href="' . esc_url( $url ) . '"' . ( '' !== $class ? ' class="' . esc_attr( $class ) . '"' : '' ) . ' target="_blank" rel="noopener noreferrer">' . esc_html( $label ) . '<span class="screen-reader-text"> ' . esc_html__( '(opens in a new tab)', 'sparxsync-accounting-integration-for-reckon-one' ) . '</span></a>';
	}

	/**
	 * "Need help?" card: in the dashboard sidebar, and below every other tab.
	 */
	public static function render_help_box() {
		echo '<section class="sxs-card sxs-help">';
		echo '<span class="sxs-help-mark dashicons dashicons-sos" aria-hidden="true"></span>';
		echo '<h2>' . esc_html__( 'Need help or a custom feature?', 'sparxsync-accounting-integration-for-reckon-one' ) . '</h2>';
		echo '<p>' . esc_html__( 'SparxSync is built and maintained by SkillsSparx. We can help you connect Reckon One, set up account and tax mappings, fix orders that will not sync, or build custom WooCommerce and accounting features for your store.', 'sparxsync-accounting-integration-for-reckon-one' ) . '</p>';
		echo '<p class="sxs-actions">';
		echo self::external_link( self::help_url( self::HELP_URL, 'settings-help-box' ), __( 'Get help from SkillsSparx', 'sparxsync-accounting-integration-for-reckon-one' ), 'button sxs-button-lime' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in external_link().
		echo self::external_link( self::help_url( self::SERVICES_URL, 'settings-help-box' ), __( 'Hire us for custom development', 'sparxsync-accounting-integration-for-reckon-one' ), 'button sxs-button-ghost' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in external_link().
		echo '</p>';
		echo '</section>';
	}

	/**
	 * Small "S" spark mark used in the header.
	 *
	 * @return string SVG markup (static, no user data).
	 */
	private static function logo_svg() {
		return '<svg class="sxs-logo" viewBox="0 0 40 40" width="40" height="40" aria-hidden="true" focusable="false"><rect width="40" height="40" rx="11" fill="#c3ef64"/><text x="18" y="29" text-anchor="middle" font-family="-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,sans-serif" font-size="25" font-weight="800" fill="#171b19">S</text><path d="M31 7l-3.2 5.6h3.8L28.4 18" fill="none" stroke="#171b19" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
	}

	/**
	 * Verify capability and nonce for an admin-post action.
	 *
	 * @param string $action Action suffix.
	 */
	private static function verify( $action ) {
		if ( ! current_user_can( Reckon_WC_Settings::capability() ) ) {
			wp_die( esc_html__( 'You do not have permission to manage the Reckon One integration.', 'sparxsync-accounting-integration-for-reckon-one' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'reckon_wc_' . $action );
	}

	/**
	 * Redirect back to a settings tab.
	 *
	 * @param string $tab Tab.
	 */
	private static function back( $tab ) {
		wp_safe_redirect( Reckon_WC_Settings::page_url( $tab ) );
		exit;
	}

	/**
	 * Start the OAuth flow.
	 */
	public static function handle_connect() {
		self::verify( 'connect' );
		$url = Reckon_WC_OAuth::start_authorization( get_current_user_id() );
		if ( is_wp_error( $url ) ) {
			Reckon_WC_Settings::add_notice( 'error', $url->get_error_message() );
			self::back( 'connection' );
		}
		// External, constant identity-server URL; wp_safe_redirect() would reject the host.
		wp_redirect( $url ); // phpcs:ignore WordPress.Security.SafeRedirect.wp_redirect_wp_redirect
		exit;
	}

	/**
	 * Disconnect: remove local tokens, optionally request remote revocation.
	 */
	public static function handle_disconnect() {
		self::verify( 'disconnect' );
		$revoke = ! empty( $_POST['revoke'] ); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- verified in verify().
		$result = Reckon_WC_OAuth::disconnect( $revoke );
		$text   = __( 'Disconnected. Local Reckon tokens were deleted and synchronization is stopped; queued jobs will not send data.', 'sparxsync-accounting-integration-for-reckon-one' );
		if ( 'accepted' === $result ) {
			$text .= ' ' . __( 'Reckon accepted the request to revoke the authorization.', 'sparxsync-accounting-integration-for-reckon-one' );
		} elseif ( 'failed' === $result ) {
			$text .= ' ' . __( 'The request asking Reckon to revoke the authorization failed.', 'sparxsync-accounting-integration-for-reckon-one' );
		}
		$text .= ' ' . __( 'To confirm that access is removed on the Reckon side, review connected applications at https://identity.reckon.com/permissions.', 'sparxsync-accounting-integration-for-reckon-one' );
		Reckon_WC_Settings::add_notice( 'failed' === $result ? 'warning' : 'success', $text );
		self::back( 'connection' );
	}

	/**
	 * Test the connection by loading the list of books.
	 */
	public static function handle_test_connection() {
		self::verify( 'test_connection' );
		$result = Reckon_WC_Reference_Data::refresh_books();
		if ( is_wp_error( $result ) ) {
			Reckon_WC_Settings::add_notice( 'error', __( 'Connection test failed:', 'sparxsync-accounting-integration-for-reckon-one' ) . ' ' . $result->get_error_message() );
		} else {
			$book = Reckon_WC_Settings::get( Reckon_WC_Settings::OPTION_BOOK );
			if ( '' !== $book['book_id'] && null === Reckon_WC_Reference_Data::find_book( $book['book_id'] ) ) {
				Reckon_WC_Settings::add_notice( 'warning', __( 'Connected, but the selected book is no longer accessible to the connected Reckon user.', 'sparxsync-accounting-integration-for-reckon-one' ) );
			} else {
				Reckon_WC_Settings::add_notice( 'success', __( 'Connection test succeeded.', 'sparxsync-accounting-integration-for-reckon-one' ) );
			}
		}
		self::back( 'connection' );
	}

	/**
	 * Reload books, accounts, tax codes and address types.
	 */
	public static function handle_refresh_data() {
		self::verify( 'refresh_data' );
		$result = Reckon_WC_Reference_Data::refresh_books();
		if ( is_wp_error( $result ) ) {
			Reckon_WC_Settings::add_notice( 'error', __( 'Could not load books from Reckon:', 'sparxsync-accounting-integration-for-reckon-one' ) . ' ' . $result->get_error_message() );
			self::back( 'book' );
		}
		$book_id = Reckon_WC_Settings::get( Reckon_WC_Settings::OPTION_BOOK )['book_id'];
		if ( '' !== $book_id ) {
			$result = Reckon_WC_Reference_Data::refresh_book( $book_id );
			if ( is_wp_error( $result ) ) {
				Reckon_WC_Settings::add_notice( 'error', __( 'Books were loaded, but accounts and tax codes could not be loaded:', 'sparxsync-accounting-integration-for-reckon-one' ) . ' ' . $result->get_error_message() );
				self::back( 'book' );
			}
		}
		Reckon_WC_Settings::add_notice( 'success', __( 'Reckon data refreshed.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		self::back( 'book' );
	}

	/**
	 * Queue or retry one order from the overview.
	 */
	public static function handle_retry_order() {
		self::verify( 'retry_order' );
		$order_id = isset( $_POST['order_id'] ) ? absint( $_POST['order_id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- verified in verify().
		$order    = $order_id ? wc_get_order( $order_id ) : false;
		if ( ! $order ) {
			Reckon_WC_Settings::add_notice( 'error', __( 'Order not found.', 'sparxsync-accounting-integration-for-reckon-one' ) );
			self::back( 'orders' );
		}
		self::notice_for_queue_result( $order, Reckon_WC_Sync::queue_order( $order, 'manual' ) );
		self::back( 'orders' );
	}

	/**
	 * Queue up to 50 failed orders again.
	 */
	public static function handle_retry_failed() {
		self::verify( 'retry_failed' );
		$queued = 0;
		$errors = 0;
		foreach ( Reckon_WC_Sync::find_orders( array( Reckon_WC_Order_State::FAILED ), 50 ) as $order ) {
			$result = Reckon_WC_Sync::queue_order( $order, 'manual' );
			if ( 'queued' === $result ) {
				++$queued;
			} elseif ( is_wp_error( $result ) ) {
				++$errors;
			}
		}
		/* translators: 1: queued count, 2: error count. */
		Reckon_WC_Settings::add_notice( $errors ? 'warning' : 'success', sprintf( __( '%1$d failed orders were queued again. %2$d could not be queued.', 'sparxsync-accounting-integration-for-reckon-one' ), $queued, $errors ) );
		self::back( 'orders' );
	}

	/**
	 * Dismiss the upgrade notice.
	 */
	public static function handle_dismiss_upgrade() {
		self::verify( 'dismiss_upgrade' );
		delete_option( Reckon_WC_Settings::OPTION_UPGRADED );
		self::back( 'connection' );
	}

	/**
	 * The upgrade notice is no longer needed once the synchronization settings are saved.
	 */
	public static function sync_settings_saved() {
		delete_option( Reckon_WC_Settings::OPTION_UPGRADED );
	}

	/**
	 * Add a notice describing a queue result.
	 *
	 * @param WC_Order        $order  Order.
	 * @param string|WP_Error $result Result.
	 */
	public static function notice_for_queue_result( $order, $result ) {
		/* translators: %s: order number. */
		$prefix = sprintf( __( 'Order #%s:', 'sparxsync-accounting-integration-for-reckon-one' ), $order->get_order_number() ) . ' ';
		if ( is_wp_error( $result ) ) {
			Reckon_WC_Settings::add_notice( 'error', $prefix . $result->get_error_message() );
			return;
		}
		$messages = array(
			'queued'              => __( 'queued for Reckon synchronization.', 'sparxsync-accounting-integration-for-reckon-one' ),
			'already_queued'      => __( 'already queued.', 'sparxsync-accounting-integration-for-reckon-one' ),
			'already_synced'      => __( 'already has a Reckon invoice; no new invoice will be created.', 'sparxsync-accounting-integration-for-reckon-one' ),
			'verification_pending' => __( 'has a Reckon invoice awaiting verification; no new invoice will be created.', 'sparxsync-accounting-integration-for-reckon-one' ),
			'in_progress'         => __( 'currently being processed.', 'sparxsync-accounting-integration-for-reckon-one' ),
			'failed_needs_manual_retry' => __( 'failed earlier and needs a manual retry.', 'sparxsync-accounting-integration-for-reckon-one' ),
		);
		Reckon_WC_Settings::add_notice( 'queued' === $result ? 'success' : 'info', $prefix . ( isset( $messages[ $result ] ) ? $messages[ $result ] : $result ) );
	}

	/**
	 * Notices shown outside the settings page.
	 */
	public static function global_notices() {
		if ( ! current_user_can( Reckon_WC_Settings::capability() ) ) {
			return;
		}
		if ( get_option( Reckon_WC_Settings::OPTION_UPGRADED ) ) {
			$dismiss = wp_nonce_url( admin_url( 'admin-post.php?action=reckon_wc_dismiss_upgrade' ), 'reckon_wc_dismiss_upgrade' );
			echo '<div class="notice notice-warning"><p>' . esc_html__( 'SparxSync Accounting Integration for Reckon One was upgraded. Automatic synchronization is disabled until you review the connection, the selected book, the account and tax mappings, and the synchronization settings.', 'sparxsync-accounting-integration-for-reckon-one' ) . ' <a href="' . esc_url( Reckon_WC_Settings::page_url( 'connection' ) ) . '">' . esc_html__( 'Review settings', 'sparxsync-accounting-integration-for-reckon-one' ) . '</a> | <a href="' . esc_url( $dismiss ) . '">' . esc_html__( 'Dismiss', 'sparxsync-accounting-integration-for-reckon-one' ) . '</a></p></div>';
		}
		if ( ! Reckon_WC_Integration::scheduler_available() ) {
			echo '<div class="notice notice-error"><p>' . esc_html__( 'SparxSync Accounting Integration for Reckon One cannot queue orders because WooCommerce Action Scheduler is not available.', 'sparxsync-accounting-integration-for-reckon-one' ) . '</p></div>';
		}
	}

	/**
	 * Render the settings page.
	 */
	public static function render_page() {
		if ( ! current_user_can( Reckon_WC_Settings::capability() ) ) {
			wp_die( esc_html__( 'You do not have permission to manage the Reckon One integration.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}
		$tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'dashboard'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Navigation only.
		$tab = in_array( $tab, self::TABS, true ) ? $tab : 'dashboard';

		$titles = array(
			'dashboard'  => array( __( 'Dashboard', 'sparxsync-accounting-integration-for-reckon-one' ), 'chart-bar' ),
			'connection' => array( __( 'Connection', 'sparxsync-accounting-integration-for-reckon-one' ), 'admin-links' ),
			'book'       => array( __( 'Book & mappings', 'sparxsync-accounting-integration-for-reckon-one' ), 'book-alt' ),
			'sync'       => array( __( 'Synchronization', 'sparxsync-accounting-integration-for-reckon-one' ), 'update' ),
			'orders'     => array( __( 'Orders', 'sparxsync-accounting-integration-for-reckon-one' ), 'list-view' ),
		);

		$conn      = Reckon_WC_OAuth::get_connection();
		$connected = 'connected' === $conn['status'] && Reckon_WC_OAuth::has_tokens();

		echo '<div class="wrap reckon-wc sxs-app">';
		echo '<header class="sxs-header">';
		echo self::logo_svg(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG.
		echo '<div class="sxs-brand"><h1>' . esc_html__( 'SparxSync', 'sparxsync-accounting-integration-for-reckon-one' ) . '</h1>';
		echo '<p>' . esc_html__( 'Accounting Integration for Reckon One', 'sparxsync-accounting-integration-for-reckon-one' ) . ' <span class="sxs-version">' . esc_html( sprintf( 'v%s', RECKON_WC_VERSION ) ) . '</span></p></div>';
		echo '<div class="sxs-header-actions">';
		echo '<span class="sxs-pill ' . esc_attr( $connected ? 'is-ok' : 'is-off' ) . '"><span class="sxs-dot" aria-hidden="true"></span>' . esc_html( $connected ? __( 'Connected to Reckon', 'sparxsync-accounting-integration-for-reckon-one' ) : __( 'Not connected', 'sparxsync-accounting-integration-for-reckon-one' ) ) . '</span>';
		echo self::external_link( self::help_url( self::HELP_URL, 'settings-header' ), __( 'Need help?', 'sparxsync-accounting-integration-for-reckon-one' ), 'button sxs-button-lime' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in external_link().
		echo '</div></header>';

		echo '<nav class="sxs-tabs" aria-label="' . esc_attr__( 'SparxSync sections', 'sparxsync-accounting-integration-for-reckon-one' ) . '">';
		foreach ( $titles as $key => $item ) {
			$active = $key === $tab;
			echo '<a href="' . esc_url( Reckon_WC_Settings::page_url( $key ) ) . '" class="sxs-tab' . ( $active ? ' is-active' : '' ) . '"' . ( $active ? ' aria-current="page"' : '' ) . '><span class="dashicons dashicons-' . esc_attr( $item[1] ) . '" aria-hidden="true"></span>' . esc_html( $item[0] ) . '</a>';
		}
		echo '</nav>';
		echo '<hr class="wp-header-end" />';

		settings_errors();
		foreach ( Reckon_WC_Settings::pop_notices() as $notice ) {
			printf( '<div class="notice notice-%1$s is-dismissible"><p>%2$s</p></div>', esc_attr( $notice['type'] ), esc_html( $notice['message'] ) );
		}

		if ( 'dashboard' === $tab ) {
			Reckon_WC_Dashboard::render();
		} else {
			echo '<div class="sxs-card sxs-panel">';
			call_user_func( array( __CLASS__, 'render_' . $tab . '_tab' ) );
			echo '</div>';
			self::render_help_box();
		}

		echo '<p class="sxs-footnote">' . esc_html__( 'Independent integration. Not an official Reckon or WooCommerce product.', 'sparxsync-accounting-integration-for-reckon-one' ) . '</p>';
		echo '</div>';
	}

	/**
	 * Small form posting to admin-post.php.
	 *
	 * @param string $action  Action suffix.
	 * @param string $label   Button label.
	 * @param array  $fields  Extra hidden fields.
	 * @param string $class   Button class.
	 * @param string $extra   Extra HTML inside the form (already escaped).
	 */
	private static function action_form( $action, $label, $fields = array(), $class = 'button', $extra = '' ) {
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="display:inline-block;margin:0 8px 8px 0;">';
		echo '<input type="hidden" name="action" value="' . esc_attr( 'reckon_wc_' . $action ) . '" />';
		wp_nonce_field( 'reckon_wc_' . $action );
		foreach ( $fields as $name => $value ) {
			echo '<input type="hidden" name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '" />';
		}
		echo $extra; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped parts by callers.
		echo '<button type="submit" class="' . esc_attr( $class ) . '">' . esc_html( $label ) . '</button>';
		echo '</form>';
	}

	/**
	 * Format a timestamp for display.
	 *
	 * @param int $timestamp Timestamp.
	 * @return string
	 */
	public static function format_time( $timestamp ) {
		$timestamp = (int) $timestamp;
		if ( $timestamp <= 0 ) {
			return __( 'Never', 'sparxsync-accounting-integration-for-reckon-one' );
		}
		return wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $timestamp );
	}

	/**
	 * Connection tab.
	 */
	public static function render_connection_tab() {
		$credentials = Reckon_WC_Settings::get( Reckon_WC_Settings::OPTION_CREDENTIALS );
		$option      = Reckon_WC_Settings::OPTION_CREDENTIALS;

		echo '<h2>' . esc_html__( 'API credentials', 'sparxsync-accounting-integration-for-reckon-one' ) . '</h2>';
		echo '<p>' . esc_html__( 'Reckon issues the Client ID, Client Secret and Subscription Key to approved Reckon developer partners. Secrets are stored in the WordPress options table without autoloading and are never shown again after saving. You can instead define RECKON_WC_CLIENT_ID, RECKON_WC_CLIENT_SECRET and RECKON_WC_SUBSCRIPTION_KEY in wp-config.php.', 'sparxsync-accounting-integration-for-reckon-one' ) . '</p>';
		echo '<form method="post" action="options.php">';
		settings_fields( Reckon_WC_Settings::GROUP_CREDENTIALS );
		echo '<table class="form-table" role="presentation">';

		// Client ID is an identifier, not a secret.
		echo '<tr><th scope="row"><label for="reckon-wc-client-id">' . esc_html__( 'Client ID', 'sparxsync-accounting-integration-for-reckon-one' ) . '</label></th><td>';
		if ( defined( Reckon_WC_Settings::credential_constant( 'client_id' ) ) ) {
			echo esc_html__( 'Defined in wp-config.php.', 'sparxsync-accounting-integration-for-reckon-one' );
		} else {
			echo '<input type="text" id="reckon-wc-client-id" class="regular-text" autocomplete="off" name="' . esc_attr( $option ) . '[client_id]" value="' . esc_attr( $credentials['client_id'] ) . '" />';
		}
		echo '</td></tr>';

		$secret_fields = array(
			'client_secret'    => __( 'Client Secret', 'sparxsync-accounting-integration-for-reckon-one' ),
			'subscription_key' => __( 'Subscription Key', 'sparxsync-accounting-integration-for-reckon-one' ),
		);
		foreach ( $secret_fields as $key => $label ) {
			$id = 'reckon-wc-' . str_replace( '_', '-', $key );
			echo '<tr><th scope="row"><label for="' . esc_attr( $id ) . '">' . esc_html( $label ) . '</label></th><td>';
			if ( defined( Reckon_WC_Settings::credential_constant( $key ) ) ) {
				echo esc_html__( 'Defined in wp-config.php.', 'sparxsync-accounting-integration-for-reckon-one' );
			} else {
				$masked = Reckon_WC_Settings::masked_credential( $key );
				echo '<input type="password" id="' . esc_attr( $id ) . '" class="regular-text" autocomplete="new-password" name="' . esc_attr( $option ) . '[' . esc_attr( $key ) . ']" value="" placeholder="' . esc_attr( '' === $masked ? '' : $masked ) . '" />';
				if ( '' !== $masked ) {
					echo '<p class="description">' . esc_html__( 'A value is saved. Leave blank to keep it.', 'sparxsync-accounting-integration-for-reckon-one' ) . '</p>';
					echo '<label><input type="checkbox" name="' . esc_attr( $option ) . '[clear_' . esc_attr( $key ) . ']" value="1" /> ' . esc_html__( 'Delete the saved value', 'sparxsync-accounting-integration-for-reckon-one' ) . '</label>';
				}
			}
			echo '</td></tr>';
		}

		echo '<tr><th scope="row">' . esc_html__( 'Redirect URI', 'sparxsync-accounting-integration-for-reckon-one' ) . '</th><td><code>' . esc_html( Reckon_WC_OAuth::get_redirect_uri() ) . '</code>';
		echo '<p class="description">' . esc_html__( 'Register this exact URI (scheme, host and path) with Reckon for your Client ID.', 'sparxsync-accounting-integration-for-reckon-one' ) . '</p></td></tr>';
		echo '</table>';
		submit_button( __( 'Save credentials', 'sparxsync-accounting-integration-for-reckon-one' ) );
		echo '</form>';

		echo '<hr /><h2>' . esc_html__( 'Connection status', 'sparxsync-accounting-integration-for-reckon-one' ) . '</h2>';
		$connection = Reckon_WC_OAuth::get_connection();
		$has_tokens = Reckon_WC_OAuth::has_tokens();
		if ( 'connected' === $connection['status'] && $has_tokens ) {
			if ( $connection['last_verified_at'] > 0 ) {
				/* translators: %s: date and time. */
				$status = sprintf( __( 'Connected. Last successful API call: %s.', 'sparxsync-accounting-integration-for-reckon-one' ), self::format_time( $connection['last_verified_at'] ) );
			} else {
				$status = __( 'Authorized, but no API call has been verified yet. Use "Test connection".', 'sparxsync-accounting-integration-for-reckon-one' );
			}
			$class = 'notice-success';
		} elseif ( 'reconnect_required' === $connection['status'] ) {
			$status = __( 'Reconnection required. Reckon rejected the saved authorization, or the Client ID changed. Synchronization is paused.', 'sparxsync-accounting-integration-for-reckon-one' );
			$class  = 'notice-error';
		} else {
			$status = __( 'Not connected.', 'sparxsync-accounting-integration-for-reckon-one' );
			$class  = 'notice-warning';
		}
		echo '<div class="notice inline ' . esc_attr( $class ) . '"><p>' . esc_html( $status ) . '</p></div>';
		if ( $has_tokens && $connection['last_refreshed_at'] > 0 ) {
			/* translators: %s: date and time. */
			echo '<p>' . esc_html( sprintf( __( 'Token last refreshed: %s', 'sparxsync-accounting-integration-for-reckon-one' ), self::format_time( $connection['last_refreshed_at'] ) ) ) . '</p>';
		}
		if ( '' !== $connection['last_error'] ) {
			/* translators: %s: error code. */
			echo '<p>' . esc_html( sprintf( __( 'Last connection error: %s', 'sparxsync-accounting-integration-for-reckon-one' ), $connection['last_error'] ) ) . '</p>';
		}

		if ( Reckon_WC_Settings::credentials_complete() ) {
			self::action_form( 'connect', $has_tokens ? __( 'Reconnect to Reckon', 'sparxsync-accounting-integration-for-reckon-one' ) : __( 'Connect to Reckon', 'sparxsync-accounting-integration-for-reckon-one' ), array(), $has_tokens ? 'button' : 'button button-primary' );
		} else {
			echo '<p>' . esc_html__( 'Save all three credentials to connect.', 'sparxsync-accounting-integration-for-reckon-one' ) . '</p>';
		}
		if ( $has_tokens ) {
			self::action_form( 'test_connection', __( 'Test connection', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}
		if ( $has_tokens || 'disconnected' !== $connection['status'] ) {
			$extra = '<label style="margin-right:8px;"><input type="checkbox" name="revoke" value="1" checked="checked" /> ' . esc_html__( 'Also ask Reckon to revoke the authorization', 'sparxsync-accounting-integration-for-reckon-one' ) . '</label>';
			self::action_form( 'disconnect', __( 'Disconnect', 'sparxsync-accounting-integration-for-reckon-one' ), array(), 'button', $extra );
			echo '<p class="description">' . esc_html__( 'Disconnecting always deletes the tokens stored in WordPress and stops synchronization. Remote revocation is a separate request to Reckon\'s revocation endpoint; you can also remove access at identity.reckon.com/permissions. Disconnecting never changes records in Reckon.', 'sparxsync-accounting-integration-for-reckon-one' ) . '</p>';
		}
	}

	/**
	 * Book and mappings tab.
	 */
	public static function render_book_tab() {
		$book     = Reckon_WC_Settings::get( Reckon_WC_Settings::OPTION_BOOK );
		$mappings = Reckon_WC_Settings::get( Reckon_WC_Settings::OPTION_MAPPINGS );
		$data     = Reckon_WC_Reference_Data::get();

		echo '<h2>' . esc_html__( 'Reckon book', 'sparxsync-accounting-integration-for-reckon-one' ) . '</h2>';
		if ( ! Reckon_WC_OAuth::has_tokens() ) {
			echo '<p>' . esc_html__( 'Connect to Reckon first.', 'sparxsync-accounting-integration-for-reckon-one' ) . '</p>';
			return;
		}
		self::action_form( 'refresh_data', __( 'Refresh Reckon data', 'sparxsync-accounting-integration-for-reckon-one' ) );
		/* translators: %s: date and time. */
		echo '<p class="description">' . esc_html( sprintf( __( 'Books last loaded: %s', 'sparxsync-accounting-integration-for-reckon-one' ), self::format_time( $data['books_fetched_at'] ) ) ) . '</p>';

		echo '<form method="post" action="options.php">';
		settings_fields( Reckon_WC_Settings::GROUP_BOOK );
		echo '<select name="' . esc_attr( Reckon_WC_Settings::OPTION_BOOK ) . '[book_id]">';
		echo '<option value="">' . esc_html__( 'Select a book', 'sparxsync-accounting-integration-for-reckon-one' ) . '</option>';
		foreach ( $data['books'] as $id => $item ) {
			$inactive = '' !== $item['status'] && 'active' !== strtolower( $item['status'] );
			$label    = $item['name'] . ( '' !== $item['currency'] ? ' (' . $item['currency'] . ')' : '' ) . ( $inactive ? ' — ' . __( 'inactive', 'sparxsync-accounting-integration-for-reckon-one' ) : '' );
			echo '<option value="' . esc_attr( $id ) . '"' . selected( $book['book_id'], $id, false ) . disabled( $inactive, true, false ) . '>' . esc_html( $label ) . '</option>';
		}
		if ( '' !== $book['book_id'] && ! isset( $data['books'][ $book['book_id'] ] ) ) {
			echo '<option value="' . esc_attr( $book['book_id'] ) . '" selected="selected">' . esc_html( '' !== $book['book_name'] ? $book['book_name'] : $book['book_id'] ) . '</option>';
		}
		echo '</select> ';
		submit_button( __( 'Save book selection', 'sparxsync-accounting-integration-for-reckon-one' ), 'secondary', 'submit', false );
		echo '<p class="description">' . esc_html__( 'Changing the book pauses synchronization until the mappings are saved for the new book. Orders already synchronized are never sent again, and jobs queued for the previous book are not redirected.', 'sparxsync-accounting-integration-for-reckon-one' ) . '</p>';
		echo '</form>';

		if ( '' === $book['book_id'] ) {
			return;
		}
		/* translators: 1: book name, 2: currency. */
		echo '<p>' . esc_html( sprintf( __( 'Selected: %1$s. Currency: %2$s.', 'sparxsync-accounting-integration-for-reckon-one' ), '' !== $book['book_name'] ? $book['book_name'] : $book['book_id'], '' !== $book['currency'] ? $book['currency'] : __( 'unknown', 'sparxsync-accounting-integration-for-reckon-one' ) ) ) . '</p>';

		$ref = Reckon_WC_Reference_Data::get_book_data( $book['book_id'] );
		echo '<hr /><h2>' . esc_html__( 'Account, product and tax mappings', 'sparxsync-accounting-integration-for-reckon-one' ) . '</h2>';
		if ( null === $ref ) {
			echo '<p>' . esc_html__( 'Use "Refresh Reckon data" to load the accounts, tax codes and address types for this book.', 'sparxsync-accounting-integration-for-reckon-one' ) . '</p>';
			return;
		}
		/* translators: %s: date and time. */
		echo '<p class="description">' . esc_html( sprintf( __( 'Accounts and tax codes last loaded: %s', 'sparxsync-accounting-integration-for-reckon-one' ), self::format_time( $ref['fetched_at'] ) ) ) . '</p>';
		if ( $mappings['book_id'] !== $book['book_id'] ) {
			echo '<div class="notice inline notice-warning"><p>' . esc_html__( 'Review required: these mappings have not been saved for the selected book. Synchronization is paused until you save them.', 'sparxsync-accounting-integration-for-reckon-one' ) . '</p></div>';
			if ( '' !== $mappings['book_id'] ) {
				$mappings = Reckon_WC_Settings::defaults( Reckon_WC_Settings::OPTION_MAPPINGS );
			}
		}

		$name = Reckon_WC_Settings::OPTION_MAPPINGS;
		echo '<form method="post" action="options.php">';
		settings_fields( Reckon_WC_Settings::GROUP_MAPPINGS );
		echo '<input type="hidden" name="' . esc_attr( $name ) . '[book_id]" value="' . esc_attr( $book['book_id'] ) . '" />';
		echo '<table class="form-table" role="presentation">';

		echo '<tr><th scope="row">' . esc_html__( 'Product lines', 'sparxsync-accounting-integration-for-reckon-one' ) . '</th><td>';
		$policies = array(
			'require_item'    => __( 'Require a Reckon item whose item code equals the product SKU. Stop if any product has no match (default).', 'sparxsync-accounting-integration-for-reckon-one' ),
			'item_or_account' => __( 'Use the matching Reckon item when found; otherwise post the line to the sales ledger account with the product name as description.', 'sparxsync-accounting-integration-for-reckon-one' ),
			'account_only'    => __( 'Post every product line to the sales ledger account (no item lookups).', 'sparxsync-accounting-integration-for-reckon-one' ),
		);
		foreach ( $policies as $value => $label ) {
			echo '<label style="display:block;margin-bottom:4px;"><input type="radio" name="' . esc_attr( $name ) . '[product_policy]" value="' . esc_attr( $value ) . '"' . checked( $mappings['product_policy'], $value, false ) . ' /> ' . esc_html( $label ) . '</label>';
		}
		echo '<p class="description">' . esc_html__( 'SKU matching only looks up existing Reckon items. It does not create or update products, prices or stock in Reckon.', 'sparxsync-accounting-integration-for-reckon-one' ) . '</p></td></tr>';

		$accounts = array(
			'sales_account'    => __( 'Sales ledger account', 'sparxsync-accounting-integration-for-reckon-one' ),
			'shipping_account' => __( 'Shipping ledger account', 'sparxsync-accounting-integration-for-reckon-one' ),
			'fee_account'      => __( 'Fee ledger account', 'sparxsync-accounting-integration-for-reckon-one' ),
		);
		foreach ( $accounts as $key => $label ) {
			echo '<tr><th scope="row">' . esc_html( $label ) . '</th><td>';
			self::select( $name . '[' . $key . ']', $mappings[ $key ], self::account_options( $ref['ledger_accounts'] ), __( '— None —', 'sparxsync-accounting-integration-for-reckon-one' ) );
			echo '</td></tr>';
		}

		$tax_options = self::tax_options( $ref['tax_rates'] );
		echo '<tr><th scope="row">' . esc_html__( 'Tax code for untaxed lines', 'sparxsync-accounting-integration-for-reckon-one' ) . '</th><td>';
		self::select( $name . '[untaxed_tax_rate]', $mappings['untaxed_tax_rate'], $tax_options, __( '— None —', 'sparxsync-accounting-integration-for-reckon-one' ) );
		echo '<p class="description">' . esc_html__( 'Used for lines without WooCommerce tax, for example a GST-free code.', 'sparxsync-accounting-integration-for-reckon-one' ) . '</p></td></tr>';

		echo '<tr><th scope="row">' . esc_html__( 'WooCommerce tax rates', 'sparxsync-accounting-integration-for-reckon-one' ) . '</th><td>';
		$wc_rates = Reckon_WC_Settings::wc_tax_rates();
		if ( empty( $wc_rates ) ) {
			echo '<p>' . esc_html__( 'No WooCommerce tax rates are defined.', 'sparxsync-accounting-integration-for-reckon-one' ) . '</p>';
		} else {
			echo '<table class="widefat striped" style="max-width:720px;"><thead><tr><th>' . esc_html__( 'WooCommerce rate', 'sparxsync-accounting-integration-for-reckon-one' ) . '</th><th>' . esc_html__( 'Reckon tax code', 'sparxsync-accounting-integration-for-reckon-one' ) . '</th></tr></thead><tbody>';
			foreach ( $wc_rates as $rate ) {
				$current = isset( $mappings['tax_rates'][ (string) $rate['id'] ] ) ? $mappings['tax_rates'][ (string) $rate['id'] ] : '';
				echo '<tr><td>' . esc_html( $rate['label'] . ( $rate['compound'] ? ' — ' . __( 'compound', 'sparxsync-accounting-integration-for-reckon-one' ) : '' ) ) . '</td><td>';
				self::select( $name . '[tax_rates][' . $rate['id'] . ']', $current, $tax_options, __( '— Not mapped —', 'sparxsync-accounting-integration-for-reckon-one' ) );
				echo '</td></tr>';
			}
			echo '</tbody></table>';
		}
		echo '<p class="description">' . esc_html__( 'Each invoice line carries one Reckon tax code and the exact tax amount WooCommerce charged. Lines taxed at more than one rate (for example compound or stacked rates) cannot be synchronized.', 'sparxsync-accounting-integration-for-reckon-one' ) . '</p></td></tr>';

		echo '<tr><th scope="row">' . esc_html__( 'Unmapped tax rates', 'sparxsync-accounting-integration-for-reckon-one' ) . '</th><td>';
		echo '<label style="display:block;"><input type="radio" name="' . esc_attr( $name ) . '[unmapped_tax_policy]" value="block"' . checked( $mappings['unmapped_tax_policy'], 'block', false ) . ' /> ' . esc_html__( 'Stop synchronization of the order (default)', 'sparxsync-accounting-integration-for-reckon-one' ) . '</label>';
		echo '<label style="display:block;"><input type="radio" name="' . esc_attr( $name ) . '[unmapped_tax_policy]" value="fallback"' . checked( $mappings['unmapped_tax_policy'], 'fallback', false ) . ' /> ' . esc_html__( 'Use the fallback tax code below (amounts stay exact, but tax reporting may be wrong)', 'sparxsync-accounting-integration-for-reckon-one' ) . '</label>';
		self::select( $name . '[fallback_tax_rate]', $mappings['fallback_tax_rate'], $tax_options, __( '— None —', 'sparxsync-accounting-integration-for-reckon-one' ) );
		echo '</td></tr>';

		echo '<tr><th scope="row">' . esc_html__( 'Billing address on new customers', 'sparxsync-accounting-integration-for-reckon-one' ) . '</th><td>';
		self::select( $name . '[billing_address_type]', $mappings['billing_address_type'], $ref['address_types'], __( 'Do not send the billing address', 'sparxsync-accounting-integration-for-reckon-one' ) );
		echo '<p class="description">' . esc_html__( 'By default only the customer name, company and email are sent. Choose a Reckon address type to also send the billing address when a customer is created.', 'sparxsync-accounting-integration-for-reckon-one' ) . '</p></td></tr>';

		echo '</table>';
		submit_button( __( 'Save mappings for this book', 'sparxsync-accounting-integration-for-reckon-one' ) );
		echo '</form>';
	}

	/**
	 * Synchronization tab.
	 */
	public static function render_sync_tab() {
		$settings = Reckon_WC_Settings::get( Reckon_WC_Settings::OPTION_SYNC );
		$name     = Reckon_WC_Settings::OPTION_SYNC;

		echo '<h2>' . esc_html__( 'Configuration check', 'sparxsync-accounting-integration-for-reckon-one' ) . '</h2><ul>';
		$icons = array(
			'ok'      => 'yes-alt',
			'warning' => 'warning',
			'error'   => 'dismiss',
		);
		foreach ( Reckon_WC_Settings::validate_configuration() as $check ) {
			echo '<li><span class="dashicons dashicons-' . esc_attr( $icons[ $check['level'] ] ) . '"></span> ' . esc_html( $check['message'] ) . ( $check['blocking'] ? ' <strong>' . esc_html__( '(blocks synchronization)', 'sparxsync-accounting-integration-for-reckon-one' ) . '</strong>' : '' ) . '</li>';
		}
		echo '</ul>';

		echo '<form method="post" action="options.php">';
		settings_fields( Reckon_WC_Settings::GROUP_SYNC );
		echo '<table class="form-table" role="presentation">';

		echo '<tr><th scope="row">' . esc_html__( 'Automatic synchronization', 'sparxsync-accounting-integration-for-reckon-one' ) . '</th><td>';
		echo '<input type="hidden" name="' . esc_attr( $name ) . '[enabled]" value="0" />';
		echo '<label><input type="checkbox" name="' . esc_attr( $name ) . '[enabled]" value="1"' . checked( $settings['enabled'], true, false ) . ' /> ' . esc_html__( 'Queue eligible orders and create Reckon invoices', 'sparxsync-accounting-integration-for-reckon-one' ) . '</label>';
		echo '<p class="description">' . esc_html__( 'When disabled, no order data is sent to Reckon, including jobs that are already queued.', 'sparxsync-accounting-integration-for-reckon-one' ) . '</p></td></tr>';

		echo '<tr><th scope="row">' . esc_html__( 'Order statuses', 'sparxsync-accounting-integration-for-reckon-one' ) . '</th><td>';
		echo '<input type="hidden" name="' . esc_attr( $name ) . '[order_statuses][]" value="" />';
		foreach ( Reckon_WC_Settings::eligible_status_choices() as $status => $label ) {
			echo '<label style="display:block;"><input type="checkbox" name="' . esc_attr( $name ) . '[order_statuses][]" value="' . esc_attr( $status ) . '"' . checked( in_array( $status, $settings['order_statuses'], true ), true, false ) . ' /> ' . esc_html( $label ) . '</label>';
		}
		echo '<p class="description">' . esc_html__( 'An order is queued when it changes to one of these statuses. Pending, failed, cancelled and refunded orders are never invoiced.', 'sparxsync-accounting-integration-for-reckon-one' ) . '</p></td></tr>';

		echo '<tr><th scope="row">' . esc_html__( 'Payment status', 'sparxsync-accounting-integration-for-reckon-one' ) . '</th><td>';
		echo '<input type="hidden" name="' . esc_attr( $name ) . '[check_payment_status]" value="0" />';
		echo '<label><input type="checkbox" name="' . esc_attr( $name ) . '[check_payment_status]" value="1"' . checked( $settings['check_payment_status'], true, false ) . ' /> ' . esc_html__( 'Check Reckon for paid invoices and show "Paid in Reckon" on orders', 'sparxsync-accounting-integration-for-reckon-one' ) . '</label>';
		echo '<p class="description">' . esc_html__( 'Once an hour, up to 20 invoices created in the last 120 days are read from Reckon (read-only) to see whether they are Draft, Approved or Paid. Nothing is changed in Reckon or in the WooCommerce order status; a note is added to the order when its invoice is first seen as paid.', 'sparxsync-accounting-integration-for-reckon-one' ) . '</p></td></tr>';

		echo '<tr><th scope="row">' . esc_html__( 'Debug logging', 'sparxsync-accounting-integration-for-reckon-one' ) . '</th><td>';
		echo '<input type="hidden" name="' . esc_attr( $name ) . '[debug_logging]" value="0" />';
		echo '<label><input type="checkbox" name="' . esc_attr( $name ) . '[debug_logging]" value="1"' . checked( $settings['debug_logging'], true, false ) . ' /> ' . esc_html__( 'Write debug-level entries to the WooCommerce log (source reckon-wc). Credentials, tokens and customer details are never logged.', 'sparxsync-accounting-integration-for-reckon-one' ) . '</label></td></tr>';

		echo '<tr><th scope="row">' . esc_html__( 'Uninstall', 'sparxsync-accounting-integration-for-reckon-one' ) . '</th><td>';
		echo '<input type="hidden" name="' . esc_attr( $name ) . '[remove_data_on_uninstall]" value="0" />';
		echo '<label><input type="checkbox" name="' . esc_attr( $name ) . '[remove_data_on_uninstall]" value="1"' . checked( $settings['remove_data_on_uninstall'], true, false ) . ' /> ' . esc_html__( 'Delete settings, credentials, tokens and cached Reckon data when the plugin is deleted', 'sparxsync-accounting-integration-for-reckon-one' ) . '</label>';
		echo '<p class="description">' . esc_html__( 'Order synchronization records (Reckon invoice IDs and references) are always kept, because deleting them would allow the same orders to be exported again. WooCommerce orders and Reckon records are never deleted.', 'sparxsync-accounting-integration-for-reckon-one' ) . '</p></td></tr>';

		echo '</table>';
		submit_button( __( 'Save synchronization settings', 'sparxsync-accounting-integration-for-reckon-one' ) );
		echo '</form>';

		echo '<hr /><h2>' . esc_html__( 'What is sent to Reckon', 'sparxsync-accounting-integration-for-reckon-one' ) . '</h2>';
		echo '<p>' . esc_html__( 'For each synchronized order: the customer name, company and billing email (plus the billing address only if enabled on the mappings tab) when a Reckon customer has to be created; and an invoice with the order date, line descriptions, quantities, amounts, tax codes and tax amounts, a reference in the form WC-{order ID}-{site code}, and a note with the order number. Nothing is sent until an order is queued and a worker runs with synchronization enabled.', 'sparxsync-accounting-integration-for-reckon-one' ) . '</p>';
	}

	/**
	 * Orders overview tab.
	 */
	public static function render_orders_tab() {
		$labels = Reckon_WC_Order_State::labels();

		echo '<h2>' . esc_html__( 'Synchronization overview', 'sparxsync-accounting-integration-for-reckon-one' ) . '</h2><p>';
		$parts = array();
		foreach ( array( Reckon_WC_Order_State::QUEUED, Reckon_WC_Order_State::IN_PROGRESS, Reckon_WC_Order_State::VERIFY_PENDING, Reckon_WC_Order_State::FAILED, Reckon_WC_Order_State::NEEDS_REVIEW ) as $state ) {
			$parts[] = esc_html( $labels[ $state ] ) . ': <strong>' . esc_html( number_format_i18n( Reckon_WC_Sync::count_state( $state ) ) ) . '</strong>';
		}
		echo implode( ' &nbsp;|&nbsp; ', $parts ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped above.
		echo '</p>';

		if ( Reckon_WC_Integration::scheduler_available() ) {
			$pending = as_get_scheduled_actions(
				array(
					'hook'     => Reckon_WC_Sync::HOOK,
					'status'   => 'pending',
					'per_page' => 200,
				),
				'ids'
			);
			$overdue = as_get_scheduled_actions(
				array(
					'hook'         => Reckon_WC_Sync::HOOK,
					'status'       => 'pending',
					'date'         => gmdate( 'Y-m-d H:i:s', time() - 10 * MINUTE_IN_SECONDS ),
					'date_compare' => '<=',
					'per_page'     => 200,
				),
				'ids'
			);
			$link = admin_url( 'admin.php?page=wc-status&tab=action-scheduler&status=pending&s=' . Reckon_WC_Sync::HOOK );
			/* translators: %d: number of jobs. */
			echo '<p>' . esc_html( sprintf( __( 'Pending background jobs: %d.', 'sparxsync-accounting-integration-for-reckon-one' ), count( $pending ) ) ) . ' ' . esc_html__( 'Jobs run through WooCommerce Action Scheduler, which is triggered by WP-Cron and site traffic.', 'sparxsync-accounting-integration-for-reckon-one' ) . ' <a href="' . esc_url( $link ) . '">' . esc_html__( 'View scheduled actions', 'sparxsync-accounting-integration-for-reckon-one' ) . '</a></p>';
			if ( count( $overdue ) > 0 ) {
				/* translators: %d: number of jobs. */
				echo '<div class="notice inline notice-warning"><p>' . esc_html( sprintf( __( '%d jobs are more than 10 minutes past their scheduled time. The site\'s scheduler (WP-Cron) may not be running; orders stay "Queued" until it runs.', 'sparxsync-accounting-integration-for-reckon-one' ), count( $overdue ) ) ) . '</p></div>';
			}
		}
		$logs = admin_url( 'admin.php?page=wc-status&tab=logs&source=' . Reckon_WC_Logger::SOURCE );
		echo '<p><a href="' . esc_url( $logs ) . '">' . esc_html__( 'View WooCommerce logs (source: reckon-wc)', 'sparxsync-accounting-integration-for-reckon-one' ) . '</a></p>';

		self::action_form( 'retry_failed', __( 'Retry failed orders (next 50)', 'sparxsync-accounting-integration-for-reckon-one' ) );

		echo '<hr />';
		Reckon_WC_History_Export::render();
		echo '<hr />';

		echo '<h3>' . esc_html__( 'Failed or needing review', 'sparxsync-accounting-integration-for-reckon-one' ) . '</h3>';
		self::orders_table( Reckon_WC_Sync::find_orders( array( Reckon_WC_Order_State::FAILED, Reckon_WC_Order_State::NEEDS_REVIEW ), 50 ), true );

		echo '<h3>' . esc_html__( 'Queued, in progress or awaiting verification', 'sparxsync-accounting-integration-for-reckon-one' ) . '</h3>';
		self::orders_table( Reckon_WC_Sync::find_orders( array( Reckon_WC_Order_State::QUEUED, Reckon_WC_Order_State::IN_PROGRESS, Reckon_WC_Order_State::VERIFY_PENDING ), 20 ), false );

		echo '<h3>' . esc_html__( 'Refunded or cancelled after synchronization', 'sparxsync-accounting-integration-for-reckon-one' ) . '</h3>';
		echo '<p class="description">' . esc_html__( 'These orders have a Reckon invoice that may need a credit note or adjustment in Reckon. Nothing is changed in Reckon automatically.', 'sparxsync-accounting-integration-for-reckon-one' ) . '</p>';
		self::orders_table( Reckon_WC_Sync::find_accounting_review_orders( 50 ), false );
	}

	/**
	 * Table of orders.
	 *
	 * @param WC_Order[] $orders      Orders.
	 * @param bool       $with_retry  Show retry buttons for failed orders.
	 */
	private static function orders_table( $orders, $with_retry ) {
		if ( empty( $orders ) ) {
			echo '<p>' . esc_html__( 'None.', 'sparxsync-accounting-integration-for-reckon-one' ) . '</p>';
			return;
		}
		$labels = Reckon_WC_Order_State::labels();
		echo '<table class="widefat striped"><thead><tr>';
		foreach ( array( __( 'Order', 'sparxsync-accounting-integration-for-reckon-one' ), __( 'State', 'sparxsync-accounting-integration-for-reckon-one' ), __( 'Attempts', 'sparxsync-accounting-integration-for-reckon-one' ), __( 'Last attempt', 'sparxsync-accounting-integration-for-reckon-one' ), __( 'Next attempt', 'sparxsync-accounting-integration-for-reckon-one' ), __( 'Invoice', 'sparxsync-accounting-integration-for-reckon-one' ), __( 'Details', 'sparxsync-accounting-integration-for-reckon-one' ), '' ) as $heading ) {
			echo '<th>' . esc_html( $heading ) . '</th>';
		}
		echo '</tr></thead><tbody>';
		foreach ( $orders as $order ) {
			$s      = Reckon_WC_Order_State::summary( $order );
			$detail = isset( $s['last_error']['message'] ) ? $s['last_error']['message'] : '';
			if ( ! empty( $s['accounting_review']['reason'] ) ) {
				$detail = $s['accounting_review']['reason'];
			}
			echo '<tr>';
			echo '<td><a href="' . esc_url( $order->get_edit_order_url() ) . '">#' . esc_html( $order->get_order_number() ) . '</a></td>';
			echo '<td>' . esc_html( $labels[ $s['state'] ] ) . '</td>';
			echo '<td>' . esc_html( (string) $s['attempts'] ) . '</td>';
			echo '<td>' . esc_html( self::format_time( $s['last_attempt_at'] ) ) . '</td>';
			echo '<td>' . esc_html( $s['next_attempt_at'] ? self::format_time( $s['next_attempt_at'] ) : '—' ) . '</td>';
			echo '<td>' . esc_html( '' !== $s['invoice_id'] ? $s['invoice_id'] : '—' ) . '</td>';
			echo '<td>' . esc_html( $detail ) . '</td><td>';
			if ( $with_retry && Reckon_WC_Order_State::FAILED === $s['state'] ) {
				self::action_form( 'retry_order', __( 'Retry', 'sparxsync-accounting-integration-for-reckon-one' ), array( 'order_id' => $order->get_id() ), 'button button-small' );
			} elseif ( Reckon_WC_Order_State::NEEDS_REVIEW === $s['state'] ) {
				echo '<a href="' . esc_url( $order->get_edit_order_url() ) . '">' . esc_html__( 'Review', 'sparxsync-accounting-integration-for-reckon-one' ) . '</a>';
			}
			echo '</td></tr>';
		}
		echo '</tbody></table>';
	}

	/**
	 * Print a select element.
	 *
	 * @param string $name    Field name.
	 * @param string $current Current value.
	 * @param array  $options value => label.
	 * @param string $empty   Label for the empty option.
	 */
	private static function select( $name, $current, $options, $empty ) {
		echo '<select name="' . esc_attr( $name ) . '"><option value="">' . esc_html( $empty ) . '</option>';
		foreach ( $options as $value => $label ) {
			echo '<option value="' . esc_attr( $value ) . '"' . selected( $current, $value, false ) . '>' . esc_html( $label ) . '</option>';
		}
		echo '</select>';
	}

	/**
	 * Ledger account options, income accounts first.
	 *
	 * @param array $accounts Accounts.
	 * @return array
	 */
	private static function account_options( $accounts ) {
		uasort(
			$accounts,
			function ( $a, $b ) {
				$ai = 0 === strpos( $a['type'], 'Income' ) ? 0 : 1;
				$bi = 0 === strpos( $b['type'], 'Income' ) ? 0 : 1;
				return $ai === $bi ? strcasecmp( $a['name'], $b['name'] ) : $ai - $bi;
			}
		);
		$options = array();
		foreach ( $accounts as $id => $account ) {
			$options[ $id ] = trim( ( '' !== $account['code'] ? $account['code'] . ' ' : '' ) . $account['name'] . ( '' !== $account['type'] ? ' (' . $account['type'] . ')' : '' ) );
		}
		return $options;
	}

	/**
	 * Tax rate options.
	 *
	 * @param array $rates Rates.
	 * @return array
	 */
	private static function tax_options( $rates ) {
		$options = array();
		foreach ( $rates as $id => $rate ) {
			$options[ $id ] = $rate['name'] . ( null !== $rate['rate'] ? ' (' . wc_format_decimal( $rate['rate'], '', true ) . '%)' : '' ) . ( '' !== $rate['description'] ? ' — ' . $rate['description'] : '' );
		}
		asort( $options );
		return $options;
	}
}
