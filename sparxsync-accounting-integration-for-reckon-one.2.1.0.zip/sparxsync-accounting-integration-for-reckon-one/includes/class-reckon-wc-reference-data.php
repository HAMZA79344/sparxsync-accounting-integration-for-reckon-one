<?php
/**
 * Cached Reckon reference data: books, countries (for currency), and for the
 * selected book its ledger accounts, tax rates, tax settings and address types.
 *
 * Data is only loaded when an administrator connects or presses "Refresh Reckon
 * data"; settings pages never call the API while rendering.
 *
 * @package Reckon_WC
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Reckon_WC_Reference_Data {

	const OPTION = 'reckon_wc_reference_data';

	/**
	 * Stored data.
	 *
	 * @return array
	 */
	public static function get() {
		$data = get_option( self::OPTION, array() );
		$data = is_array( $data ) ? $data : array();
		return array(
			'books'            => isset( $data['books'] ) && is_array( $data['books'] ) ? $data['books'] : array(),
			'books_fetched_at' => isset( $data['books_fetched_at'] ) ? (int) $data['books_fetched_at'] : 0,
			'book'             => isset( $data['book'] ) && is_array( $data['book'] ) ? $data['book'] : null,
		);
	}

	/**
	 * Save data (not autoloaded).
	 *
	 * @param array $data Data.
	 */
	private static function save( $data ) {
		if ( false === get_option( self::OPTION, false ) ) {
			add_option( self::OPTION, $data, '', false );
		} else {
			update_option( self::OPTION, $data, false );
		}
	}

	/**
	 * A cached book.
	 *
	 * @param string $book_id Book ID.
	 * @return array|null id, name, country, currency, status.
	 */
	public static function find_book( $book_id ) {
		$books = self::get()['books'];
		$key   = strtolower( (string) $book_id );
		return isset( $books[ $key ] ) ? $books[ $key ] : null;
	}

	/**
	 * Cached data for a book, or null when not loaded for that book.
	 *
	 * @param string $book_id Book ID.
	 * @return array|null
	 */
	public static function get_book_data( $book_id ) {
		$book = self::get()['book'];
		if ( null === $book || ! isset( $book['book_id'] ) || strtolower( $book['book_id'] ) !== strtolower( (string) $book_id ) ) {
			return null;
		}
		return $book;
	}

	/**
	 * ID of the "Email" electronic address type in a book.
	 *
	 * @param string $book_id Book ID.
	 * @return string|null
	 */
	public static function email_type_id( $book_id ) {
		$data = self::get_book_data( $book_id );
		if ( null === $data ) {
			return null;
		}
		foreach ( $data['electronic_address_types'] as $id => $name ) {
			if ( 'email' === strtolower( trim( $name ) ) ) {
				return $id;
			}
		}
		return null;
	}

	/**
	 * Load books and country currencies. Keeps previous data on failure.
	 *
	 * @return true|WP_Error
	 */
	public static function refresh_books() {
		$books = Reckon_WC_API::get_books();
		if ( is_wp_error( $books ) ) {
			return $books;
		}
		$countries = Reckon_WC_API::get_countries();
		if ( is_wp_error( $countries ) ) {
			return $countries;
		}

		$currency_by_country = array();
		foreach ( $countries as $country ) {
			if ( isset( $country['countryCode'], $country['currencyCode'] ) && is_string( $country['countryCode'] ) && is_string( $country['currencyCode'] ) ) {
				$currency_by_country[ strtoupper( $country['countryCode'] ) ] = strtoupper( $country['currencyCode'] );
			}
		}

		$normalized = array();
		foreach ( $books as $book ) {
			if ( ! isset( $book['id'] ) || ! Reckon_WC_API::is_guid( $book['id'] ) ) {
				continue;
			}
			if ( isset( $book['bookCreated'] ) && false === $book['bookCreated'] ) {
				continue;
			}
			$id                = strtolower( $book['id'] );
			$country           = isset( $book['country'] ) && is_string( $book['country'] ) ? strtoupper( $book['country'] ) : '';
			$normalized[ $id ] = array(
				'id'       => $id,
				'name'     => isset( $book['name'] ) && is_string( $book['name'] ) ? sanitize_text_field( $book['name'] ) : $id,
				'country'  => $country,
				'currency' => isset( $currency_by_country[ $country ] ) && preg_match( '/^[A-Z]{3}$/', $currency_by_country[ $country ] ) ? $currency_by_country[ $country ] : '',
				'status'   => isset( $book['status'] ) && is_string( $book['status'] ) ? $book['status'] : '',
			);
		}

		$data                     = self::get();
		$data['books']            = $normalized;
		$data['books_fetched_at'] = time();
		self::save( $data );
		Reckon_WC_OAuth::mark_verified();

		// Fill in details of an already selected book (for example after upgrading from 1.x).
		$selected = Reckon_WC_Settings::get( Reckon_WC_Settings::OPTION_BOOK );
		if ( '' !== $selected['book_id'] && isset( $normalized[ $selected['book_id'] ] ) ) {
			$book = $normalized[ $selected['book_id'] ];
			if ( $book['currency'] !== $selected['currency'] || $book['name'] !== $selected['book_name'] ) {
				$selected['book_name'] = $book['name'];
				$selected['country']   = $book['country'];
				$selected['currency']  = $book['currency'];
				update_option( Reckon_WC_Settings::OPTION_BOOK, $selected );
			}
		}
		return true;
	}

	/**
	 * Load accounts, tax rates, tax settings and address types for a book.
	 * All requests must succeed; otherwise the previous data is kept.
	 *
	 * @param string $book_id Book ID.
	 * @return true|WP_Error
	 */
	public static function refresh_book( $book_id ) {
		if ( ! Reckon_WC_API::is_guid( $book_id ) ) {
			return new WP_Error( 'reckon_wc_invalid_book', __( 'Select a book first.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}
		$book_id = strtolower( $book_id );

		$accounts = Reckon_WC_API::get_ledger_accounts( $book_id );
		if ( is_wp_error( $accounts ) ) {
			return $accounts;
		}
		$tax_rates = Reckon_WC_API::get_tax_rates( $book_id, wp_date( 'Y-m-d' ) );
		if ( is_wp_error( $tax_rates ) ) {
			return $tax_rates;
		}
		$tax_settings = Reckon_WC_API::get_tax_settings( $book_id );
		if ( is_wp_error( $tax_settings ) ) {
			return $tax_settings;
		}
		$address_types = Reckon_WC_API::get_address_types( $book_id );
		if ( is_wp_error( $address_types ) ) {
			return $address_types;
		}
		$email_types = Reckon_WC_API::get_electronic_address_types( $book_id );
		if ( is_wp_error( $email_types ) ) {
			return $email_types;
		}

		$ledger = array();
		foreach ( $accounts as $account ) {
			if ( ! isset( $account['id'] ) || ! Reckon_WC_API::is_guid( $account['id'] ) || ! self::is_active( $account ) ) {
				continue;
			}
			$name = isset( $account['fullName'] ) && is_string( $account['fullName'] ) && '' !== $account['fullName'] ? $account['fullName'] : ( isset( $account['name'] ) && is_string( $account['name'] ) ? $account['name'] : '' );
			$ledger[ strtolower( $account['id'] ) ] = array(
				'name' => sanitize_text_field( $name ),
				'type' => isset( $account['accountType'] ) && is_string( $account['accountType'] ) ? sanitize_text_field( $account['accountType'] ) : '',
				'code' => isset( $account['accountCode'] ) && is_string( $account['accountCode'] ) ? sanitize_text_field( $account['accountCode'] ) : '',
			);
		}

		$rates = array();
		foreach ( $tax_rates as $rate ) {
			if ( ! isset( $rate['id'] ) || ! Reckon_WC_API::is_guid( $rate['id'] ) || ! self::is_active( $rate ) ) {
				continue;
			}
			if ( isset( $rate['useOnSales'] ) && false === $rate['useOnSales'] ) {
				continue;
			}
			$rates[ strtolower( $rate['id'] ) ] = array(
				'name'        => isset( $rate['name'] ) && is_string( $rate['name'] ) ? sanitize_text_field( $rate['name'] ) : '',
				'description' => isset( $rate['description'] ) && is_string( $rate['description'] ) ? sanitize_text_field( $rate['description'] ) : '',
				'rate'        => isset( $rate['rate'] ) && is_numeric( $rate['rate'] ) ? (float) $rate['rate'] : null,
			);
		}

		$status = isset( $tax_settings['amountTaxStatus'] ) && is_string( $tax_settings['amountTaxStatus'] ) ? strtolower( $tax_settings['amountTaxStatus'] ) : '';
		$tax    = array(
			'tax_registered'           => isset( $tax_settings['taxRegistered'] ) ? (bool) $tax_settings['taxRegistered'] : null,
			'tax_amount_editable'      => isset( $tax_settings['taxAmountEditable'] ) ? (bool) $tax_settings['taxAmountEditable'] : null,
			'choose_amount_tax_status' => isset( $tax_settings['chooseAmountTaxStatus'] ) ? (bool) $tax_settings['chooseAmountTaxStatus'] : null,
			'amount_tax_status'        => false !== strpos( $status, 'inclusive' ) ? 'Inclusive' : ( false !== strpos( $status, 'exclusive' ) ? 'Exclusive' : '' ),
		);

		$data         = self::get();
		$data['book'] = array(
			'book_id'                  => $book_id,
			'fetched_at'               => time(),
			'ledger_accounts'          => $ledger,
			'tax_rates'                => $rates,
			'tax_settings'             => $tax,
			'address_types'            => self::names( $address_types ),
			'electronic_address_types' => self::names( $email_types ),
		);
		self::save( $data );
		Reckon_WC_OAuth::mark_verified();
		return true;
	}

	/**
	 * Map of id => name for active records.
	 *
	 * @param array $records Records.
	 * @return array
	 */
	private static function names( $records ) {
		$out = array();
		foreach ( $records as $record ) {
			if ( isset( $record['id'], $record['name'] ) && Reckon_WC_API::is_guid( $record['id'] ) && is_string( $record['name'] ) && self::is_active( $record ) ) {
				$out[ strtolower( $record['id'] ) ] = sanitize_text_field( $record['name'] );
			}
		}
		return $out;
	}

	/**
	 * Whether a record is active (records without a status are treated as active).
	 *
	 * @param array $record Record.
	 * @return bool
	 */
	private static function is_active( $record ) {
		return ! isset( $record['status'] ) || ! is_string( $record['status'] ) || 'inactive' !== strtolower( $record['status'] );
	}
}
