<?php
/**
 * Reckon Sync Handler Class
 *
 * Order events only queue work (Action Scheduler). Jobs carry the order ID and
 * the destination book ID, never credentials or customer data. The worker:
 * - takes an atomic per-order lock,
 * - re-reads the order, settings, connection, book and mappings,
 * - builds and reconciles the invoice,
 * - finds or creates the customer,
 * - checks Reckon for an invoice already carrying the order's reference,
 * - records a "create attempted" marker before sending the invoice.
 *
 * If the outcome of a create request is unknown (timeout, 5xx, malformed
 * response), the invoice is never blindly re-sent. The next run looks the
 * invoice up by reference; if exactly one is found it is linked, otherwise the
 * order is marked "Needs review" for an administrator.
 *
 * Reckon does not document an idempotency key for invoice creation, so this is
 * duplicate protection, not a guarantee of exactly-once delivery.
 *
 * @package Reckon_WC
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Reckon_WC_Sync {

	const HOOK            = 'reckon_wc_sync_order';
	const VERIFY_HOOK     = 'reckon_wc_verify_invoice';
	const RECOVER_HOOK    = 'reckon_wc_recover_verification';
	const GROUP           = 'reckon-wc';
	const LOCK_TTL        = 600;
	const MAX_ATTEMPTS    = 5;
	const MAX_VERIFY_ATTEMPTS = 5;
	const RECONCILE_DELAY = 300;
	const MAX_RETRY_AFTER = 21600;

	// Transient holding the dashboard's 30-day figures; cleared whenever an invoice is linked.
	const STATS_CACHE     = 'reckon_wc_dashboard_stats';

	/**
	 * Delay before retry N (1-based), in seconds.
	 *
	 * @var int[]
	 */
	const BACKOFF = array( 60, 300, 900, 1800, 3600 );

	/**
	 * Statuses for which no invoice is ever created.
	 *
	 * @var string[]
	 */
	const NEVER_INVOICE = array( 'pending', 'failed', 'cancelled', 'refunded', 'checkout-draft', 'trash' );

	/**
	 * Register hooks.
	 */
	public static function init() {
		add_action( 'woocommerce_order_status_changed', array( __CLASS__, 'on_status_changed' ), 10, 4 );
		add_action( 'woocommerce_order_refunded', array( __CLASS__, 'on_refunded' ), 10, 2 );
		add_action( self::HOOK, array( __CLASS__, 'run_job' ), 10, 2 );
		add_action( self::VERIFY_HOOK, array( __CLASS__, 'run_verify_job' ), 10, 2 );
		add_action( self::RECOVER_HOOK, array( __CLASS__, 'maybe_recover_verification' ) );
		add_action( 'init', array( __CLASS__, 'maybe_schedule_verification_recovery' ) );
	}

	/**
	 * Action Scheduler arguments for an order.
	 *
	 * @param int    $order_id Order ID.
	 * @param string $book_id  Book ID.
	 * @return array
	 */
	public static function job_args( $order_id, $book_id ) {
		return array(
			'order_id' => (int) $order_id,
			'book_id'  => (string) $book_id,
		);
	}

	/**
	 * Queue eligible orders when their status changes. Returns quickly; no API calls.
	 *
	 * @param int           $order_id Order ID.
	 * @param string        $from     Old status.
	 * @param string        $to       New status.
	 * @param WC_Order|null $order    Order.
	 */
	public static function on_status_changed( $order_id, $from, $to, $order = null ) {
		$order = $order instanceof WC_Order ? $order : wc_get_order( $order_id );
		if ( ! $order ) {
			return;
		}
		if ( in_array( $to, array( 'cancelled', 'refunded' ), true ) ) {
			self::flag_accounting_review( $order, $to );
			return;
		}
		$settings = Reckon_WC_Settings::get( Reckon_WC_Settings::OPTION_SYNC );
		if ( ! $settings['enabled'] || ! in_array( $to, $settings['order_statuses'], true ) ) {
			return;
		}
		self::queue_order( $order, 'automatic' );
	}

	/**
	 * Flag synchronized orders that receive a refund.
	 *
	 * @param int $order_id  Order ID.
	 * @param int $refund_id Refund ID.
	 */
	public static function on_refunded( $order_id, $refund_id ) {
		$order = wc_get_order( $order_id );
		if ( $order ) {
			self::flag_accounting_review( $order, 'refunded' === $order->get_status() ? 'refunded' : 'partially_refunded' );
		}
	}

	/**
	 * Flag an order whose Reckon invoice may need a manual credit note or adjustment.
	 * Nothing is changed in Reckon.
	 *
	 * @param WC_Order $order  Order.
	 * @param string   $reason cancelled|refunded|partially_refunded|refunded_before_sync.
	 */
	public static function flag_accounting_review( $order, $reason ) {
		$invoice_id = Reckon_WC_Order_State::get_invoice_id( $order );
		if ( '' === $invoice_id ) {
			return;
		}
		$existing = $order->get_meta( Reckon_WC_Order_State::ACCOUNTING_REVIEW, true );
		if ( is_array( $existing ) && isset( $existing['reason'] ) && $existing['reason'] === $reason ) {
			return;
		}
		$order->update_meta_data(
			Reckon_WC_Order_State::ACCOUNTING_REVIEW,
			array(
				'reason' => $reason,
				'at'     => time(),
			)
		);
		$order->save();
		$labels = array(
			'cancelled'            => __( 'cancelled', 'sparxsync-accounting-integration-for-reckon-one' ),
			'refunded'             => __( 'refunded', 'sparxsync-accounting-integration-for-reckon-one' ),
			'partially_refunded'   => __( 'partially refunded', 'sparxsync-accounting-integration-for-reckon-one' ),
			'refunded_before_sync' => __( 'refunded before synchronization (the invoice shows the original sale)', 'sparxsync-accounting-integration-for-reckon-one' ),
		);
		$order->add_order_note(
			sprintf(
				/* translators: 1: reason, 2: Reckon invoice ID. */
				__( 'Reckon One: this order was %1$s after Reckon invoice %2$s was created. No credit note or change was made in Reckon automatically. Review the invoice in Reckon.', 'sparxsync-accounting-integration-for-reckon-one' ),
				isset( $labels[ $reason ] ) ? $labels[ $reason ] : $reason,
				$invoice_id
			)
		);
		Reckon_WC_Logger::info( 'Order flagged for accounting review: ' . $reason . '.', array( 'operation' => 'accounting_review', 'order_id' => $order->get_id() ) );
	}

	/**
	 * Queue an order for synchronization.
	 *
	 * @param WC_Order $order  Order.
	 * @param string   $source automatic|manual.
	 * @return string|WP_Error queued|already_queued|already_synced|in_progress|failed_needs_manual_retry.
	 */
	public static function queue_order( $order, $source = 'automatic' ) {
		if ( ! Reckon_WC_Integration::scheduler_available() ) {
			$error = new WP_Error( 'reckon_wc_scheduler_unavailable', __( 'Action Scheduler is not available, so the order could not be queued.', 'sparxsync-accounting-integration-for-reckon-one' ) );
			if ( 'automatic' === $source ) {
				$order->update_meta_data( Reckon_WC_Order_State::STATE, Reckon_WC_Order_State::FAILED );
				Reckon_WC_Order_State::set_error( $order, $error );
				$order->save();
			}
			return $error;
		}

		$state = Reckon_WC_Order_State::get_state( $order );
		// Once an invoice ID exists, normal creation queueing must never overwrite
		// the verification state or the destination book. Verification is handled by
		// a separate read-only operation.
		if ( '' !== Reckon_WC_Order_State::get_invoice_id( $order ) ) {
			return Reckon_WC_Order_State::VERIFY_PENDING === $state ? 'verification_pending' : 'already_synced';
		}
		if ( ! Reckon_WC_Settings::get( Reckon_WC_Settings::OPTION_SYNC )['enabled'] ) {
			return new WP_Error( 'reckon_wc_sync_disabled', __( 'Synchronization is disabled in the Reckon One settings.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}
		if ( Reckon_WC_Order_State::NEEDS_REVIEW === $state ) {
			return new WP_Error( 'reckon_wc_needs_review', __( 'This order needs review before it can be queued again.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}
		if ( in_array( $order->get_status(), self::NEVER_INVOICE, true ) ) {
			/* translators: %s: order status. */
			return new WP_Error( 'reckon_wc_order_not_eligible', sprintf( __( 'Orders with status "%s" are not invoiced.', 'sparxsync-accounting-integration-for-reckon-one' ), wc_get_order_status_name( $order->get_status() ) ) );
		}

		$order_id = $order->get_id();
		$stamped  = (string) $order->get_meta( Reckon_WC_Order_State::BOOK_ID, true );
		if ( in_array( $state, array( Reckon_WC_Order_State::QUEUED, Reckon_WC_Order_State::IN_PROGRESS ), true ) ) {
			if ( as_has_scheduled_action( self::HOOK, self::job_args( $order_id, $stamped ), self::GROUP ) ) {
				return 'already_queued';
			}
			if ( Reckon_WC_Lock::is_locked( 'order_' . $order_id ) ) {
				return 'in_progress';
			}
			// Otherwise the job was lost (e.g. deactivation or a crashed worker); re-queue below.
		}
		if ( 'automatic' === $source && Reckon_WC_Order_State::FAILED === $state ) {
			return 'failed_needs_manual_retry';
		}

		$book_id = Reckon_WC_Settings::get( Reckon_WC_Settings::OPTION_BOOK )['book_id'];
		$marker  = $order->get_meta( Reckon_WC_Order_State::CREATE_ATTEMPT, true );
		if ( is_array( $marker ) && ! empty( $marker['book_id'] ) ) {
			// An earlier create request may have succeeded in that book: always reconcile there.
			$book_id = (string) $marker['book_id'];
		}
		if ( '' === $book_id ) {
			$error = new WP_Error( 'reckon_wc_book_missing', __( 'No Reckon book is selected.', 'sparxsync-accounting-integration-for-reckon-one' ) );
			$order->update_meta_data( Reckon_WC_Order_State::STATE, Reckon_WC_Order_State::FAILED );
			Reckon_WC_Order_State::set_error( $order, $error );
			$order->save();
			return $error;
		}

		Reckon_WC_Order_State::get_reference( $order );
		$order->update_meta_data( Reckon_WC_Order_State::STATE, Reckon_WC_Order_State::QUEUED );
		$order->update_meta_data( Reckon_WC_Order_State::BOOK_ID, $book_id );
		$order->update_meta_data( Reckon_WC_Order_State::QUEUED_AT, time() );
		$order->update_meta_data( Reckon_WC_Order_State::NEXT_ATTEMPT_AT, time() );
		if ( 'manual' === $source ) {
			$order->update_meta_data( Reckon_WC_Order_State::ATTEMPTS, 0 );
		}
		$order->save();

		$action_id = as_enqueue_async_action( self::HOOK, self::job_args( $order_id, $book_id ), self::GROUP, true );
		if ( ! $action_id ) {
			// A false return from as_enqueue_async_action() is not proof that the job
			// is already queued. Re-check; otherwise report a recoverable error and
			// preserve the accounting-safety state instead of silently dropping work.
			if ( as_has_scheduled_action( self::HOOK, self::job_args( $order_id, $book_id ), self::GROUP ) ) {
				return 'already_queued';
			}
			$error = new WP_Error( 'reckon_wc_enqueue_failed', __( 'The order could not be queued because the scheduler did not accept the job.', 'sparxsync-accounting-integration-for-reckon-one' ), array( 'retryable' => true ) );
			self::fail_order( $order, $error );
			return $error;
		}
		Reckon_WC_Logger::debug( 'Order queued (' . $source . ').', array( 'operation' => 'queue', 'order_id' => $order_id, 'book_id' => $book_id ) );
		return 'queued';
	}

	/**
	 * Action Scheduler callback.
	 *
	 * @param int    $order_id Order ID.
	 * @param string $book_id  Book ID the job was queued for.
	 */
	public static function run_job( $order_id, $book_id = '' ) {
		$order_id = absint( $order_id );
		if ( ! $order_id || ! wc_get_order( $order_id ) ) {
			Reckon_WC_Logger::warning( 'Queued order no longer exists; job skipped.', array( 'operation' => 'sync', 'order_id' => $order_id ) );
			return;
		}

		$lock = Reckon_WC_Lock::acquire( 'order_' . $order_id, self::LOCK_TTL );
		if ( false === $lock ) {
			Reckon_WC_Logger::info( 'Another worker is processing this order; job skipped.', array( 'operation' => 'sync', 'order_id' => $order_id ) );
			return;
		}

		try {
			self::process( $order_id, (string) $book_id, $lock );
		} catch ( Throwable $e ) {
			Reckon_WC_Logger::error( 'Unexpected ' . get_class( $e ) . ': ' . $e->getMessage(), array( 'operation' => 'sync', 'order_id' => $order_id ) );
			$order = wc_get_order( $order_id );
			if ( $order ) {
				$error = new WP_Error( 'reckon_wc_unexpected_error', __( 'An unexpected error stopped synchronization. See the WooCommerce log (source reckon-wc).', 'sparxsync-accounting-integration-for-reckon-one' ) );
				if ( is_array( $order->get_meta( Reckon_WC_Order_State::CREATE_ATTEMPT, true ) ) ) {
					self::needs_review( $order, 'unexpected_error_after_send', __( 'An unexpected error occurred after the invoice request may have been sent. Check Reckon for this order\'s reference before retrying.', 'sparxsync-accounting-integration-for-reckon-one' ) );
				} else {
					self::fail_order( $order, $error );
				}
			}
		} finally {
			Reckon_WC_Lock::release( 'order_' . $order_id, $lock );
		}
	}

	/**
	 * Process one order while holding its lock.
	 *
	 * @param int    $order_id Order ID.
	 * @param string $job_book Book ID from the job.
	 * @param string $lock     Order lock token.
	 */
	private static function process( $order_id, $job_book, $lock ) {
		// Re-read after locking so changes by another worker are seen.
		$order = wc_get_order( $order_id );
		$state = Reckon_WC_Order_State::get_state( $order );
		if ( ! in_array( $state, array( Reckon_WC_Order_State::QUEUED, Reckon_WC_Order_State::IN_PROGRESS ), true ) ) {
			Reckon_WC_Logger::debug( 'Order is not queued (' . $state . '); job ignored.', array( 'operation' => 'sync', 'order_id' => $order_id ) );
			return;
		}
		$stamped = (string) $order->get_meta( Reckon_WC_Order_State::BOOK_ID, true );
		if ( $stamped !== $job_book ) {
			Reckon_WC_Logger::debug( 'Job was queued for a different book than the order now targets; ignored.', array( 'operation' => 'sync', 'order_id' => $order_id ) );
			return;
		}
		$marker = $order->get_meta( Reckon_WC_Order_State::CREATE_ATTEMPT, true );
		$marker = is_array( $marker ) ? $marker : null;

		$blocker = Reckon_WC_Settings::sync_blocker();
		if ( null !== $blocker ) {
			self::fail_order( $order, $blocker );
			return;
		}

		$book = Reckon_WC_Settings::get( Reckon_WC_Settings::OPTION_BOOK );
		if ( $job_book !== $book['book_id'] ) {
			if ( null !== $marker ) {
				self::needs_review( $order, 'book_changed_unknown_outcome', __( 'The destination book changed while the outcome of an earlier invoice request was unknown. Check the original book for this order\'s reference.', 'sparxsync-accounting-integration-for-reckon-one' ) );
			} else {
				self::fail_order( $order, new WP_Error( 'reckon_wc_book_changed', __( 'The Reckon book changed after this order was queued. It was not sent to the new book. Queue it again if it should go to the new book.', 'sparxsync-accounting-integration-for-reckon-one' ) ) );
			}
			return;
		}

		if ( null === $marker && in_array( $order->get_status(), self::NEVER_INVOICE, true ) ) {
			$order->update_meta_data( Reckon_WC_Order_State::STATE, Reckon_WC_Order_State::NOT_QUEUED );
			$order->delete_meta_data( Reckon_WC_Order_State::NEXT_ATTEMPT_AT );
			/* translators: %s: order status. */
			Reckon_WC_Order_State::set_error( $order, new WP_Error( 'reckon_wc_order_not_eligible', sprintf( __( 'The order status changed to "%s" before synchronization; no invoice was created.', 'sparxsync-accounting-integration-for-reckon-one' ), $order->get_status() ) ) );
			$order->save();
			return;
		}

		$attempt = (int) $order->get_meta( Reckon_WC_Order_State::ATTEMPTS, true ) + 1;
		$order->update_meta_data( Reckon_WC_Order_State::ATTEMPTS, $attempt );
		$order->update_meta_data( Reckon_WC_Order_State::LAST_ATTEMPT_AT, time() );
		$order->update_meta_data( Reckon_WC_Order_State::STATE, Reckon_WC_Order_State::IN_PROGRESS );
		$order->delete_meta_data( Reckon_WC_Order_State::NEXT_ATTEMPT_AT );
		$order->save();

		if ( null !== $marker ) {
			self::reconcile( $order, $marker );
			return;
		}

		$book_id  = $book['book_id'];
		$mappings = Reckon_WC_Settings::get( Reckon_WC_Settings::OPTION_MAPPINGS );
		$ref_data = Reckon_WC_Reference_Data::get_book_data( $book_id );

		$prepared = Reckon_WC_Invoice_Builder::prepare( $order, $mappings, $book, $ref_data['tax_settings'] );
		if ( is_wp_error( $prepared ) ) {
			self::fail_order( $order, $prepared );
			return;
		}

		$item_ids = self::resolve_items( $prepared, $book_id, $mappings['product_policy'] );
		if ( is_wp_error( $item_ids ) ) {
			self::handle_error( $order, $item_ids );
			return;
		}

		$customer_id = Reckon_WC_Customer_Resolver::resolve( $order, $book_id, $mappings );
		if ( is_wp_error( $customer_id ) ) {
			self::handle_error( $order, $customer_id );
			return;
		}

		$reference = Reckon_WC_Order_State::get_reference( $order );
		$payload   = Reckon_WC_Invoice_Builder::build_payload( $prepared, $order, $customer_id, $item_ids, $reference, $mappings );
		if ( is_wp_error( $payload ) ) {
			self::fail_order( $order, $payload );
			return;
		}
		if ( Reckon_WC_Invoice_Builder::payload_totals( $payload, $prepared['dp'] ) !== $prepared['totals'] ) {
			self::fail_order( $order, new WP_Error( 'reckon_wc_payload_mismatch', __( 'The invoice lines do not add up to the order totals. Nothing was sent.', 'sparxsync-accounting-integration-for-reckon-one' ) ) );
			return;
		}

		// Duplicate guard: an invoice with this reference may already exist (e.g. after a database restore).
		$existing = Reckon_WC_API::find_invoices_by_reference( $book_id, $reference );
		if ( is_wp_error( $existing ) ) {
			self::handle_error( $order, $existing );
			return;
		}
		if ( count( $existing ) > 1 ) {
			self::needs_review( $order, 'duplicate_invoices', __( 'More than one Reckon invoice already carries this order\'s reference. Resolve the duplicates in Reckon, then link the correct invoice.', 'sparxsync-accounting-integration-for-reckon-one' ) );
			return;
		}
		if ( 1 === count( $existing ) ) {
			self::link_invoice( $order, $book_id, strtolower( $existing[0]['id'] ), 'found', $prepared['totals'] );
			return;
		}

		// Never send if another worker took the lock over while this one was slow.
		if ( ! Reckon_WC_Lock::refresh( 'order_' . $order_id, $lock, self::LOCK_TTL ) ) {
			Reckon_WC_Logger::warning( 'Order lock was lost before sending; this worker stopped without sending.', array( 'operation' => 'invoice_create', 'order_id' => $order_id ) );
			return;
		}

		// Record the attempt and the immutable export snapshot before sending, so a
		// crash or timeout can never lead to a blind resend, and a later order edit
		// cannot change the values that are reconciled and verified.
		$order->update_meta_data(
			Reckon_WC_Order_State::CREATE_ATTEMPT,
			array(
				'book_id'    => $book_id,
				'reference'  => $reference,
				'started_at' => time(),
				'attempt'    => $attempt,
			)
		);
		$order->update_meta_data( Reckon_WC_Order_State::CUSTOMER_ID, $customer_id );
		$order->update_meta_data( Reckon_WC_Order_State::EXPORT_RECORD, self::export_snapshot( $order, $book_id, $reference, $customer_id, $prepared['totals'] ) );
		$order->save();
		$check = wc_get_order( $order_id );
		if ( ! $check || ! is_array( $check->get_meta( Reckon_WC_Order_State::CREATE_ATTEMPT, true ) ) || ! is_array( $check->get_meta( Reckon_WC_Order_State::EXPORT_RECORD, true ) ) ) {
			self::handle_error( $order, new WP_Error( 'reckon_wc_marker_not_saved', __( 'The order could not be updated before sending, so nothing was sent.', 'sparxsync-accounting-integration-for-reckon-one' ), array( 'retryable' => true, 'outcome' => 'not_sent' ) ) );
			return;
		}

		Reckon_WC_Logger::info( 'Creating Reckon invoice.', array( 'operation' => 'invoice_create', 'order_id' => $order_id, 'attempt' => $attempt, 'book_id' => $book_id ) );
		$invoice_id = Reckon_WC_API::create_invoice( $book_id, $payload );

		if ( ! is_wp_error( $invoice_id ) ) {
			self::link_invoice( $order, $book_id, $invoice_id, 'created', $prepared['totals'], $prepared['adjustments'] );
			return;
		}

		$outcome = Reckon_WC_API::error_data( $invoice_id, 'outcome', 'unknown' );
		Reckon_WC_Logger::warning(
			'Invoice request failed; outcome: ' . $outcome . '.',
			array(
				'operation'   => 'invoice_create',
				'order_id'    => $order_id,
				'attempt'     => $attempt,
				'http_status' => Reckon_WC_API::error_data( $invoice_id, 'status', 0 ),
				'error_code'  => $invoice_id->get_error_code(),
			)
		);
		if ( 'unknown' === $outcome ) {
			// Keep the marker. The next run looks the invoice up instead of sending again.
			self::schedule_retry( $order, $invoice_id, self::RECONCILE_DELAY );
			return;
		}
		// Rejected or never sent: nothing was created, so the marker is removed.
		$order->delete_meta_data( Reckon_WC_Order_State::CREATE_ATTEMPT );
		self::handle_error( $order, $invoice_id );
	}

	/**
	 * Resolve Reckon item IDs for product lines according to the product policy.
	 *
	 * @param array  $prepared Prepared invoice.
	 * @param string $book_id  Book ID.
	 * @param string $policy   require_item|item_or_account|account_only.
	 * @return array|WP_Error WooCommerce item ID => Reckon item ID.
	 */
	private static function resolve_items( $prepared, $book_id, $policy ) {
		if ( 'account_only' === $policy ) {
			return array();
		}
		$ids     = array();
		$cache   = array();
		$missing = array();
		foreach ( $prepared['lines'] as $line ) {
			if ( 'product' !== $line['kind'] ) {
				continue;
			}
			$reason = '';
			if ( ! $line['product_exists'] ) {
				$reason = __( 'product deleted', 'sparxsync-accounting-integration-for-reckon-one' );
			} elseif ( '' === $line['sku'] ) {
				$reason = __( 'no SKU', 'sparxsync-accounting-integration-for-reckon-one' );
			} else {
				$sku = $line['sku'];
				if ( ! array_key_exists( $sku, $cache ) ) {
					$items = Reckon_WC_API::find_items_by_code( $book_id, $sku );
					if ( is_wp_error( $items ) ) {
						if ( 'reckon_wc_unsafe_filter_value' !== $items->get_error_code() ) {
							return $items;
						}
						$cache[ $sku ] = array( 'error' => __( 'SKU cannot be searched safely', 'sparxsync-accounting-integration-for-reckon-one' ) );
					} else {
						$exact = array_values(
							array_filter(
								$items,
								function ( $item ) use ( $sku ) {
									return isset( $item['id'], $item['itemCode'] ) && Reckon_WC_API::is_guid( $item['id'] ) && $item['itemCode'] === $sku;
								}
							)
						);
						$active = array_values(
							array_filter(
								$exact,
								function ( $item ) {
									return ! isset( $item['status'] ) || 'inactive' !== strtolower( (string) $item['status'] );
								}
							)
						);
						if ( count( $active ) > 1 ) {
							/* translators: %s: SKU. */
							return new WP_Error( 'reckon_wc_item_ambiguous', sprintf( __( 'More than one active Reckon item has the item code "%s".', 'sparxsync-accounting-integration-for-reckon-one' ), $sku ), array( 'retryable' => false ) );
						}
						if ( 1 === count( $active ) ) {
							$cache[ $sku ] = array( 'id' => strtolower( $active[0]['id'] ) );
						} else {
							$cache[ $sku ] = array( 'error' => empty( $exact ) ? __( 'no Reckon item with this code', 'sparxsync-accounting-integration-for-reckon-one' ) : __( 'Reckon item is inactive', 'sparxsync-accounting-integration-for-reckon-one' ) );
						}
					}
				}
				if ( isset( $cache[ $sku ]['id'] ) ) {
					$ids[ $line['item_id'] ] = $cache[ $sku ]['id'];
					continue;
				}
				$reason = $cache[ $sku ]['error'];
			}
			if ( 'require_item' === $policy ) {
				$missing[] = sprintf( '"%s" (%s%s)', $line['name'], '' === $line['sku'] ? '' : 'SKU ' . $line['sku'] . ', ', $reason );
			}
		}
		if ( ! empty( $missing ) ) {
			return new WP_Error(
				'reckon_wc_item_not_found',
				/* translators: %s: list of lines. */
				sprintf( __( 'These lines have no matching Reckon item, and the product policy requires one: %s. Create the items in Reckon with matching item codes, or change the product policy.', 'sparxsync-accounting-integration-for-reckon-one' ), implode( '; ', $missing ) ),
				array( 'retryable' => false )
			);
		}
		return $ids;
	}

	/**
	 * Look up an invoice whose creation outcome was unknown.
	 *
	 * @param WC_Order $order  Order.
	 * @param array    $marker Create-attempt marker.
	 */
	private static function reconcile( $order, $marker ) {
		$book_id   = isset( $marker['book_id'] ) ? (string) $marker['book_id'] : '';
		$reference = isset( $marker['reference'] ) ? (string) $marker['reference'] : '';
		$found     = Reckon_WC_API::find_invoices_by_reference( $book_id, $reference );
		if ( is_wp_error( $found ) ) {
			if ( Reckon_WC_API::error_data( $found, 'retryable', false ) ) {
				self::schedule_retry( $order, $found );
			} else {
				/* translators: %s: error message. */
				self::needs_review( $order, 'reconcile_failed', sprintf( __( 'The outcome of an earlier invoice request is unknown and Reckon could not be searched for the invoice: %s', 'sparxsync-accounting-integration-for-reckon-one' ), $found->get_error_message() ) );
			}
			return;
		}
		if ( 1 === count( $found ) ) {
			self::link_invoice( $order, $book_id, strtolower( $found[0]['id'] ), 'reconciled', null );
			return;
		}
		if ( count( $found ) > 1 ) {
			self::needs_review( $order, 'duplicate_invoices', __( 'More than one Reckon invoice carries this order\'s reference. Resolve the duplicates in Reckon, then link the correct invoice.', 'sparxsync-accounting-integration-for-reckon-one' ) );
			return;
		}
		self::needs_review(
			$order,
			'unknown_outcome_not_found',
			/* translators: %s: invoice reference. */
			sprintf( __( 'An earlier invoice request had an unknown outcome and no Reckon invoice with reference %s was found. Check Reckon. If no invoice exists, use "Confirm no Reckon invoice exists and retry"; if one exists, link it.', 'sparxsync-accounting-integration-for-reckon-one' ), $reference )
		);
	}

	/**
	 * Store a remote invoice ID and verify the remote totals.
	 *
	 * @param WC_Order   $order       Order.
	 * @param string     $book_id     Book ID.
	 * @param string     $invoice_id  Validated invoice ID.
	 * @param string     $how         created|found|reconciled|linked.
	 * @param array|null $totals      Expected totals in minor units.
	 * @param int        $adjustments Rounding adjustments applied.
	 */
	public static function link_invoice( $order, $book_id, $invoice_id, $how, $totals = null, $adjustments = 0 ) {
		$order->update_meta_data( Reckon_WC_Order_State::INVOICE_ID, $invoice_id );
		$order->update_meta_data( Reckon_WC_Order_State::BOOK_ID, $book_id );
		$order->update_meta_data( Reckon_WC_Order_State::STATE, Reckon_WC_Order_State::VERIFY_PENDING );
		$order->update_meta_data( Reckon_WC_Order_State::SYNCED_AT, time() );
		delete_transient( self::STATS_CACHE );
		foreach ( array( Reckon_WC_Order_State::CREATE_ATTEMPT, Reckon_WC_Order_State::NEXT_ATTEMPT_AT, Reckon_WC_Order_State::REVIEW_REASON, Reckon_WC_Order_State::LAST_ERROR, Reckon_WC_Order_State::VERIFY_ATTEMPTS ) as $key ) {
			$order->delete_meta_data( $key );
		}

		// If an immutable export snapshot was written before the invoice POST, keep it
		// (do not recompute from the current order, which may have been edited). For a
		// manual link or a "found" invoice, record a distinct comparison snapshot.
		$existing    = $order->get_meta( Reckon_WC_Order_State::EXPORT_RECORD, true );
		$is_exported = is_array( $existing )
			&& isset( $existing['kind'], $existing['book_id'] )
			&& 'exported' === $existing['kind']
			&& (string) $existing['book_id'] === (string) $book_id
			&& in_array( $how, array( 'created', 'reconciled' ), true );
		if ( $is_exported ) {
			$existing['invoice_id'] = $invoice_id;
			$existing['how']        = $how;
			$order->update_meta_data( Reckon_WC_Order_State::EXPORT_RECORD, $existing );
		} else {
			$order->update_meta_data( Reckon_WC_Order_State::EXPORT_RECORD, self::comparison_snapshot( $order, $book_id, $invoice_id, $how, $totals ) );
		}
		$order->save();

		$book  = Reckon_WC_Settings::get( Reckon_WC_Settings::OPTION_BOOK );
		$notes = array(
			/* translators: 1: invoice ID, 2: book name. */
			'created'    => __( 'Reckon One: invoice %1$s created in book "%2$s".', 'sparxsync-accounting-integration-for-reckon-one' ),
			/* translators: 1: invoice ID, 2: book name. */
			'found'      => __( 'Reckon One: an existing invoice %1$s with this order\'s reference was found in book "%2$s" and linked; no new invoice was created.', 'sparxsync-accounting-integration-for-reckon-one' ),
			/* translators: 1: invoice ID, 2: book name. */
			'reconciled' => __( 'Reckon One: the earlier invoice request succeeded; invoice %1$s in book "%2$s" was found by reference and linked.', 'sparxsync-accounting-integration-for-reckon-one' ),
			/* translators: 1: invoice ID, 2: book name. */
			'linked'     => __( 'Reckon One: linked to existing invoice %1$s in book "%2$s" by an administrator.', 'sparxsync-accounting-integration-for-reckon-one' ),
		);
		$note = sprintf( isset( $notes[ $how ] ) ? $notes[ $how ] : $notes['created'], $invoice_id, $book['book_id'] === $book_id ? $book['book_name'] : $book_id );
		if ( $adjustments > 0 ) {
			/* translators: %d: number of minor units. */
			$note .= ' ' . sprintf( _n( 'A rounding difference of %d minor unit was allocated across the lines so the invoice total equals the order total.', 'Rounding differences of %d minor units were allocated across the lines so the invoice total equals the order total.', $adjustments, 'sparxsync-accounting-integration-for-reckon-one' ), $adjustments );
		}
		$order->add_order_note( $note );
		Reckon_WC_Logger::info( 'Order linked to Reckon invoice ' . $invoice_id . ' (' . $how . ').', array( 'operation' => 'invoice_link', 'order_id' => $order->get_id(), 'book_id' => $book_id ) );

		if ( $order->get_total_refunded() > 0 ) {
			self::flag_accounting_review( $order, 'refunded_before_sync' );
		}

		self::verify_remote_totals( $order, $book_id, $invoice_id );
	}

	/**
	 * Expected invoice totals for verification.
	 *
	 * @param WC_Order   $order  Order.
	 * @param array|null $totals Totals in minor units when known (net_c, tax_c, gross_c).
	 * @return array gross_c, tax_c, net_c, dp, currency.
	 */
	private static function expected_totals( $order, $totals ) {
		$dp     = Reckon_WC_Invoice_Builder::currency_decimals( $order->get_currency() );
		$scale  = pow( 10, $dp );
		$currency = strtoupper( (string) $order->get_currency() );
		if ( is_array( $totals ) && isset( $totals['gross_c'], $totals['tax_c'] ) ) {
			$gross_c = (int) $totals['gross_c'];
			$tax_c   = (int) $totals['tax_c'];
			return array(
				'gross_c' => $gross_c,
				'tax_c'   => $tax_c,
				'net_c'   => $gross_c - $tax_c,
				'dp'      => $dp,
				'currency' => $currency,
			);
		}
		$gross_c = (int) round( (float) $order->get_total() * $scale );
		$tax_c   = (int) round( (float) $order->get_total_tax() * $scale );
		return array(
			'gross_c' => $gross_c,
			'tax_c'   => $tax_c,
			'net_c'   => $gross_c - $tax_c,
			'dp'      => $dp,
			'currency' => $currency,
		);
	}

	/**
	 * Immutable evidence of what this plugin is about to export. Written before the
	 * invoice POST so a lost response and a later order edit cannot corrupt it.
	 *
	 * @param WC_Order $order       Order.
	 * @param string   $book_id     Book ID.
	 * @param string   $reference   Invoice reference.
	 * @param string   $customer_id Customer ID.
	 * @param array    $totals      Expected totals in minor units.
	 * @return array
	 */
	private static function export_snapshot( $order, $book_id, $reference, $customer_id, $totals ) {
		$base = self::expected_totals( $order, $totals );
		return array_merge(
			$base,
			array(
				'kind'        => 'exported',
				'book_id'     => $book_id,
				'reference'   => $reference,
				'customer_id' => $customer_id,
				'order_total' => (float) $order->get_total(),
				'order_tax'   => (float) $order->get_total_tax(),
				'exported_at' => time(),
			)
		);
	}

	/**
	 * Comparison snapshot for an invoice that was linked (not originally exported by
	 * this plugin). Kept distinct from the immutable export evidence above.
	 *
	 * @param WC_Order $order      Order.
	 * @param string   $book_id    Book ID.
	 * @param string   $invoice_id Invoice ID.
	 * @param string   $how        linked|found.
	 * @param array    $totals     Expected totals in minor units.
	 * @return array
	 */
	private static function comparison_snapshot( $order, $book_id, $invoice_id, $how, $totals ) {
		$base = self::expected_totals( $order, $totals );
		return array_merge(
			$base,
			array(
				'kind'        => 'comparison',
				'book_id'     => $book_id,
				'invoice_id'  => $invoice_id,
				'how'         => $how,
				// Existing association evidence (never auto-generated here).
				'reference'   => (string) $order->get_meta( Reckon_WC_Order_State::REFERENCE, true ),
				'customer_id' => (string) $order->get_meta( Reckon_WC_Order_State::CUSTOMER_ID, true ),
				'order_total' => (float) $order->get_total(),
				'order_tax'   => (float) $order->get_total_tax(),
				'exported_at' => time(),
			)
		);
	}

	/**
	 * Compare the Reckon invoice totals with the immutable export record.
	 *
	 * Verification is separated from creation: the known invoice ID is retained
	 * immediately, and the order stays in "verification pending" until the remote
	 * totals are read back and match. A failed read-back schedules a bounded,
	 * read-only retry; it never creates another invoice.
	 *
	 * @param WC_Order $order      Order.
	 * @param string   $book_id    Book ID.
	 * @param string   $invoice_id Invoice ID.
	 */
	private static function verify_remote_totals( $order, $book_id, $invoice_id ) {
		$record = $order->get_meta( Reckon_WC_Order_State::EXPORT_RECORD, true );
		if ( ! is_array( $record ) || ! isset( $record['gross_c'] ) ) {
			// Without a snapshot there is nothing to verify against. Do not fabricate
			// a verification from the current (possibly edited) order totals.
			self::verification_retry( $order, new WP_Error( 'reckon_wc_missing_export_record', __( 'The invoice export snapshot is missing, so the totals could not be verified.', 'sparxsync-accounting-integration-for-reckon-one' ), array( 'retryable' => false ) ) );
			return;
		}
		$dp    = isset( $record['dp'] ) ? (int) $record['dp'] : Reckon_WC_Invoice_Builder::currency_decimals( $order->get_currency() );
		$scale = pow( 10, $dp );

		$invoice = Reckon_WC_API::get_invoice( $book_id, $invoice_id );
		if ( is_wp_error( $invoice ) ) {
			self::verification_retry( $order, $invoice );
			return;
		}
		if ( ! isset( $invoice['totalAmount'] ) || ! is_numeric( $invoice['totalAmount'] ) ) {
			self::verification_retry( $order, new WP_Error( 'reckon_wc_invoice_missing_total', __( 'Reckon returned the invoice without a total amount, so it could not be verified.', 'sparxsync-accounting-integration-for-reckon-one' ), array( 'retryable' => true ) ) );
			return;
		}

		$remote_gross = (int) round( (float) $invoice['totalAmount'] * $scale );
		$remote_tax   = null;
		if ( array_key_exists( 'totalTaxAmount', $invoice ) && is_numeric( $invoice['totalTaxAmount'] ) ) {
			$remote_tax = (int) round( (float) $invoice['totalTaxAmount'] * $scale );
		}

		// A missing or non-numeric tax total is not proof of zero tax, even for a
		// zero-tax order. Verification stays pending rather than fabricating a match.
		if ( null === $remote_tax ) {
			self::verification_retry( $order, new WP_Error( 'reckon_wc_invoice_missing_tax', __( 'Reckon returned the invoice without a tax total, so it could not be verified.', 'sparxsync-accounting-integration-for-reckon-one' ), array( 'retryable' => true ) ) );
			return;
		}

		// Matching totals alone are not proof of identity. Validate the association
		// strictly: a missing remote field is not silently treated as a match.
		$expect_ref = isset( $record['reference'] ) && '' !== (string) $record['reference'];
		if ( $expect_ref ) {
			$remote_ref = isset( $invoice['reference'] ) && is_string( $invoice['reference'] ) ? trim( $invoice['reference'] ) : '';
			if ( '' === $remote_ref ) {
				self::association_review( $order, 'invoice_reference_missing', __( 'The Reckon invoice is missing its reference, so the order association could not be confirmed.', 'sparxsync-accounting-integration-for-reckon-one' ) );
				return;
			}
			if ( $remote_ref !== (string) $record['reference'] ) {
				self::association_review( $order, 'invoice_reference_mismatch', __( 'The Reckon invoice has this order\'s totals but a different reference, so it is not the invoice this plugin exported. It has not been changed. Resolve the association in Reckon, then mark the review complete.', 'sparxsync-accounting-integration-for-reckon-one' ) );
				return;
			}
		}
		$expect_customer = isset( $record['customer_id'] ) && '' !== (string) $record['customer_id'];
		if ( $expect_customer ) {
			$remote_customer = isset( $invoice['customer'] ) && is_string( $invoice['customer'] ) ? trim( $invoice['customer'] ) : '';
			if ( '' === $remote_customer ) {
				self::association_review( $order, 'invoice_customer_missing', __( 'The Reckon invoice is missing its customer, so the order association could not be confirmed.', 'sparxsync-accounting-integration-for-reckon-one' ) );
				return;
			}
			if ( strtolower( $remote_customer ) !== strtolower( (string) $record['customer_id'] ) ) {
				self::association_review( $order, 'invoice_customer_mismatch', __( 'The Reckon invoice has this order\'s totals but a different customer, so it is not the invoice this plugin exported. It has not been changed. Resolve the association in Reckon, then mark the review complete.', 'sparxsync-accounting-integration-for-reckon-one' ) );
				return;
			}
		}
		// Order-specific reference evidence is required for automatic verification.
		// Customer identity alone is not enough: a customer can have several invoices
		// with identical totals.
		if ( ! $expect_ref ) {
			self::association_review( $order, 'association_evidence_missing', __( 'The order has no saved invoice reference, so the association could not be confirmed automatically. Review the invoice manually, then mark the review complete.', 'sparxsync-accounting-integration-for-reckon-one' ) );
			return;
		}

		if ( $remote_gross === (int) $record['gross_c'] && $remote_tax === (int) $record['tax_c'] ) {
			$order->update_meta_data( Reckon_WC_Order_State::STATE, Reckon_WC_Order_State::SYNCED );
			$order->update_meta_data( Reckon_WC_Order_State::TOTALS_VERIFIED, 'yes' );
			$order->delete_meta_data( Reckon_WC_Order_State::VERIFY_ATTEMPTS );
			$order->delete_meta_data( Reckon_WC_Order_State::NEXT_ATTEMPT_AT );
			$order->delete_meta_data( Reckon_WC_Order_State::LAST_ERROR );
			$order->save();
			Reckon_WC_Logger::info( 'Invoice totals verified.', array( 'operation' => 'invoice_verify', 'order_id' => $order->get_id() ) );
			return;
		}

		$order->update_meta_data( Reckon_WC_Order_State::TOTALS_VERIFIED, 'mismatch' );
		self::needs_review(
			$order,
			'total_mismatch',
			sprintf(
				/* translators: 1: Reckon total, 2: Reckon tax, 3: order total, 4: order tax. */
				__( 'The Reckon invoice totals (%1$s, tax %2$s) differ from the order (%3$s, tax %4$s). The invoice was not changed; correct it in Reckon, then mark the review complete.', 'sparxsync-accounting-integration-for-reckon-one' ),
				number_format( $remote_gross / $scale, $dp, '.', '' ),
				number_format( $remote_tax / $scale, $dp, '.', '' ),
				number_format( (int) $record['gross_c'] / $scale, $dp, '.', '' ),
				number_format( (int) $record['tax_c'] / $scale, $dp, '.', '' )
			)
		);
	}

	/**
	 * Mark an association problem as unverified and stop for review.
	 *
	 * @param WC_Order $order   Order.
	 * @param string   $reason  Reason code.
	 * @param string   $message Message.
	 */
	private static function association_review( $order, $reason, $message ) {
		$order->update_meta_data( Reckon_WC_Order_State::TOTALS_VERIFIED, 'unverified' );
		self::needs_review( $order, $reason, $message );
	}

	/**
	 * Handle a failed read-back verification. Bounded retries are scheduled; the
	 * linked invoice is never changed or re-created.
	 *
	 * @param WC_Order $order Order.
	 * @param WP_Error $error Error.
	 */
	private static function verification_retry( $order, $error ) {
		// A non-retryable read-back error escalates to review immediately; it must
		// not be retried forever and must never trigger another invoice.
		if ( ! Reckon_WC_API::error_data( $error, 'retryable', true ) ) {
			self::needs_review(
				$order,
				'verification_failed',
				/* translators: %s: error message. */
				sprintf( __( 'The Reckon invoice was created and linked, but its totals could not be verified: %s It has not been changed. Check the invoice in Reckon, then mark the review complete.', 'sparxsync-accounting-integration-for-reckon-one' ), $error->get_error_message() )
			);
			return;
		}

		$attempts = (int) $order->get_meta( Reckon_WC_Order_State::VERIFY_ATTEMPTS, true ) + 1;
		$order->update_meta_data( Reckon_WC_Order_State::VERIFY_ATTEMPTS, $attempts );
		$order->update_meta_data( Reckon_WC_Order_State::TOTALS_VERIFIED, 'unverified' );

		if ( $attempts >= self::MAX_VERIFY_ATTEMPTS ) {
			$order->delete_meta_data( Reckon_WC_Order_State::VERIFY_ATTEMPTS );
			$order->save();
			self::needs_review(
				$order,
				'verification_failed',
				__( 'The Reckon invoice was created and linked, but its totals could not be verified after several attempts. It has not been changed. Check the invoice in Reckon, then mark the review complete.', 'sparxsync-accounting-integration-for-reckon-one' )
			);
			return;
		}

		$delay       = 60 * (int) pow( 2, $attempts - 1 ); // 60, 120, 240, 480 seconds.
		$retry_after = Reckon_WC_API::error_data( $error, 'retry_after', null );
		if ( is_int( $retry_after ) && $retry_after > 0 ) {
			$delay = max( $delay, min( $retry_after, self::MAX_RETRY_AFTER ) );
		}
		$next = time() + $delay;

		$order->update_meta_data( Reckon_WC_Order_State::STATE, Reckon_WC_Order_State::VERIFY_PENDING );
		$order->delete_meta_data( Reckon_WC_Order_State::REVIEW_REASON );
		$order->update_meta_data( Reckon_WC_Order_State::NEXT_ATTEMPT_AT, $next );
		Reckon_WC_Order_State::set_error( $order, $error );
		$order->save();

		if ( ! self::schedule_verification( $order, $next ) ) {
			self::needs_review(
				$order,
				'verification_schedule_failed',
				__( 'The next invoice verification attempt could not be scheduled. The invoice is linked and has not been changed. Use "Retry verification" to continue.', 'sparxsync-accounting-integration-for-reckon-one' )
			);
			return;
		}
		Reckon_WC_Logger::warning(
			'Invoice verification pending; read-only retry scheduled.',
			array(
				'operation'  => 'invoice_verify',
				'order_id'   => $order->get_id(),
				'error_code' => $error->get_error_code(),
				'retry_in'   => $delay,
			)
		);
	}

	/**
	 * Whether a future, still-pending verification action exists for an order.
	 * The currently running action must not count as "future pending".
	 *
	 * @param WC_Order $order Order.
	 * @return bool
	 */
	public static function has_future_pending_verification( $order ) {
		if ( ! function_exists( 'as_get_scheduled_actions' ) ) {
			return false;
		}
		$ids = as_get_scheduled_actions(
			array(
				'hook'   => self::VERIFY_HOOK,
				'args'   => self::job_args( $order->get_id(), (string) $order->get_meta( Reckon_WC_Order_State::BOOK_ID, true ) ),
				'group'  => self::GROUP,
				'status' => 'pending',
			),
			'ids'
		);
		return ! empty( $ids );
	}

	/**
	 * Schedule a read-only verification job, avoiding duplicates. The currently
	 * running action is not treated as a duplicate, so a retryable failure inside
	 * the callback still schedules exactly one future attempt.
	 *
	 * @param WC_Order $order Order.
	 * @param int      $next  Timestamp.
	 * @return bool True when a future pending action now exists.
	 */
	public static function schedule_verification( $order, $next ) {
		if ( self::has_future_pending_verification( $order ) ) {
			return true;
		}
		$action_id = as_schedule_single_action(
			$next,
			self::VERIFY_HOOK,
			self::job_args( $order->get_id(), (string) $order->get_meta( Reckon_WC_Order_State::BOOK_ID, true ) ),
			self::GROUP
		);
		if ( ! $action_id ) {
			Reckon_WC_Logger::error( 'Verification job could not be scheduled.', array( 'operation' => 'invoice_verify', 'order_id' => $order->get_id() ) );
			return false;
		}
		return true;
	}

	/**
	 * Re-schedule verification without consuming a retry attempt (used on lock
	 * contention so the only verification job is not dropped).
	 *
	 * @param WC_Order $order Order.
	 * @param int      $next  Timestamp.
	 */
	private static function reschedule_verification( $order, $next ) {
		$order->update_meta_data( Reckon_WC_Order_State::NEXT_ATTEMPT_AT, $next );
		$order->save();
		self::schedule_verification( $order, $next );
	}

	/**
	 * Action Scheduler callback for read-only invoice verification.
	 *
	 * @param int    $order_id Order ID.
	 * @param string $book_id  Book ID from the job.
	 */
	public static function run_verify_job( $order_id, $book_id = '' ) {
		$order_id = absint( $order_id );
		$lock     = Reckon_WC_Lock::acquire( 'order_' . $order_id, self::LOCK_TTL );
		if ( false === $lock ) {
			// Recover from lock contention rather than dropping the only job.
			$order = wc_get_order( $order_id );
			if ( $order && Reckon_WC_Order_State::VERIFY_PENDING === Reckon_WC_Order_State::get_state( $order ) ) {
				self::reschedule_verification( $order, time() + 60 );
			}
			return;
		}
		try {
			// Re-read the order after acquiring the lock.
			$order = wc_get_order( $order_id );
			if ( ! $order || Reckon_WC_Order_State::VERIFY_PENDING !== Reckon_WC_Order_State::get_state( $order ) ) {
				return;
			}
			$invoice_id = Reckon_WC_Order_State::get_invoice_id( $order );
			if ( '' === $invoice_id ) {
				return;
			}
			// The destination book must match the immutable export snapshot.
			$record  = $order->get_meta( Reckon_WC_Order_State::EXPORT_RECORD, true );
			$stored  = (string) $order->get_meta( Reckon_WC_Order_State::BOOK_ID, true );
			$dest    = is_array( $record ) && ! empty( $record['book_id'] ) ? (string) $record['book_id'] : ( '' !== $stored ? $stored : (string) $book_id );
			self::verify_remote_totals( $order, $dest, $invoice_id );
		} catch ( Throwable $e ) {
			Reckon_WC_Logger::error( 'Unexpected ' . get_class( $e ) . ' during verification: ' . $e->getMessage(), array( 'operation' => 'invoice_verify', 'order_id' => $order_id ) );
			$order = wc_get_order( $order_id );
			if ( $order ) {
				self::verification_retry( $order, new WP_Error( 'reckon_wc_verification_error', __( 'Invoice verification failed unexpectedly. It will be retried.', 'sparxsync-accounting-integration-for-reckon-one' ), array( 'retryable' => true ) ) );
			}
		} finally {
			Reckon_WC_Lock::release( 'order_' . $order_id, $lock );
		}
	}

	/**
	 * Schedule the recurring verification-recovery action so recovery does not rely
	 * on administrator visits.
	 */
	public static function maybe_schedule_verification_recovery() {
		if ( ! Reckon_WC_Integration::scheduler_available() || ! function_exists( 'as_schedule_recurring_action' ) ) {
			return;
		}
		if ( as_has_scheduled_action( self::RECOVER_HOOK, array(), self::GROUP ) ) {
			return;
		}
		as_schedule_recurring_action( time() + 60, 15 * MINUTE_IN_SECONDS, self::RECOVER_HOOK, array(), self::GROUP );
	}

	/**
	 * Recover verification jobs that were cancelled (for example by deactivation)
	 * but whose orders still carry a verification-pending state. Runs as a recurring
	 * action and processes oldest orders first so no order is permanently skipped.
	 */
	public static function maybe_recover_verification() {
		if ( ! Reckon_WC_Integration::scheduler_available() ) {
			return;
		}
		// Recovery progress is stored durably (no expiry), with an explicit reset
		// once a scan reaches the end, so a delayed recurring run cannot restart at
		// the first page and permanently skip later orders.
		$offset = (int) get_option( 'reckon_wc_verify_recovery_offset', 0 );
		$orders = self::query_orders(
			array(
				'type'       => 'shop_order',
				'limit'      => 100,
				'offset'     => $offset,
				'orderby'    => 'date',
				'order'      => 'ASC',
				'meta_query' => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
					array(
						'key'   => Reckon_WC_Order_State::STATE,
						'value' => Reckon_WC_Order_State::VERIFY_PENDING,
					),
				),
			)
		);

		if ( empty( $orders ) ) {
			delete_option( 'reckon_wc_verify_recovery_offset' );
			return;
		}

		foreach ( $orders as $order ) {
			if ( ! self::has_future_pending_verification( $order ) ) {
				self::schedule_verification( $order, time() + 60 );
			}
		}

		if ( count( $orders ) >= 100 ) {
			update_option( 'reckon_wc_verify_recovery_offset', $offset + 100, false );
		} else {
			delete_option( 'reckon_wc_verify_recovery_offset' );
		}
	}

	/**
	 * Retry transient errors; fail permanent ones.
	 *
	 * @param WC_Order $order Order.
	 * @param WP_Error $error Error.
	 */
	private static function handle_error( $order, $error ) {
		if ( Reckon_WC_API::error_data( $error, 'review', false ) ) {
			self::needs_review( $order, Reckon_WC_API::error_data( $error, 'review_reason', 'review_required' ), $error->get_error_message() );
		} elseif ( Reckon_WC_API::error_data( $error, 'retryable', false ) ) {
			self::schedule_retry( $order, $error );
		} else {
			self::fail_order( $order, $error );
		}
	}

	/**
	 * Schedule the next attempt with backoff, bounded by MAX_ATTEMPTS.
	 *
	 * @param WC_Order $order     Order.
	 * @param WP_Error $error     Error.
	 * @param int      $min_delay Minimum delay.
	 */
	private static function schedule_retry( $order, $error, $min_delay = 0 ) {
		$attempts = (int) $order->get_meta( Reckon_WC_Order_State::ATTEMPTS, true );
		$marker   = $order->get_meta( Reckon_WC_Order_State::CREATE_ATTEMPT, true );
		if ( $attempts >= self::MAX_ATTEMPTS ) {
			if ( is_array( $marker ) ) {
				/* translators: %s: error message. */
				self::needs_review( $order, 'retries_exhausted_unknown_outcome', sprintf( __( 'Retries are exhausted and the outcome of an earlier invoice request is unknown. Check Reckon for this order\'s reference. Last error: %s', 'sparxsync-accounting-integration-for-reckon-one' ), $error->get_error_message() ) );
			} else {
				/* translators: %s: error message. */
				self::fail_order( $order, new WP_Error( $error->get_error_code(), sprintf( __( 'Retries exhausted. Last error: %s', 'sparxsync-accounting-integration-for-reckon-one' ), $error->get_error_message() ), $error->get_error_data() ) );
			}
			return;
		}

		$delay       = self::BACKOFF[ min( max( 0, $attempts - 1 ), count( self::BACKOFF ) - 1 ) ];
		$retry_after = Reckon_WC_API::error_data( $error, 'retry_after', null );
		if ( is_int( $retry_after ) && $retry_after > 0 ) {
			$delay = max( $delay, min( $retry_after, self::MAX_RETRY_AFTER ) );
		}
		$delay = max( $delay, (int) $min_delay );
		$next  = time() + $delay;

		$book_id = (string) $order->get_meta( Reckon_WC_Order_State::BOOK_ID, true );
		$order->update_meta_data( Reckon_WC_Order_State::STATE, Reckon_WC_Order_State::QUEUED );
		$order->update_meta_data( Reckon_WC_Order_State::NEXT_ATTEMPT_AT, $next );
		Reckon_WC_Order_State::set_error( $order, $error );
		$order->save();

		$args      = self::job_args( $order->get_id(), $book_id );
		$action_id = as_schedule_single_action( $next, self::HOOK, $args, self::GROUP );
		if ( ! $action_id ) {
			// The retry could not be scheduled. Preserve the accounting-safety state
			// and record a recoverable failure rather than pretending it will run.
			Reckon_WC_Logger::error( 'Retry job could not be scheduled.', array( 'operation' => 'sync', 'order_id' => $order->get_id(), 'error_code' => $error->get_error_code() ) );
			self::fail_order( $order, new WP_Error( 'reckon_wc_retry_schedule_failed', __( 'The next retry could not be scheduled. The order has been marked failed; retry it manually.', 'sparxsync-accounting-integration-for-reckon-one' ), array( 'retryable' => true ) ) );
			return;
		}
		Reckon_WC_Logger::warning(
			'Temporary failure; retry scheduled.',
			array(
				'operation'   => 'sync',
				'order_id'    => $order->get_id(),
				'attempt'     => $attempts,
				'http_status' => Reckon_WC_API::error_data( $error, 'status', 0 ),
				'error_code'  => $error->get_error_code(),
				'retry_in'    => $delay,
			)
		);
	}

	/**
	 * Mark an order failed. It is retried only by an administrator.
	 *
	 * @param WC_Order $order Order.
	 * @param WP_Error $error Error.
	 */
	private static function fail_order( $order, $error ) {
		$order->update_meta_data( Reckon_WC_Order_State::STATE, Reckon_WC_Order_State::FAILED );
		$order->delete_meta_data( Reckon_WC_Order_State::NEXT_ATTEMPT_AT );
		Reckon_WC_Order_State::set_error( $order, $error );
		$order->save();
		/* translators: %s: error message. */
		$order->add_order_note( sprintf( __( 'Reckon One: synchronization failed. %s', 'sparxsync-accounting-integration-for-reckon-one' ), Reckon_WC_Logger::redact( $error->get_error_message() ) ) );
		Reckon_WC_Logger::error(
			'Synchronization failed.',
			array(
				'operation'   => 'sync',
				'order_id'    => $order->get_id(),
				'attempt'     => (int) $order->get_meta( Reckon_WC_Order_State::ATTEMPTS, true ),
				'http_status' => Reckon_WC_API::error_data( $error, 'status', 0 ),
				'error_code'  => $error->get_error_code(),
			)
		);
	}

	/**
	 * Mark an order as needing administrator review. Automatic creation stops.
	 *
	 * @param WC_Order $order   Order.
	 * @param string   $reason  Reason code.
	 * @param string   $message Message.
	 */
	private static function needs_review( $order, $reason, $message ) {
		$order->update_meta_data( Reckon_WC_Order_State::STATE, Reckon_WC_Order_State::NEEDS_REVIEW );
		$order->update_meta_data( Reckon_WC_Order_State::REVIEW_REASON, $reason );
		$order->delete_meta_data( Reckon_WC_Order_State::NEXT_ATTEMPT_AT );
		Reckon_WC_Order_State::set_error( $order, new WP_Error( 'reckon_wc_' . $reason, $message ) );
		$order->save();
		/* translators: %s: explanation. */
		$order->add_order_note( sprintf( __( 'Reckon One: needs review. %s', 'sparxsync-accounting-integration-for-reckon-one' ), $message ) );
		Reckon_WC_Logger::warning( 'Order needs review.', array( 'operation' => 'sync', 'order_id' => $order->get_id(), 'error_code' => $reason ) );
	}

	/**
	 * Administrator confirmed no Reckon invoice exists for an order needing review; queue it again.
	 * The worker still checks for an invoice with the order's reference before creating one.
	 *
	 * @param WC_Order $order Order.
	 * @return string|WP_Error
	 */
	public static function confirm_no_invoice_and_retry( $order ) {
		if ( Reckon_WC_Order_State::NEEDS_REVIEW !== Reckon_WC_Order_State::get_state( $order ) || '' !== Reckon_WC_Order_State::get_invoice_id( $order ) ) {
			return new WP_Error( 'reckon_wc_not_applicable', __( 'This action applies only to orders that need review and have no linked invoice.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}
		$order->delete_meta_data( Reckon_WC_Order_State::CREATE_ATTEMPT );
		$order->delete_meta_data( Reckon_WC_Order_State::REVIEW_REASON );
		$order->update_meta_data( Reckon_WC_Order_State::STATE, Reckon_WC_Order_State::NOT_QUEUED );
		$order->save();
		/* translators: %s: user display name. */
		$order->add_order_note( sprintf( __( 'Reckon One: %s confirmed that no Reckon invoice exists for this order and queued it again.', 'sparxsync-accounting-integration-for-reckon-one' ), wp_get_current_user()->display_name ) );
		return self::queue_order( $order, 'manual' );
	}

	/**
	 * Administrator confirmed no Reckon customer was created for an order whose
	 * customer-create outcome was unknown. The worker still re-searches before creating.
	 *
	 * @param WC_Order $order Order.
	 * @return string|WP_Error
	 */
	public static function confirm_no_customer_and_retry( $order ) {
		if ( Reckon_WC_Order_State::NEEDS_REVIEW !== Reckon_WC_Order_State::get_state( $order ) || '' !== Reckon_WC_Order_State::get_invoice_id( $order ) ) {
			return new WP_Error( 'reckon_wc_not_applicable', __( 'This action applies only to orders that need review and have no linked invoice.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}
		if ( 'customer_create_unknown' !== (string) $order->get_meta( Reckon_WC_Order_State::REVIEW_REASON, true ) ) {
			return new WP_Error( 'reckon_wc_not_applicable', __( 'This action applies only to orders that need review because a customer-create outcome was unknown.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}

		$marker  = $order->get_meta( Reckon_WC_Order_State::CUSTOMER_ATTEMPT, true );
		$book_id = is_array( $marker ) && ! empty( $marker['book_id'] ) ? (string) $marker['book_id'] : (string) $order->get_meta( Reckon_WC_Order_State::BOOK_ID, true );
		if ( '' === $book_id ) {
			$book_id = Reckon_WC_Settings::get( Reckon_WC_Settings::OPTION_BOOK )['book_id'];
		}
		$email = is_array( $marker ) && ! empty( $marker['email'] ) ? (string) $marker['email'] : strtolower( trim( (string) $order->get_billing_email() ) );
		if ( '' === $book_id || '' === $email ) {
			return new WP_Error( 'reckon_wc_not_applicable', __( 'The customer attempt could not be identified.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}

		// Resolve the shared attempt under the customer lock using only the saved
		// attempt reference. Never substitute the current shared ID: that would let a
		// historical review clear a newer attempt.
		$attempt_id = is_array( $marker ) && ! empty( $marker['attempt_id'] ) ? (string) $marker['attempt_id'] : '';
		if ( '' === $attempt_id ) {
			return new WP_Error( 'reckon_wc_customer_attempt_missing', __( 'This order has no saved customer-attempt reference, so a newer attempt could not be distinguished. The shared attempt was preserved. Reconcile the customer in Reckon, then link it.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}
		$cleared = Reckon_WC_Customer_Resolver::clear_shared_attempt_if_owned( $book_id, $email, $attempt_id );
		if ( is_wp_error( $cleared ) ) {
			return $cleared;
		}

		$order->delete_meta_data( Reckon_WC_Order_State::CUSTOMER_ATTEMPT );
		$order->delete_meta_data( Reckon_WC_Order_State::REVIEW_REASON );
		$order->update_meta_data( Reckon_WC_Order_State::STATE, Reckon_WC_Order_State::NOT_QUEUED );
		$order->save();
		/* translators: %s: user display name. */
		$order->add_order_note( sprintf( __( 'Reckon One: %s confirmed that no Reckon customer was created and queued the order again.', 'sparxsync-accounting-integration-for-reckon-one' ), wp_get_current_user()->display_name ) );
		return self::queue_order( $order, 'manual' );
	}

	/**
	 * Clear a "needs review" state for a linked invoice, or an accounting-review flag.
	 *
	 * @param WC_Order $order Order.
	 * @return true|WP_Error
	 */
	public static function mark_reviewed( $order ) {
		$changed = false;
		if ( Reckon_WC_Order_State::NEEDS_REVIEW === Reckon_WC_Order_State::get_state( $order ) && '' !== Reckon_WC_Order_State::get_invoice_id( $order ) ) {
			// Marking a review complete is a manual decision; it must not fabricate
			// automated verification.
			$order->update_meta_data( Reckon_WC_Order_State::STATE, Reckon_WC_Order_State::MANUAL_REVIEWED );
			$order->delete_meta_data( Reckon_WC_Order_State::REVIEW_REASON );
			$changed = true;
		}
		if ( $order->get_meta( Reckon_WC_Order_State::ACCOUNTING_REVIEW, true ) ) {
			$order->delete_meta_data( Reckon_WC_Order_State::ACCOUNTING_REVIEW );
			$changed = true;
		}
		if ( ! $changed ) {
			return new WP_Error( 'reckon_wc_not_applicable', __( 'There is nothing to mark as reviewed on this order.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}
		$order->save();
		/* translators: %s: user display name. */
		$order->add_order_note( sprintf( __( 'Reckon One: review marked complete by %s.', 'sparxsync-accounting-integration-for-reckon-one' ), wp_get_current_user()->display_name ) );
		return true;
	}

	/**
	 * Administrator-triggered read-only verification retry. Does not create an invoice.
	 *
	 * @param WC_Order $order Order.
	 * @return true|WP_Error
	 */
	public static function retry_verification( $order ) {
		$state      = Reckon_WC_Order_State::get_state( $order );
		$invoice_id = Reckon_WC_Order_State::get_invoice_id( $order );
		$record     = $order->get_meta( Reckon_WC_Order_State::EXPORT_RECORD, true );
		$applicable = '' !== $invoice_id
			&& is_array( $record )
			&& in_array( $state, array( Reckon_WC_Order_State::VERIFY_PENDING, Reckon_WC_Order_State::NEEDS_REVIEW, Reckon_WC_Order_State::LINKED_UNVERIFIED ), true );
		if ( ! $applicable ) {
			return new WP_Error( 'reckon_wc_not_applicable', __( 'Verification can only be retried for a linked invoice that has an original export record.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}
		$lock = Reckon_WC_Lock::acquire( 'order_' . $order->get_id(), self::LOCK_TTL );
		if ( false === $lock ) {
			return new WP_Error( 'reckon_wc_locked', __( 'The order is being processed. Try again in a few minutes.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}
		try {
			// Re-read the order after acquiring the lock.
			$order = wc_get_order( $order->get_id() );
			if ( ! $order ) {
				return new WP_Error( 'reckon_wc_order_not_found', __( 'Order not found.', 'sparxsync-accounting-integration-for-reckon-one' ) );
			}
			self::verify_remote_totals( $order, (string) $order->get_meta( Reckon_WC_Order_State::BOOK_ID, true ), Reckon_WC_Order_State::get_invoice_id( $order ) );
			return true;
		} finally {
			Reckon_WC_Lock::release( 'order_' . $order->get_id(), $lock );
		}
	}

	/**
	 * Link an existing Reckon invoice to an order that is not synced.
	 *
	 * @param WC_Order $order      Order.
	 * @param string   $invoice_id Invoice ID.
	 * @return true|WP_Error
	 */
	public static function link_existing_invoice( $order, $invoice_id ) {
		$invoice_id = strtolower( trim( (string) $invoice_id ) );
		if ( ! Reckon_WC_API::is_guid( $invoice_id ) ) {
			return new WP_Error( 'reckon_wc_invalid_invoice_id', __( 'Enter a Reckon invoice ID in GUID format.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}
		if ( '' !== Reckon_WC_Order_State::get_invoice_id( $order ) ) {
			return new WP_Error( 'reckon_wc_already_linked', __( 'This order is already linked to a Reckon invoice.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}
		$lock = Reckon_WC_Lock::acquire( 'order_' . $order->get_id(), self::LOCK_TTL );
		if ( false === $lock ) {
			return new WP_Error( 'reckon_wc_locked', __( 'The order is being processed. Try again in a few minutes.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}
		// Also reserve the remote invoice so two orders cannot link it concurrently.
		$invoice_lock = Reckon_WC_Lock::acquire( 'invoice_' . $invoice_id, self::LOCK_TTL );
		if ( false === $invoice_lock ) {
			Reckon_WC_Lock::release( 'order_' . $order->get_id(), $lock );
			return new WP_Error( 'reckon_wc_invoice_locked', __( 'This Reckon invoice is being linked by another request. Try again in a few minutes.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}
		try {
			// Re-read the order after acquiring the locks.
			$order = wc_get_order( $order->get_id() );
			if ( ! $order ) {
				return new WP_Error( 'reckon_wc_order_not_found', __( 'Order not found.', 'sparxsync-accounting-integration-for-reckon-one' ) );
			}
			if ( '' !== Reckon_WC_Order_State::get_invoice_id( $order ) ) {
				return new WP_Error( 'reckon_wc_already_linked', __( 'This order is already linked to a Reckon invoice.', 'sparxsync-accounting-integration-for-reckon-one' ) );
			}
			$marker  = $order->get_meta( Reckon_WC_Order_State::CREATE_ATTEMPT, true );
			$book_id = is_array( $marker ) && ! empty( $marker['book_id'] ) ? (string) $marker['book_id'] : (string) $order->get_meta( Reckon_WC_Order_State::BOOK_ID, true );
			if ( '' === $book_id ) {
				$book_id = Reckon_WC_Settings::get( Reckon_WC_Settings::OPTION_BOOK )['book_id'];
			}
			$invoice = Reckon_WC_API::get_invoice( $book_id, $invoice_id );
			if ( is_wp_error( $invoice ) ) {
				return $invoice;
			}
			$already = self::order_with_invoice_id( $invoice_id, $order->get_id() );
			if ( $already ) {
				/* translators: %s: order number. */
				return new WP_Error( 'reckon_wc_invoice_already_linked', sprintf( __( 'This Reckon invoice is already linked to order #%s.', 'sparxsync-accounting-integration-for-reckon-one' ), $already->get_order_number() ) );
			}
			self::link_invoice( $order, $book_id, $invoice_id, 'linked', null );
			return true;
		} finally {
			Reckon_WC_Lock::release( 'invoice_' . $invoice_id, $invoice_lock );
			Reckon_WC_Lock::release( 'order_' . $order->get_id(), $lock );
		}
	}

	/**
	 * Link an existing Reckon customer to an order whose customer-create outcome was
	 * unknown. Validates that the customer exists in the destination book.
	 *
	 * @param WC_Order $order       Order.
	 * @param string   $customer_id Customer ID.
	 * @return true|WP_Error
	 */
	public static function link_existing_customer( $order, $customer_id ) {
		$customer_id = strtolower( trim( (string) $customer_id ) );
		if ( ! Reckon_WC_API::is_guid( $customer_id ) ) {
			return new WP_Error( 'reckon_wc_invalid_customer_id', __( 'Enter a Reckon customer ID in GUID format.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}
		$marker  = $order->get_meta( Reckon_WC_Order_State::CUSTOMER_ATTEMPT, true );
		$book_id = is_array( $marker ) && ! empty( $marker['book_id'] ) ? (string) $marker['book_id'] : (string) $order->get_meta( Reckon_WC_Order_State::BOOK_ID, true );
		if ( '' === $book_id ) {
			$book_id = Reckon_WC_Settings::get( Reckon_WC_Settings::OPTION_BOOK )['book_id'];
		}
		if ( '' === $book_id ) {
			return new WP_Error( 'reckon_wc_book_missing', __( 'No Reckon book is selected.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}
		$lock = Reckon_WC_Lock::acquire( 'order_' . $order->get_id(), self::LOCK_TTL );
		if ( false === $lock ) {
			return new WP_Error( 'reckon_wc_locked', __( 'The order is being processed. Try again in a few minutes.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}
		try {
			$customer = Reckon_WC_API::get_customer( $book_id, $customer_id );
			if ( is_wp_error( $customer ) ) {
				return $customer;
			}
			if ( isset( $customer['status'] ) && 'inactive' === strtolower( (string) $customer['status'] ) ) {
				return new WP_Error( 'reckon_wc_customer_inactive', __( 'The selected Reckon customer is inactive. Reactivate it in Reckon, then link it again.', 'sparxsync-accounting-integration-for-reckon-one' ) );
			}

			// Record a deliberate, validated mapping that the resolver honours.
			$order->update_meta_data(
				Reckon_WC_Order_State::CUSTOMER_MAPPING,
				array(
					'customer_id' => $customer_id,
					'book_id'     => $book_id,
					'email'       => strtolower( trim( (string) $order->get_billing_email() ) ),
					'name'        => Reckon_WC_Customer_Resolver::display_name( $order ),
					'at'          => time(),
					'by'          => get_current_user_id(),
				)
			);
			$order->update_meta_data( Reckon_WC_Order_State::CUSTOMER_ID, $customer_id );
			$order->delete_meta_data( Reckon_WC_Order_State::CUSTOMER_ATTEMPT );
			$order->delete_meta_data( Reckon_WC_Order_State::REVIEW_REASON );
			$order->update_meta_data( Reckon_WC_Order_State::STATE, Reckon_WC_Order_State::NOT_QUEUED );
			$order->save();

			$email      = is_array( $marker ) && ! empty( $marker['email'] ) ? (string) $marker['email'] : strtolower( trim( (string) $order->get_billing_email() ) );
			$attempt_id = is_array( $marker ) && ! empty( $marker['attempt_id'] ) ? (string) $marker['attempt_id'] : '';

			/* translators: 1: customer ID, 2: user display name. */
			$note = sprintf( __( 'Reckon One: customer %1$s linked by %2$s.', 'sparxsync-accounting-integration-for-reckon-one' ), $customer_id, wp_get_current_user()->display_name );
			if ( '' === $attempt_id ) {
				// No saved attempt reference: preserve the shared record; the manual
				// mapping still recovers this order without clearing another attempt.
				$note .= ' ' . __( 'A shared customer attempt was preserved because this order had no saved attempt reference.', 'sparxsync-accounting-integration-for-reckon-one' );
			} else {
				$cleared = Reckon_WC_Customer_Resolver::clear_shared_attempt_if_owned( $book_id, $email, $attempt_id );
				if ( is_wp_error( $cleared ) ) {
					Reckon_WC_Logger::warning( 'Shared customer attempt not cleared after manual link: ' . $cleared->get_error_code(), array( 'operation' => 'customer_link', 'order_id' => $order->get_id() ) );
					$note .= ' ' . sprintf(
						/* translators: %s: reason. */
						__( 'A shared customer attempt was not cleared automatically: %s.', 'sparxsync-accounting-integration-for-reckon-one' ),
						$cleared->get_error_message()
					);
				}
			}
			$order->add_order_note( $note );
			return true;
		} finally {
			Reckon_WC_Lock::release( 'order_' . $order->get_id(), $lock );
		}
	}

	/**
	 * On deactivation: mark orders whose jobs were cancelled so they appear as failed.
	 * Any create-attempt marker is kept so a later retry reconciles first.
	 */
	public static function mark_cancelled_jobs() {
		$orders = self::find_orders( array( Reckon_WC_Order_State::QUEUED, Reckon_WC_Order_State::IN_PROGRESS ), 200 );
		foreach ( $orders as $order ) {
			$order->update_meta_data( Reckon_WC_Order_State::STATE, Reckon_WC_Order_State::FAILED );
			$order->delete_meta_data( Reckon_WC_Order_State::NEXT_ATTEMPT_AT );
			Reckon_WC_Order_State::set_error( $order, new WP_Error( 'reckon_wc_jobs_cancelled', __( 'The queued job was cancelled because the plugin was deactivated. Retry after reactivating.', 'sparxsync-accounting-integration-for-reckon-one' ) ) );
			$order->save();
		}
	}

	/**
	 * Whether WooCommerce High-Performance Order Storage is the active order data
	 * store. `meta_query` is only supported by `wc_get_orders()` in this mode.
	 *
	 * @return bool
	 */
	private static function hpos_enabled() {
		return class_exists( '\Automattic\WooCommerce\Utilities\OrderUtil' )
			&& \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled();
	}

	/**
	 * Translate our `meta_query` argument for legacy (CPT) order storage.
	 *
	 * This filter is only registered while a query is running, so it never affects
	 * unrelated WooCommerce queries.
	 *
	 * @param array $query      WP_Query arguments.
	 * @param array $query_vars Original wc_get_orders() arguments.
	 * @return array
	 */
	public static function legacy_meta_query( $query, $query_vars ) {
		if ( ! empty( $query_vars['meta_query'] ) && is_array( $query_vars['meta_query'] ) ) {
			$query['meta_query'] = isset( $query['meta_query'] ) && is_array( $query['meta_query'] )
				? array_merge( $query['meta_query'], $query_vars['meta_query'] )
				: $query_vars['meta_query'];
		}
		return $query;
	}

	/**
	 * Run a wc_get_orders() query that works in both HPOS and legacy storage.
	 *
	 * HPOS supports `meta_query` directly. Legacy storage does not, so the
	 * documented `woocommerce_order_data_store_cpt_get_orders_query` filter is
	 * registered only for the duration of this query.
	 *
	 * @param array $args wc_get_orders() arguments.
	 * @return mixed
	 */
	public static function query_orders( $args ) {
		if ( self::hpos_enabled() ) {
			return wc_get_orders( $args );
		}
		add_filter( 'woocommerce_order_data_store_cpt_get_orders_query', array( __CLASS__, 'legacy_meta_query' ), 10, 2 );
		try {
			return wc_get_orders( $args );
		} finally {
			remove_filter( 'woocommerce_order_data_store_cpt_get_orders_query', array( __CLASS__, 'legacy_meta_query' ), 10 );
		}
	}

	/**
	 * Find another order already linked to a given Reckon invoice ID.
	 *
	 * @param string $invoice_id Invoice ID.
	 * @param int    $exclude_id Order ID to exclude.
	 * @return WC_Order|null
	 */
	private static function order_with_invoice_id( $invoice_id, $exclude_id ) {
		$orders = self::query_orders(
			array(
				'type'       => 'shop_order',
				'limit'      => 5,
				'exclude'    => array( (int) $exclude_id ),
				'meta_query' => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
					array(
						'key'   => Reckon_WC_Order_State::INVOICE_ID,
						'value' => (string) $invoice_id,
					),
				),
			)
		);
		return ! empty( $orders ) ? $orders[0] : null;
	}

	/**
	 * Orders in the given states.
	 *
	 * @param string[] $states States.
	 * @param int      $limit  Limit.
	 * @return WC_Order[]
	 */
	public static function find_orders( $states, $limit = 50 ) {
		return self::query_orders(
			array(
				'type'       => 'shop_order',
				'limit'      => $limit,
				'orderby'    => 'date',
				'order'      => 'DESC',
				'meta_query' => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
					array(
						'key'     => Reckon_WC_Order_State::STATE,
						'value'   => (array) $states,
						'compare' => 'IN',
					),
				),
			)
		);
	}

	/**
	 * Orders flagged for accounting review.
	 *
	 * @param int $limit Limit.
	 * @return WC_Order[]
	 */
	public static function find_accounting_review_orders( $limit = 50 ) {
		return self::query_orders(
			array(
				'type'       => 'shop_order',
				'limit'      => $limit,
				'orderby'    => 'date',
				'order'      => 'DESC',
				'meta_query' => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
					array(
						'key'     => Reckon_WC_Order_State::ACCOUNTING_REVIEW,
						'compare' => 'EXISTS',
					),
				),
			)
		);
	}

	/**
	 * Number of orders in a state.
	 *
	 * @param string $state State.
	 * @return int
	 */
	public static function count_state( $state ) {
		$result = self::query_orders(
			array(
				'type'       => 'shop_order',
				'limit'      => 1,
				'paginate'   => true,
				'return'     => 'ids',
				'meta_query' => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
					array(
						'key'   => Reckon_WC_Order_State::STATE,
						'value' => $state,
					),
				),
			)
		);
		return is_object( $result ) && isset( $result->total ) ? (int) $result->total : 0;
	}

	/**
	 * Orders whose Reckon invoice was linked at or after a time (newest orders first).
	 *
	 * @param int $since Unix timestamp.
	 * @param int $limit Maximum number of orders.
	 * @return WC_Order[]
	 */
	public static function find_invoiced_since( $since, $limit ) {
		return self::query_orders(
			array(
				'type'       => 'shop_order',
				'limit'      => $limit,
				'orderby'    => 'date',
				'order'      => 'DESC',
				'meta_query' => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
					array(
						'key'     => Reckon_WC_Order_State::SYNCED_AT,
						'value'   => (int) $since,
						'compare' => '>=',
						'type'    => 'NUMERIC',
					),
				),
			)
		);
	}

	/**
	 * Number of orders that have a Reckon invoice ID.
	 *
	 * @return int
	 */
	public static function count_invoiced() {
		$result = self::query_orders(
			array(
				'type'       => 'shop_order',
				'limit'      => 1,
				'paginate'   => true,
				'return'     => 'ids',
				'meta_query' => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
					array(
						'key'     => Reckon_WC_Order_State::INVOICE_ID,
						'compare' => 'EXISTS',
					),
				),
			)
		);
		return is_object( $result ) && isset( $result->total ) ? (int) $result->total : 0;
	}
}
