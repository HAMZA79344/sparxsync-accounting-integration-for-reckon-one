<?php
/**
 * Per-order synchronization metadata, read and written only through WooCommerce
 * CRUD methods so it works with both HPOS and legacy post storage.
 *
 * @package Reckon_WC
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Reckon_WC_Order_State {

	// Invoice ID key kept from 1.x so previously synced orders are recognised.
	const INVOICE_ID        = '_reckon_invoice_id';
	const STATE             = '_reckon_wc_sync_state';
	const BOOK_ID           = '_reckon_wc_book_id';
	const CUSTOMER_ID       = '_reckon_wc_customer_id';
	const REFERENCE         = '_reckon_wc_reference';
	const ATTEMPTS          = '_reckon_wc_attempts';
	const LAST_ATTEMPT_AT   = '_reckon_wc_last_attempt_at';
	const NEXT_ATTEMPT_AT   = '_reckon_wc_next_attempt_at';
	const QUEUED_AT         = '_reckon_wc_queued_at';
	const SYNCED_AT         = '_reckon_wc_synced_at';
	const LAST_ERROR        = '_reckon_wc_last_error';
	const CREATE_ATTEMPT    = '_reckon_wc_create_attempt';
	const REVIEW_REASON     = '_reckon_wc_review_reason';
	const ACCOUNTING_REVIEW = '_reckon_wc_accounting_review';
	const TOTALS_VERIFIED   = '_reckon_wc_totals_verified';
	const VERIFY_ATTEMPTS   = '_reckon_wc_verify_attempts';
	const EXPORT_RECORD     = '_reckon_wc_export_record';
	const CUSTOMER_ATTEMPT  = '_reckon_wc_customer_attempt';
	const CUSTOMER_MAPPING  = '_reckon_wc_customer_mapping';
	// Read-only payment status copied from the Reckon invoice (Draft, Approved, Paid or NotFound).
	const REMOTE_STATUS     = '_reckon_wc_remote_status';
	const REMOTE_CHECKED_AT = '_reckon_wc_remote_checked_at';
	const PAID_AT           = '_reckon_wc_paid_at';

	const NOT_QUEUED      = 'not_queued';
	const QUEUED          = 'queued';
	const IN_PROGRESS     = 'in_progress';
	const VERIFY_PENDING  = 'verify_pending';
	const SYNCED          = 'synced';
	const LINKED_UNVERIFIED = 'linked_unverified';
	const MANUAL_REVIEWED = 'manual_reviewed';
	const FAILED          = 'failed';
	const NEEDS_REVIEW    = 'needs_review';

	/**
	 * Human-readable state labels.
	 *
	 * @return array
	 */
	public static function labels() {
		return array(
			self::NOT_QUEUED        => __( 'Not queued', 'sparxsync-accounting-integration-for-reckon-one' ),
			self::QUEUED            => __( 'Queued', 'sparxsync-accounting-integration-for-reckon-one' ),
			self::IN_PROGRESS       => __( 'In progress', 'sparxsync-accounting-integration-for-reckon-one' ),
			self::VERIFY_PENDING    => __( 'Invoice created — verification pending', 'sparxsync-accounting-integration-for-reckon-one' ),
			self::SYNCED            => __( 'Synced (verified)', 'sparxsync-accounting-integration-for-reckon-one' ),
			self::LINKED_UNVERIFIED => __( 'Linked (not verified)', 'sparxsync-accounting-integration-for-reckon-one' ),
			self::MANUAL_REVIEWED   => __( 'Manually reviewed (not auto-verified)', 'sparxsync-accounting-integration-for-reckon-one' ),
			self::FAILED            => __( 'Failed', 'sparxsync-accounting-integration-for-reckon-one' ),
			self::NEEDS_REVIEW      => __( 'Needs review', 'sparxsync-accounting-integration-for-reckon-one' ),
		);
	}

	/**
	 * Remote invoice ID, including IDs stored by 1.x.
	 *
	 * @param WC_Order $order Order.
	 * @return string
	 */
	public static function get_invoice_id( $order ) {
		$id = $order->get_meta( self::INVOICE_ID, true );
		return is_scalar( $id ) ? trim( (string) $id ) : '';
	}

	/**
	 * Current state. Orders synced by 1.x (invoice ID but no state) report "synced".
	 *
	 * @param WC_Order $order Order.
	 * @return string
	 */
	public static function get_state( $order ) {
		$state = (string) $order->get_meta( self::STATE, true );
		if ( '' !== self::get_invoice_id( $order ) ) {
			// A linked invoice is verified only when there is verification evidence.
			// Legacy 1.x links (invoice ID but no state or verification) are not
			// labelled as verified.
			if ( self::NEEDS_REVIEW === $state ) {
				return self::NEEDS_REVIEW;
			}
			if ( self::VERIFY_PENDING === $state ) {
				return self::VERIFY_PENDING;
			}
			if ( self::MANUAL_REVIEWED === $state ) {
				return self::MANUAL_REVIEWED;
			}
			if ( 'yes' === (string) $order->get_meta( self::TOTALS_VERIFIED, true ) ) {
				return self::SYNCED;
			}
			return self::LINKED_UNVERIFIED;
		}
		return array_key_exists( $state, self::labels() ) ? $state : self::NOT_QUEUED;
	}

	/**
	 * Stable external reference sent to Reckon as the invoice reference.
	 * Created once and never changed. The caller saves the order.
	 *
	 * @param WC_Order $order Order.
	 * @return string
	 */
	public static function get_reference( $order ) {
		$reference = (string) $order->get_meta( self::REFERENCE, true );
		if ( '' === $reference ) {
			$reference = 'WC-' . $order->get_id() . '-' . Reckon_WC_Settings::get_site_token();
			$order->update_meta_data( self::REFERENCE, $reference );
		}
		return $reference;
	}

	/**
	 * Record an error summary. Messages are redacted and shortened.
	 *
	 * @param WC_Order $order Order.
	 * @param WP_Error $error Error.
	 */
	public static function set_error( $order, $error ) {
		$message = Reckon_WC_Logger::redact( $error->get_error_message() );
		if ( strlen( $message ) > 500 ) {
			$message = substr( $message, 0, 497 ) . '...';
		}
		$order->update_meta_data(
			self::LAST_ERROR,
			array(
				'code'        => sanitize_key( $error->get_error_code() ),
				'message'     => $message,
				'http_status' => (int) Reckon_WC_API::error_data( $error, 'status', 0 ),
				'at'          => time(),
			)
		);
	}

	/**
	 * All synchronization details for display.
	 *
	 * @param WC_Order $order Order.
	 * @return array
	 */
	public static function summary( $order ) {
		$error  = $order->get_meta( self::LAST_ERROR, true );
		$review = $order->get_meta( self::ACCOUNTING_REVIEW, true );
		return array(
			'state'             => self::get_state( $order ),
			'invoice_id'        => self::get_invoice_id( $order ),
			'book_id'           => (string) $order->get_meta( self::BOOK_ID, true ),
			'customer_id'       => (string) $order->get_meta( self::CUSTOMER_ID, true ),
			'reference'         => (string) $order->get_meta( self::REFERENCE, true ),
			'attempts'          => (int) $order->get_meta( self::ATTEMPTS, true ),
			'last_attempt_at'   => (int) $order->get_meta( self::LAST_ATTEMPT_AT, true ),
			'next_attempt_at'   => (int) $order->get_meta( self::NEXT_ATTEMPT_AT, true ),
			'queued_at'         => (int) $order->get_meta( self::QUEUED_AT, true ),
			'synced_at'         => (int) $order->get_meta( self::SYNCED_AT, true ),
			'last_error'        => is_array( $error ) ? $error : array(),
			'review_reason'     => (string) $order->get_meta( self::REVIEW_REASON, true ),
			'accounting_review' => is_array( $review ) ? $review : array(),
			'totals_verified'   => (string) $order->get_meta( self::TOTALS_VERIFIED, true ),
			'verify_attempts'   => (int) $order->get_meta( self::VERIFY_ATTEMPTS, true ),
			'export_record'     => is_array( $order->get_meta( self::EXPORT_RECORD, true ) ) ? $order->get_meta( self::EXPORT_RECORD, true ) : array(),
			'create_pending'    => is_array( $order->get_meta( self::CREATE_ATTEMPT, true ) ),
			'remote_status'     => (string) $order->get_meta( self::REMOTE_STATUS, true ),
			'remote_checked_at' => (int) $order->get_meta( self::REMOTE_CHECKED_AT, true ),
			'paid_at'           => (int) $order->get_meta( self::PAID_AT, true ),
		);
	}
}
