<?php
/**
 * Reckon Settings Handler Class
 *
 * Settings are stored in separate array options, one per form, each registered
 * in its own settings group. options.php only writes the options registered in
 * the submitted group, so saving one form can never clear another form's values.
 * Every sanitize callback starts from the saved value and only overlays fields
 * that were submitted and valid.
 *
 * @package Reckon_WC
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Reckon_WC_Settings {

	const SCHEMA_VERSION = 2;

	const OPTION_CREDENTIALS = 'reckon_wc_credentials';
	const OPTION_BOOK        = 'reckon_wc_book';
	const OPTION_MAPPINGS    = 'reckon_wc_mappings';
	const OPTION_SYNC        = 'reckon_wc_sync_settings';
	const OPTION_VERSION     = 'reckon_wc_settings_version';
	const OPTION_SITE_TOKEN  = 'reckon_wc_site_token';
	const OPTION_UPGRADED    = 'reckon_wc_upgrade_notice';

	const GROUP_CREDENTIALS = 'reckon_wc_credentials_group';
	const GROUP_BOOK        = 'reckon_wc_book_group';
	const GROUP_MAPPINGS    = 'reckon_wc_mappings_group';
	const GROUP_SYNC        = 'reckon_wc_sync_group';

	const PAGE_SLUG    = 'reckon-wc-settings';
	const ERROR_SLUG   = 'reckon_wc_settings';
	const GUID_PATTERN = '/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i';

	/**
	 * Legacy (1.x) option names.
	 *
	 * @var string[]
	 */
	const LEGACY_OPTIONS = array(
		'reckon_wc_client_id',
		'reckon_wc_client_secret',
		'reckon_wc_subscription_key',
		'reckon_wc_book_id',
		'reckon_wc_access_token',
		'reckon_wc_refresh_token',
		'reckon_wc_token_expiry',
		'reckon_wc_sales_account',
		'reckon_wc_shipping_account',
		'reckon_wc_default_tax_rate_id',
	);

	/**
	 * Order statuses that never trigger an invoice.
	 *
	 * @var string[]
	 */
	const EXCLUDED_STATUSES = array( 'pending', 'failed', 'cancelled', 'refunded', 'checkout-draft', 'trash' );

	/**
	 * True while the migration writes already-validated values.
	 *
	 * @var bool
	 */
	private static $raw_write = false;

	/**
	 * Add an option without running the form sanitize callbacks.
	 *
	 * @param string $name     Option.
	 * @param mixed  $value    Value.
	 * @param bool   $autoload Autoload.
	 */
	private static function raw_add_option( $name, $value, $autoload ) {
		self::$raw_write = true;
		try {
			add_option( $name, $value, '', $autoload );
		} finally {
			self::$raw_write = false;
		}
	}

	/**
	 * Register hooks.
	 */
	public static function init() {
		add_action( 'admin_init', array( __CLASS__, 'register' ) );
		add_action( 'update_option_' . self::OPTION_CREDENTIALS, array( __CLASS__, 'credentials_updated' ), 10, 2 );
		add_action( 'update_option_' . self::OPTION_BOOK, array( __CLASS__, 'book_updated' ), 10, 2 );
	}

	/**
	 * Capability required to manage the connection and settings.
	 *
	 * @return string
	 */
	public static function capability() {
		return (string) apply_filters( 'reckon_wc_manage_capability', 'manage_options' );
	}

	/**
	 * URL of a tab on the settings page.
	 *
	 * @param string $tab Tab key.
	 * @return string
	 */
	public static function page_url( $tab = 'connection' ) {
		return add_query_arg(
			array(
				'page' => self::PAGE_SLUG,
				'tab'  => sanitize_key( $tab ),
			),
			admin_url( 'admin.php' )
		);
	}

	/**
	 * Queue an admin notice for the current user (shown after the next redirect).
	 *
	 * @param string $type    success|error|warning|info.
	 * @param string $message Plain-text message.
	 */
	public static function add_notice( $type, $message ) {
		$user_id = get_current_user_id();
		if ( ! $user_id ) {
			return;
		}
		$key       = 'reckon_wc_notices_' . $user_id;
		$notices   = get_transient( $key );
		$notices   = is_array( $notices ) ? $notices : array();
		$notices[] = array(
			'type'    => in_array( $type, array( 'success', 'error', 'warning', 'info' ), true ) ? $type : 'info',
			'message' => (string) $message,
		);
		set_transient( $key, array_slice( $notices, -10 ), 10 * MINUTE_IN_SECONDS );
	}

	/**
	 * Retrieve and clear the current user's queued notices.
	 *
	 * @return array[]
	 */
	public static function pop_notices() {
		$user_id = get_current_user_id();
		if ( ! $user_id ) {
			return array();
		}
		$key     = 'reckon_wc_notices_' . $user_id;
		$notices = get_transient( $key );
		delete_transient( $key );
		return is_array( $notices ) ? $notices : array();
	}

	/**
	 * Default values for each option.
	 *
	 * @param string $option Option name.
	 * @return array
	 */
	public static function defaults( $option ) {
		switch ( $option ) {
			case self::OPTION_CREDENTIALS:
				return array(
					'client_id'        => '',
					'client_secret'    => '',
					'subscription_key' => '',
				);
			case self::OPTION_BOOK:
				return array(
					'book_id'     => '',
					'book_name'   => '',
					'country'     => '',
					'currency'    => '',
					'selected_at' => 0,
				);
			case self::OPTION_MAPPINGS:
				return array(
					'book_id'              => '',
					'sales_account'        => '',
					'shipping_account'     => '',
					'fee_account'          => '',
					'untaxed_tax_rate'     => '',
					'tax_rates'            => array(),
					'unmapped_tax_policy'  => 'block',
					'fallback_tax_rate'    => '',
					'product_policy'       => 'require_item',
					'billing_address_type' => '',
					'saved_at'             => 0,
				);
			case self::OPTION_SYNC:
				return array(
					'enabled'                  => false,
					'order_statuses'           => array( 'processing', 'completed' ),
					'debug_logging'            => false,
					'remove_data_on_uninstall' => false,
					'check_payment_status'     => true,
				);
		}
		return array();
	}

	/**
	 * Read an option merged with its defaults.
	 *
	 * @param string $option Option name.
	 * @return array
	 */
	public static function get( $option ) {
		$defaults = self::defaults( $option );
		$value    = get_option( $option, array() );
		if ( ! is_array( $value ) ) {
			$value = array();
		}
		$merged = array();
		foreach ( $defaults as $key => $default ) {
			$merged[ $key ] = array_key_exists( $key, $value ) ? $value[ $key ] : $default;
			if ( is_bool( $default ) ) {
				$merged[ $key ] = (bool) $merged[ $key ];
			} elseif ( is_int( $default ) ) {
				$merged[ $key ] = (int) $merged[ $key ];
			} elseif ( is_array( $default ) ) {
				$merged[ $key ] = is_array( $merged[ $key ] ) ? $merged[ $key ] : $default;
			} else {
				$merged[ $key ] = is_scalar( $merged[ $key ] ) ? (string) $merged[ $key ] : $default;
			}
		}
		return $merged;
	}

	/**
	 * Read a credential, preferring a wp-config.php constant when defined.
	 *
	 * @param string $key client_id, client_secret or subscription_key.
	 * @return string
	 */
	public static function get_credential( $key ) {
		$constant = self::credential_constant( $key );
		if ( $constant && defined( $constant ) ) {
			return trim( (string) constant( $constant ) );
		}
		$credentials = self::get( self::OPTION_CREDENTIALS );
		return isset( $credentials[ $key ] ) ? trim( (string) $credentials[ $key ] ) : '';
	}

	/**
	 * Name of the wp-config.php constant that can hold a credential.
	 *
	 * @param string $key Credential key.
	 * @return string
	 */
	public static function credential_constant( $key ) {
		$map = array(
			'client_id'        => 'RECKON_WC_CLIENT_ID',
			'client_secret'    => 'RECKON_WC_CLIENT_SECRET',
			'subscription_key' => 'RECKON_WC_SUBSCRIPTION_KEY',
		);
		return isset( $map[ $key ] ) ? $map[ $key ] : '';
	}

	/**
	 * Whether all credentials are present.
	 *
	 * @return bool
	 */
	public static function credentials_complete() {
		foreach ( array( 'client_id', 'client_secret', 'subscription_key' ) as $key ) {
			if ( '' === self::get_credential( $key ) ) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Masked representation of a saved secret for display. Never returns the secret.
	 *
	 * @param string $key Credential key.
	 * @return string Empty when nothing is saved.
	 */
	public static function masked_credential( $key ) {
		$value = self::get_credential( $key );
		if ( '' === $value ) {
			return '';
		}
		if ( strlen( $value ) < 12 ) {
			return str_repeat( '•', 8 );
		}
		return str_repeat( '•', 8 ) . substr( $value, -4 );
	}

	/**
	 * Whether a value is a GUID.
	 *
	 * @param mixed $value Value.
	 * @return bool
	 */
	public static function is_guid( $value ) {
		return is_string( $value ) && 1 === preg_match( self::GUID_PATTERN, $value );
	}

	/**
	 * Register the settings with the Settings API.
	 */
	public static function register() {
		register_setting(
			self::GROUP_CREDENTIALS,
			self::OPTION_CREDENTIALS,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( __CLASS__, 'sanitize_credentials' ),
				'default'           => self::defaults( self::OPTION_CREDENTIALS ),
				'show_in_rest'      => false,
			)
		);
		register_setting(
			self::GROUP_BOOK,
			self::OPTION_BOOK,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( __CLASS__, 'sanitize_book' ),
				'default'           => self::defaults( self::OPTION_BOOK ),
				'show_in_rest'      => false,
			)
		);
		register_setting(
			self::GROUP_MAPPINGS,
			self::OPTION_MAPPINGS,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( __CLASS__, 'sanitize_mappings' ),
				'default'           => self::defaults( self::OPTION_MAPPINGS ),
				'show_in_rest'      => false,
			)
		);
		register_setting(
			self::GROUP_SYNC,
			self::OPTION_SYNC,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( __CLASS__, 'sanitize_sync' ),
				'default'           => self::defaults( self::OPTION_SYNC ),
				'show_in_rest'      => false,
			)
		);
	}

	/**
	 * Report a validation problem to the administrator.
	 *
	 * @param string $code    Code.
	 * @param string $message Message.
	 * @param string $type    error|warning|success|info.
	 */
	private static function error( $code, $message, $type = 'error' ) {
		if ( function_exists( 'add_settings_error' ) ) {
			add_settings_error( self::ERROR_SLUG, 'reckon_wc_' . $code, $message, $type );
		}
	}

	/**
	 * Read a submitted scalar string. Arrays and objects are rejected.
	 *
	 * @param array  $input Input.
	 * @param string $key   Key.
	 * @return string|null|false Trimmed string, null when absent, false when not a scalar.
	 */
	private static function input_string( $input, $key ) {
		if ( ! array_key_exists( $key, $input ) || null === $input[ $key ] ) {
			return null;
		}
		if ( ! is_scalar( $input[ $key ] ) ) {
			return false;
		}
		return trim( (string) $input[ $key ] );
	}

	/**
	 * Read a submitted checkbox (hidden "0" + checkbox "1").
	 *
	 * @param array  $input Input.
	 * @param string $key   Key.
	 * @return bool|null Null when absent.
	 */
	private static function input_bool( $input, $key ) {
		if ( ! array_key_exists( $key, $input ) ) {
			return null;
		}
		$value = $input[ $key ];
		if ( is_bool( $value ) ) {
			return $value;
		}
		return is_scalar( $value ) && in_array( (string) $value, array( '1', 'yes', 'on', 'true' ), true );
	}

	/**
	 * Sanitize the credentials option.
	 *
	 * A blank secret or subscription key keeps the saved value. The saved value is
	 * only removed when the matching "clear" checkbox is submitted.
	 *
	 * @param mixed $input Submitted value.
	 * @return array
	 */
	public static function sanitize_credentials( $input ) {
		if ( self::$raw_write ) {
			return $input;
		}
		$current = self::get( self::OPTION_CREDENTIALS );
		if ( ! is_array( $input ) ) {
			self::error( 'credentials_invalid', __( 'The credentials form submission was not valid. Nothing was changed.', 'sparxsync-accounting-integration-for-reckon-one' ) );
			return $current;
		}

		$out = $current;

		$client_id = self::input_string( $input, 'client_id' );
		if ( false === $client_id ) {
			self::error( 'client_id_invalid', __( 'Client ID must be text.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		} elseif ( null !== $client_id ) {
			if ( '' === $client_id || preg_match( '/^[\x21-\x7E]{1,200}$/', $client_id ) ) {
				$out['client_id'] = $client_id;
			} else {
				self::error( 'client_id_invalid', __( 'Client ID contains unsupported characters or is too long. The saved Client ID was kept.', 'sparxsync-accounting-integration-for-reckon-one' ) );
			}
		}

		$secrets = array(
			'client_secret'    => array( '/^[\x21-\x7E]{1,500}$/', __( 'Client Secret', 'sparxsync-accounting-integration-for-reckon-one' ) ),
			'subscription_key' => array( '/^[\x21-\x7E]{8,256}$/', __( 'Subscription Key', 'sparxsync-accounting-integration-for-reckon-one' ) ),
		);
		foreach ( $secrets as $key => $rule ) {
			if ( true === self::input_bool( $input, 'clear_' . $key ) ) {
				$out[ $key ] = '';
				continue;
			}
			$value = self::input_string( $input, $key );
			if ( false === $value ) {
				/* translators: %s: field label. */
				self::error( $key . '_invalid', sprintf( __( '%s must be text. The saved value was kept.', 'sparxsync-accounting-integration-for-reckon-one' ), $rule[1] ) );
				continue;
			}
			if ( null === $value || '' === $value ) {
				continue; // Blank keeps the saved secret.
			}
			if ( ! preg_match( $rule[0], $value ) ) {
				/* translators: %s: field label. */
				self::error( $key . '_invalid', sprintf( __( '%s contains unsupported characters or has an invalid length. The saved value was kept.', 'sparxsync-accounting-integration-for-reckon-one' ), $rule[1] ) );
				continue;
			}
			$out[ $key ] = $value;
		}

		return $out;
	}

	/**
	 * After credentials change: a different Client ID invalidates existing tokens.
	 *
	 * @param mixed $old Old value.
	 * @param mixed $new New value.
	 */
	public static function credentials_updated( $old, $new ) {
		$old_id = is_array( $old ) && isset( $old['client_id'] ) ? (string) $old['client_id'] : '';
		$new_id = is_array( $new ) && isset( $new['client_id'] ) ? (string) $new['client_id'] : '';
		if ( $old_id !== $new_id && '' !== $old_id && class_exists( 'Reckon_WC_OAuth' ) && Reckon_WC_OAuth::has_tokens() ) {
			Reckon_WC_OAuth::clear_tokens( 'reconnect_required', 'client_changed' );
			self::error( 'client_changed', __( 'The Client ID changed, so the existing Reckon connection was cleared. Connect again to resume synchronization.', 'sparxsync-accounting-integration-for-reckon-one' ), 'warning' );
		}
	}

	/**
	 * Sanitize the book selection.
	 *
	 * @param mixed $input Submitted value.
	 * @return array
	 */
	public static function sanitize_book( $input ) {
		if ( self::$raw_write ) {
			return $input;
		}
		$current = self::get( self::OPTION_BOOK );
		if ( ! is_array( $input ) ) {
			self::error( 'book_invalid', __( 'The book form submission was not valid. Nothing was changed.', 'sparxsync-accounting-integration-for-reckon-one' ) );
			return $current;
		}
		$book_id = self::input_string( $input, 'book_id' );
		if ( false === $book_id || null === $book_id ) {
			self::error( 'book_invalid', __( 'Choose a book from the list.', 'sparxsync-accounting-integration-for-reckon-one' ) );
			return $current;
		}
		if ( '' === $book_id ) {
			if ( '' !== $current['book_id'] ) {
				self::error( 'book_cleared', __( 'No book is selected. Synchronization is paused until a book is selected and its mappings are saved.', 'sparxsync-accounting-integration-for-reckon-one' ), 'warning' );
			}
			return self::defaults( self::OPTION_BOOK );
		}
		$book_id = strtolower( $book_id );
		if ( ! self::is_guid( $book_id ) ) {
			self::error( 'book_invalid', __( 'The selected book ID is not valid. The saved book was kept.', 'sparxsync-accounting-integration-for-reckon-one' ) );
			return $current;
		}
		if ( $book_id === strtolower( $current['book_id'] ) && '' !== $current['currency'] ) {
			return $current;
		}
		$book = class_exists( 'Reckon_WC_Reference_Data' ) ? Reckon_WC_Reference_Data::find_book( $book_id ) : null;
		if ( null === $book ) {
			self::error( 'book_unknown', __( 'That book is not in the list loaded from Reckon. Use "Refresh Reckon data" and try again. The saved book was kept.', 'sparxsync-accounting-integration-for-reckon-one' ) );
			return $current;
		}

		$out = array(
			'book_id'     => $book_id,
			'book_name'   => $book['name'],
			'country'     => $book['country'],
			'currency'    => $book['currency'],
			'selected_at' => $book_id === strtolower( $current['book_id'] ) ? $current['selected_at'] : time(),
		);
		if ( '' === $out['currency'] ) {
			self::error( 'book_currency_unknown', __( "The book's currency could not be determined from Reckon. Synchronization stays paused until it is known; use \"Refresh Reckon data\".", 'sparxsync-accounting-integration-for-reckon-one' ), 'warning' );
		}
		return $out;
	}

	/**
	 * After the book changes: mappings belong to the old book and must be reviewed.
	 *
	 * @param mixed $old Old value.
	 * @param mixed $new New value.
	 */
	public static function book_updated( $old, $new ) {
		$old_id = is_array( $old ) && isset( $old['book_id'] ) ? (string) $old['book_id'] : '';
		$new_id = is_array( $new ) && isset( $new['book_id'] ) ? (string) $new['book_id'] : '';
		if ( $old_id === $new_id ) {
			return;
		}
		Reckon_WC_Logger::info( 'Destination book changed. Account and tax mappings must be reviewed before synchronization continues.', array( 'operation' => 'settings', 'book_id' => $new_id ) );
		if ( '' !== $new_id ) {
			self::error( 'book_changed', __( 'Book changed. Synchronization is paused until you review and save the account and tax mappings for this book. Orders already synchronized are not sent again, and jobs queued for the previous book will not be redirected.', 'sparxsync-accounting-integration-for-reckon-one' ), 'warning' );
		}
	}

	/**
	 * Sanitize the account, tax and product mappings for the selected book.
	 *
	 * @param mixed $input Submitted value.
	 * @return array
	 */
	public static function sanitize_mappings( $input ) {
		if ( self::$raw_write ) {
			return $input;
		}
		$current = self::get( self::OPTION_MAPPINGS );
		if ( ! is_array( $input ) ) {
			self::error( 'mappings_invalid', __( 'The mappings form submission was not valid. Nothing was changed.', 'sparxsync-accounting-integration-for-reckon-one' ) );
			return $current;
		}

		$book_id = self::get( self::OPTION_BOOK )['book_id'];
		if ( '' === $book_id ) {
			self::error( 'mappings_no_book', __( 'Select a Reckon book before saving mappings.', 'sparxsync-accounting-integration-for-reckon-one' ) );
			return $current;
		}
		$submitted_book = self::input_string( $input, 'book_id' );
		if ( ! is_string( $submitted_book ) || strtolower( $submitted_book ) !== strtolower( $book_id ) ) {
			self::error( 'mappings_book_mismatch', __( 'These mappings were loaded for a different book. Reload the page and review them for the selected book. Nothing was changed.', 'sparxsync-accounting-integration-for-reckon-one' ) );
			return $current;
		}

		$ref = class_exists( 'Reckon_WC_Reference_Data' ) ? Reckon_WC_Reference_Data::get_book_data( $book_id ) : null;
		if ( null === $ref ) {
			self::error( 'mappings_no_reference', __( 'Accounts and tax rates for this book have not been loaded. Use "Refresh Reckon data" first. Nothing was changed.', 'sparxsync-accounting-integration-for-reckon-one' ) );
			return $current;
		}

		// Start from the saved mappings only when they belong to this book (or are unconfirmed legacy values).
		$base = ( $current['book_id'] === $book_id || '' === $current['book_id'] ) ? $current : self::defaults( self::OPTION_MAPPINGS );
		$out  = $base;

		$account_ids = array_keys( $ref['ledger_accounts'] );
		$tax_ids     = array_keys( $ref['tax_rates'] );
		$address_ids = array_keys( $ref['address_types'] );

		$guid_fields = array(
			'sales_account'        => array( $account_ids, __( 'Sales ledger account', 'sparxsync-accounting-integration-for-reckon-one' ) ),
			'shipping_account'     => array( $account_ids, __( 'Shipping ledger account', 'sparxsync-accounting-integration-for-reckon-one' ) ),
			'fee_account'          => array( $account_ids, __( 'Fee ledger account', 'sparxsync-accounting-integration-for-reckon-one' ) ),
			'untaxed_tax_rate'     => array( $tax_ids, __( 'Tax code for untaxed lines', 'sparxsync-accounting-integration-for-reckon-one' ) ),
			'fallback_tax_rate'    => array( $tax_ids, __( 'Fallback tax code', 'sparxsync-accounting-integration-for-reckon-one' ) ),
			'billing_address_type' => array( $address_ids, __( 'Billing address type', 'sparxsync-accounting-integration-for-reckon-one' ) ),
		);
		foreach ( $guid_fields as $key => $rule ) {
			$value = self::input_string( $input, $key );
			if ( null === $value ) {
				continue;
			}
			$value = false === $value ? false : strtolower( $value );
			if ( '' === $value || ( is_string( $value ) && in_array( $value, $rule[0], true ) ) ) {
				$out[ $key ] = $value;
			} else {
				/* translators: %s: field label. */
				self::error( $key . '_invalid', sprintf( __( '%s: the selected value is not available in this book. The previous value was kept.', 'sparxsync-accounting-integration-for-reckon-one' ), $rule[1] ) );
				$out[ $key ] = in_array( $base[ $key ], $rule[0], true ) ? $base[ $key ] : '';
			}
		}

		$enums = array(
			'unmapped_tax_policy' => array( 'block', 'fallback' ),
			'product_policy'      => array( 'require_item', 'item_or_account', 'account_only' ),
		);
		foreach ( $enums as $key => $allowed ) {
			$value = self::input_string( $input, $key );
			if ( null === $value ) {
				continue;
			}
			if ( is_string( $value ) && in_array( $value, $allowed, true ) ) {
				$out[ $key ] = $value;
			} else {
				self::error( $key . '_invalid', __( 'An unsupported policy value was submitted. The previous value was kept.', 'sparxsync-accounting-integration-for-reckon-one' ) );
			}
		}

		if ( array_key_exists( 'tax_rates', $input ) ) {
			if ( ! is_array( $input['tax_rates'] ) ) {
				self::error( 'tax_rates_invalid', __( 'Tax mappings were not submitted correctly. The previous tax mappings were kept.', 'sparxsync-accounting-integration-for-reckon-one' ) );
			} else {
				$map = array();
				foreach ( $input['tax_rates'] as $wc_rate_id => $reckon_rate ) {
					if ( ! is_scalar( $reckon_rate ) || ! preg_match( '/^\d{1,10}$/', (string) $wc_rate_id ) ) {
						self::error( 'tax_rates_invalid', __( 'An invalid tax mapping row was ignored.', 'sparxsync-accounting-integration-for-reckon-one' ) );
						continue;
					}
					$reckon_rate = strtolower( trim( (string) $reckon_rate ) );
					if ( '' === $reckon_rate ) {
						continue;
					}
					if ( ! in_array( $reckon_rate, $tax_ids, true ) ) {
						/* translators: %d: WooCommerce tax rate ID. */
						self::error( 'tax_rates_invalid', sprintf( __( 'The Reckon tax code chosen for WooCommerce tax rate #%d is not available in this book and was not saved.', 'sparxsync-accounting-integration-for-reckon-one' ), (int) $wc_rate_id ) );
						continue;
					}
					if ( ! self::wc_tax_rate_exists( (int) $wc_rate_id ) ) {
						continue;
					}
					$map[ (string) (int) $wc_rate_id ] = $reckon_rate;
				}
				$out['tax_rates'] = $map;
			}
		}

		if ( 'fallback' === $out['unmapped_tax_policy'] && '' === $out['fallback_tax_rate'] ) {
			self::error( 'fallback_missing', __( 'The fallback tax policy needs a fallback tax code. Unmapped tax rates will block synchronization until one is chosen.', 'sparxsync-accounting-integration-for-reckon-one' ), 'warning' );
		}
		if ( in_array( $out['product_policy'], array( 'item_or_account', 'account_only' ), true ) && '' === $out['sales_account'] ) {
			self::error( 'sales_account_missing', __( 'The selected product policy posts lines to the sales ledger account, but none is selected.', 'sparxsync-accounting-integration-for-reckon-one' ), 'warning' );
		}

		$out['book_id']  = $book_id;
		$out['saved_at'] = time();
		return $out;
	}

	/**
	 * Whether a WooCommerce tax rate ID exists.
	 *
	 * @param int $rate_id Rate ID.
	 * @return bool
	 */
	private static function wc_tax_rate_exists( $rate_id ) {
		if ( ! class_exists( 'WC_Tax' ) ) {
			return false;
		}
		$rate = WC_Tax::_get_tax_rate( $rate_id );
		return ! empty( $rate );
	}

	/**
	 * Sanitize the synchronization settings.
	 *
	 * @param mixed $input Submitted value.
	 * @return array
	 */
	public static function sanitize_sync( $input ) {
		if ( self::$raw_write ) {
			return $input;
		}
		$current = self::get( self::OPTION_SYNC );
		if ( ! is_array( $input ) ) {
			self::error( 'sync_invalid', __( 'The synchronization form submission was not valid. Nothing was changed.', 'sparxsync-accounting-integration-for-reckon-one' ) );
			return $current;
		}
		$out = $current;

		foreach ( array( 'enabled', 'debug_logging', 'remove_data_on_uninstall', 'check_payment_status' ) as $key ) {
			$value = self::input_bool( $input, $key );
			if ( null !== $value ) {
				$out[ $key ] = $value;
			}
		}

		if ( array_key_exists( 'order_statuses', $input ) ) {
			if ( ! is_array( $input['order_statuses'] ) ) {
				self::error( 'statuses_invalid', __( 'Order statuses were not submitted correctly. The previous selection was kept.', 'sparxsync-accounting-integration-for-reckon-one' ) );
			} else {
				$allowed  = array_keys( self::eligible_status_choices() );
				$statuses = array();
				foreach ( $input['order_statuses'] as $status ) {
					if ( ! is_scalar( $status ) ) {
						continue;
					}
					$status = preg_replace( '/^wc-/', '', sanitize_key( (string) $status ) );
					if ( '' === $status ) {
						continue; // Placeholder that lets an empty selection be submitted.
					}
					if ( in_array( $status, $allowed, true ) ) {
						$statuses[] = $status;
					} else {
						self::error( 'status_invalid', __( 'An order status that cannot trigger invoices was ignored.', 'sparxsync-accounting-integration-for-reckon-one' ) );
					}
				}
				$out['order_statuses'] = array_values( array_unique( $statuses ) );
			}
		}

		if ( $out['enabled'] && empty( $out['order_statuses'] ) ) {
			self::error( 'statuses_empty', __( 'Choose at least one order status before enabling automatic synchronization. Automatic synchronization was left disabled.', 'sparxsync-accounting-integration-for-reckon-one' ) );
			$out['enabled'] = false;
		}

		return $out;
	}

	/**
	 * Order statuses that may trigger synchronization, keyed without the "wc-" prefix.
	 *
	 * @return array
	 */
	public static function eligible_status_choices() {
		$choices = array();
		if ( function_exists( 'wc_get_order_statuses' ) ) {
			foreach ( wc_get_order_statuses() as $key => $label ) {
				$status = preg_replace( '/^wc-/', '', $key );
				if ( ! in_array( $status, self::EXCLUDED_STATUSES, true ) ) {
					$choices[ $status ] = $label;
				}
			}
		}
		return $choices;
	}

	/**
	 * Stable per-site token used in external invoice references.
	 *
	 * @return string
	 */
	public static function get_site_token() {
		$token = get_option( self::OPTION_SITE_TOKEN, '' );
		if ( ! is_string( $token ) || ! preg_match( '/^[a-z0-9]{6}$/', $token ) ) {
			$token = strtolower( wp_generate_password( 6, false, false ) );
			if ( ! add_option( self::OPTION_SITE_TOKEN, $token, '', false ) ) {
				$stored = get_option( self::OPTION_SITE_TOKEN, '' );
				$token  = is_string( $stored ) && preg_match( '/^[a-z0-9]{6}$/', $stored ) ? $stored : $token;
			}
		}
		return $token;
	}

	/**
	 * Create missing options (secrets with autoload disabled) and migrate 1.x settings.
	 * Safe to run repeatedly. Never enables synchronization.
	 */
	public static function maybe_migrate() {
		$version = (int) get_option( self::OPTION_VERSION, 0 );
		if ( $version >= self::SCHEMA_VERSION ) {
			return;
		}

		$had_legacy = false;
		foreach ( self::LEGACY_OPTIONS as $legacy ) {
			if ( false !== get_option( $legacy, false ) ) {
				$had_legacy = true;
				break;
			}
		}

		// Credentials: not autoloaded.
		if ( false === get_option( self::OPTION_CREDENTIALS, false ) ) {
			$credentials = self::defaults( self::OPTION_CREDENTIALS );
			foreach ( array( 'client_id', 'client_secret', 'subscription_key' ) as $key ) {
				$legacy = get_option( 'reckon_wc_' . $key, '' );
				if ( is_string( $legacy ) ) {
					$credentials[ $key ] = trim( $legacy );
				}
			}
			self::raw_add_option( self::OPTION_CREDENTIALS, $credentials, false );
		}

		// Tokens: not autoloaded; marked unverified so the UI does not claim a live connection.
		if ( false === get_option( 'reckon_wc_tokens', false ) ) {
			$refresh = get_option( 'reckon_wc_refresh_token', '' );
			$access  = get_option( 'reckon_wc_access_token', '' );
			if ( is_string( $refresh ) && '' !== $refresh ) {
				add_option(
					'reckon_wc_tokens',
					array(
						'access_token'  => is_string( $access ) ? $access : '',
						'refresh_token' => $refresh,
						'expires_at'    => (int) get_option( 'reckon_wc_token_expiry', 0 ),
						'obtained_at'   => 0,
					),
					'',
					false
				);
				add_option(
					'reckon_wc_connection',
					array(
						'status'           => 'connected',
						'connected_at'     => 0,
						'last_verified_at' => 0,
						'last_error'       => '',
						'connected_by'     => 0,
					),
					'',
					false
				);
			}
		}

		// Book: carried over only when it is a valid ID. Currency must be refreshed from Reckon.
		if ( false === get_option( self::OPTION_BOOK, false ) ) {
			$book   = self::defaults( self::OPTION_BOOK );
			$legacy = get_option( 'reckon_wc_book_id', '' );
			if ( self::is_guid( $legacy ) ) {
				$book['book_id']     = strtolower( $legacy );
				$book['selected_at'] = time();
			}
			self::raw_add_option( self::OPTION_BOOK, $book, true );
		}

		// Mappings: legacy values are pre-filled but left unconfirmed (book_id = '') so they must be reviewed.
		if ( false === get_option( self::OPTION_MAPPINGS, false ) ) {
			$mappings = self::defaults( self::OPTION_MAPPINGS );
			foreach ( array( 'sales_account', 'shipping_account' ) as $key ) {
				$legacy = get_option( 'reckon_wc_' . $key, '' );
				if ( self::is_guid( $legacy ) ) {
					$mappings[ $key ] = strtolower( $legacy );
				}
			}
			$legacy_tax = get_option( 'reckon_wc_default_tax_rate_id', '' );
			if ( self::is_guid( $legacy_tax ) ) {
				// Offered as the fallback code, but the policy stays "block" until an administrator chooses otherwise.
				$mappings['fallback_tax_rate'] = strtolower( $legacy_tax );
			}
			self::raw_add_option( self::OPTION_MAPPINGS, $mappings, false );
		}

		// Synchronization settings: always disabled after install or upgrade.
		if ( false === get_option( self::OPTION_SYNC, false ) ) {
			self::raw_add_option( self::OPTION_SYNC, self::defaults( self::OPTION_SYNC ), true );
		}

		self::get_site_token();

		// Remove legacy options only after their values were copied. Several held secrets and were autoloaded.
		$copied = false !== get_option( self::OPTION_CREDENTIALS, false ) && false !== get_option( self::OPTION_BOOK, false );
		if ( $copied ) {
			foreach ( self::LEGACY_OPTIONS as $legacy ) {
				delete_option( $legacy );
			}
		}

		if ( $had_legacy ) {
			update_option( self::OPTION_UPGRADED, 1, false );
		}
		update_option( self::OPTION_VERSION, self::SCHEMA_VERSION, true );
	}

	/**
	 * Configuration checks shown to administrators. The same checks gate the worker.
	 *
	 * @return array[] Each: id, level (ok|warning|error), blocking (bool), message.
	 */
	public static function validate_configuration() {
		$checks = array();
		$add    = function ( $id, $level, $blocking, $message ) use ( &$checks ) {
			$checks[] = array(
				'id'       => $id,
				'level'    => $level,
				'blocking' => $blocking,
				'message'  => $message,
			);
		};

		$sync     = self::get( self::OPTION_SYNC );
		$book     = self::get( self::OPTION_BOOK );
		$mappings = self::get( self::OPTION_MAPPINGS );

		if ( class_exists( 'Reckon_WC_Integration' ) && ! Reckon_WC_Integration::scheduler_available() ) {
			$add( 'scheduler', 'error', true, __( 'Action Scheduler is not available, so orders cannot be queued.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}

		if ( $sync['enabled'] ) {
			$add( 'sync_enabled', 'ok', false, __( 'Automatic synchronization is enabled.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		} else {
			$add( 'sync_disabled', 'warning', true, __( 'Automatic synchronization is disabled. Queued jobs will not send data until it is enabled.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}

		if ( self::credentials_complete() ) {
			$add( 'credentials', 'ok', false, __( 'Client ID, Client Secret and Subscription Key are saved.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		} else {
			$add( 'credentials_missing', 'error', true, __( 'Client ID, Client Secret and Subscription Key are all required.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}

		$connection = class_exists( 'Reckon_WC_OAuth' ) ? Reckon_WC_OAuth::get_connection() : array( 'status' => 'disconnected' );
		if ( 'connected' === $connection['status'] && class_exists( 'Reckon_WC_OAuth' ) && Reckon_WC_OAuth::has_tokens() ) {
			$add( 'connection', 'ok', false, __( 'Connected to Reckon.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		} elseif ( 'reconnect_required' === $connection['status'] ) {
			$add( 'reconnect_required', 'error', true, __( 'Reckon rejected the saved authorization. Connect again.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		} else {
			$add( 'not_connected', 'error', true, __( 'Not connected to Reckon.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}

		if ( '' === $book['book_id'] ) {
			$add( 'book_missing', 'error', true, __( 'No Reckon book is selected.', 'sparxsync-accounting-integration-for-reckon-one' ) );
			return $checks;
		}
		if ( '' === $book['currency'] ) {
			$add( 'book_currency_unknown', 'error', true, __( "The selected book's currency is unknown. Use \"Refresh Reckon data\".", 'sparxsync-accounting-integration-for-reckon-one' ) );
		} else {
			$store_currency = function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : '';
			if ( '' !== $store_currency && strtoupper( $store_currency ) !== strtoupper( $book['currency'] ) ) {
				/* translators: 1: store currency, 2: book currency. */
				$add( 'currency_mismatch', 'warning', false, sprintf( __( 'The store currency (%1$s) differs from the book currency (%2$s). Orders in other currencies are blocked.', 'sparxsync-accounting-integration-for-reckon-one' ), $store_currency, $book['currency'] ) );
			}
		}

		$ref = class_exists( 'Reckon_WC_Reference_Data' ) ? Reckon_WC_Reference_Data::get_book_data( $book['book_id'] ) : null;
		if ( null === $ref ) {
			$add( 'reference_missing', 'error', true, __( 'Accounts and tax rates for the selected book have not been loaded. Use "Refresh Reckon data".', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}

		if ( $mappings['book_id'] !== $book['book_id'] ) {
			$add( 'mappings_review_required', 'error', true, __( 'Account and tax mappings have not been saved for the selected book. Review and save them.', 'sparxsync-accounting-integration-for-reckon-one' ) );
			return $checks;
		}

		if ( null !== $ref ) {
			$tax = $ref['tax_settings'];
			if ( ! empty( $tax['tax_registered'] ) && isset( $tax['tax_amount_editable'] ) && false === $tax['tax_amount_editable'] ) {
				$add( 'tax_amount_not_editable', 'error', true, __( 'The Reckon book does not allow tax amounts to be edited. This plugin sends the exact tax amounts charged by WooCommerce and cannot do so for this book.', 'sparxsync-accounting-integration-for-reckon-one' ) );
			}
			if ( null === Reckon_WC_Reference_Data::email_type_id( $book['book_id'] ) ) {
				$add( 'email_type_missing', 'warning', false, __( 'No "Email" electronic address type was found in the book. New Reckon customers cannot be created until it exists.', 'sparxsync-accounting-integration-for-reckon-one' ) );
			}
		}

		if ( in_array( $mappings['product_policy'], array( 'item_or_account', 'account_only' ), true ) && '' === $mappings['sales_account'] ) {
			$add( 'sales_account_missing', 'error', true, __( 'The product policy needs a sales ledger account.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}
		if ( '' === $mappings['shipping_account'] ) {
			$add( 'shipping_account_missing', 'warning', false, __( 'No shipping ledger account is selected. Orders with shipping charges will be blocked.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}
		if ( '' === $mappings['fee_account'] ) {
			$add( 'fee_account_missing', 'warning', false, __( 'No fee ledger account is selected. Orders with fees will be blocked.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}
		if ( '' === $mappings['untaxed_tax_rate'] ) {
			$add( 'untaxed_missing', 'warning', false, __( 'No tax code is selected for untaxed lines. Orders with untaxed lines will be blocked.', 'sparxsync-accounting-integration-for-reckon-one' ) );
		}

		$unmapped = self::unmapped_wc_tax_rates( $mappings );
		if ( ! empty( $unmapped ) ) {
			$level = ( 'fallback' === $mappings['unmapped_tax_policy'] && '' !== $mappings['fallback_tax_rate'] ) ? 'warning' : 'error';
			/* translators: %s: comma-separated list of tax rate names. */
			$add( 'tax_unmapped', $level, false, sprintf( __( 'WooCommerce tax rates without a Reckon tax code: %s.', 'sparxsync-accounting-integration-for-reckon-one' ), implode( ', ', $unmapped ) ) );
		}

		return $checks;
	}

	/**
	 * First blocking configuration problem, or null when the worker may send data.
	 *
	 * @return WP_Error|null
	 */
	public static function sync_blocker() {
		foreach ( self::validate_configuration() as $check ) {
			if ( $check['blocking'] ) {
				return new WP_Error( 'reckon_wc_' . $check['id'], $check['message'], array( 'retryable' => false ) );
			}
		}
		return null;
	}

	/**
	 * Labels of WooCommerce tax rates that have no mapping.
	 *
	 * @param array $mappings Mappings.
	 * @return string[]
	 */
	public static function unmapped_wc_tax_rates( $mappings ) {
		$labels = array();
		foreach ( self::wc_tax_rates() as $rate ) {
			if ( empty( $mappings['tax_rates'][ (string) $rate['id'] ] ) ) {
				$labels[] = $rate['label'];
			}
		}
		return $labels;
	}

	/**
	 * All WooCommerce tax rates across tax classes.
	 *
	 * @return array[] Each: id, label, rate, class, compound.
	 */
	public static function wc_tax_rates() {
		if ( ! class_exists( 'WC_Tax' ) ) {
			return array();
		}
		$classes = array_merge( array( '' ), WC_Tax::get_tax_class_slugs() );
		$rates   = array();
		foreach ( $classes as $class ) {
			foreach ( WC_Tax::get_rates_for_tax_class( $class ) as $rate ) {
				$rate    = (object) $rate;
				$id      = (int) $rate->tax_rate_id;
				$label   = sprintf(
					'#%d %s %s%% (%s%s)',
					$id,
					$rate->tax_rate_name,
					wc_format_decimal( $rate->tax_rate, '', true ),
					'' === $rate->tax_rate_country ? '*' : $rate->tax_rate_country,
					'' === $class ? '' : ', ' . $class
				);
				$rates[] = array(
					'id'       => $id,
					'label'    => $label,
					'rate'     => (float) $rate->tax_rate,
					'class'    => $class,
					'compound' => ! empty( $rate->tax_rate_compound ),
				);
			}
		}
		return $rates;
	}
}
