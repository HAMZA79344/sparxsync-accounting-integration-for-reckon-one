<?php
/**
 * Uninstall routine.
 *
 * Always: cancels this plugin's pending background jobs (they cannot run once the
 * plugin files are gone).
 *
 * Only when "Delete settings ... when the plugin is deleted" was enabled: removes
 * options, credentials, tokens, cached Reckon data, locks, OAuth state rows,
 * notices and remembered Reckon customer IDs on user accounts.
 *
 * Never: deletes WooCommerce orders, order synchronization metadata (Reckon
 * invoice IDs, references, states) or anything in Reckon. Keeping the order
 * metadata prevents the same orders from being exported again after a reinstall.
 *
 * @package Reckon_WC
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

/**
 * Clean up one site.
 */
function reckon_wc_uninstall_site() {
	global $wpdb;

	delete_transient( 'reckon_wc_dashboard_stats' );

	if ( function_exists( 'as_unschedule_all_actions' ) ) {
		as_unschedule_all_actions( 'reckon_wc_sync_order' );
		as_unschedule_all_actions( 'reckon_wc_verify_invoice' );
		as_unschedule_all_actions( 'reckon_wc_recover_verification' );
		as_unschedule_all_actions( 'reckon_wc_history_export_batch' );
		as_unschedule_all_actions( 'reckon_wc_check_payments' );
	}

	$settings = get_option( 'reckon_wc_sync_settings', array() );
	if ( ! is_array( $settings ) || empty( $settings['remove_data_on_uninstall'] ) ) {
		return;
	}

	$options = array(
		'reckon_wc_credentials',
		'reckon_wc_book',
		'reckon_wc_mappings',
		'reckon_wc_sync_settings',
		'reckon_wc_settings_version',
		'reckon_wc_site_token',
		'reckon_wc_upgrade_notice',
		'reckon_wc_tokens',
		'reckon_wc_connection',
		'reckon_wc_reference_data',
		'reckon_wc_redirect_uri',
		'reckon_wc_verify_recovery_offset',
		'reckon_wc_history_export',
		// 1.x options, in case the migration never ran.
		'reckon_wc_client_id',
		'reckon_wc_client_secret',
		'reckon_wc_subscription_key',
		'reckon_wc_book_id',
		'reckon_wc_access_token',
		'reckon_wc_refresh_token',
		'reckon_wc_token_expiry',
		'reckon_wc_sales_account',
		'reckon_wc_shipping_account',
		'reckon_wc_default_tax_rate_id',
	);
	foreach ( $options as $option ) {
		delete_option( $option );
	}

	// Locks, OAuth state rows, shared customer attempts and per-user notices.
	// These rows have dynamic names, so a prefixed, prepared DELETE is the only way to find them.
	// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.SlowDBQuery
	$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s", $wpdb->esc_like( '_reckon_wc_lock_' ) . '%', $wpdb->esc_like( '_reckon_wc_oauth_state_' ) . '%' ) );
	$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", $wpdb->esc_like( '_reckon_wc_cust_attempt_' ) . '%' ) );
	$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s", $wpdb->esc_like( '_transient_reckon_wc_notices_' ) . '%', $wpdb->esc_like( '_transient_timeout_reckon_wc_notices_' ) . '%' ) );

	// Remembered Reckon customer IDs. Scope deletion to the current site so deleting
	// one site's settings never erases another site's mappings. Legacy unscoped keys
	// are left alone on multisite (they may belong to a pre-isolation site).
	if ( is_multisite() ) {
		$prefix = '_reckon_wc_customer_site_' . get_current_blog_id() . '_';
	} else {
		$prefix = '_reckon_wc_customer_';
	}
	$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->usermeta} WHERE meta_key LIKE %s", $wpdb->esc_like( $prefix ) . '%' ) );
	// phpcs:enable
}

if ( is_multisite() ) {
	$reckon_offset = 0;
	$reckon_number = 100;
	while ( true ) {
		$reckon_sites = get_sites(
			array(
				'fields' => 'ids',
				'number' => $reckon_number,
				'offset' => $reckon_offset,
			)
		);
		if ( empty( $reckon_sites ) ) {
			break;
		}
		foreach ( $reckon_sites as $reckon_wc_site_id ) {
			switch_to_blog( $reckon_wc_site_id );
			reckon_wc_uninstall_site();
			restore_current_blog();
		}
		$reckon_offset += $reckon_number;
		if ( count( $reckon_sites ) < $reckon_number ) {
			break;
		}
	}
} else {
	reckon_wc_uninstall_site();
}
