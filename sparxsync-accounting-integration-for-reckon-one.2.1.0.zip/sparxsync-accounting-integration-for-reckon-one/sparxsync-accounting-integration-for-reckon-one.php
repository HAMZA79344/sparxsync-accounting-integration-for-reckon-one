<?php
/**
 * Plugin Name: SparxSync Accounting Integration for Reckon One
 * Plugin URI: https://skillssparx.com/our-plugin/
 * Description: Sends paid WooCommerce orders to Reckon One as customer invoices, in the background, with totals and tax matched to the order. Independent integration; not an official Reckon or WooCommerce product.
 * Version: 2.1.0
 * Author: SkillsSparx
 * Author URI: https://skillssparx.com/
 * Text Domain: sparxsync-accounting-integration-for-reckon-one
 * Requires at least: 6.2
 * Requires PHP: 7.4
 * Requires Plugins: woocommerce
 * WC requires at least: 8.2
 * WC tested up to: 11.2
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 *
 * @package Reckon_WC
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

// Another copy of this plugin (for example an older upload in a differently named
// folder) is already loaded. Declaring the classes twice would be a fatal error, so
// this copy stays inactive and asks the administrator to deactivate one of them.
if ( defined( 'RECKON_WC_VERSION' ) ) {
	$reckon_wc_duplicate = plugin_basename( __FILE__ );
	add_action(
		'admin_notices',
		function () use ( $reckon_wc_duplicate ) {
			if ( ! current_user_can( 'activate_plugins' ) ) {
				return;
			}
			echo '<div class="notice notice-error"><p>';
			echo esc_html(
				sprintf(
					/* translators: 1: folder/file of the copy that is running, 2: folder/file of the copy that was skipped. */
					__( 'Two copies of SparxSync Accounting Integration for Reckon One are active (%1$s and %2$s). Only the first one is running. Deactivate and delete the copy you do not use.', 'sparxsync-accounting-integration-for-reckon-one' ),
					RECKON_WC_BASENAME,
					$reckon_wc_duplicate
				)
			);
			echo '</p></div>';
		}
	);
	unset( $reckon_wc_duplicate );
	return;
}

define( 'RECKON_WC_VERSION', '2.1.0' );
define( 'RECKON_WC_FILE', __FILE__ );
define( 'RECKON_WC_PATH', plugin_dir_path( __FILE__ ) );
define( 'RECKON_WC_URL', plugin_dir_url( __FILE__ ) );
define( 'RECKON_WC_BASENAME', plugin_basename( __FILE__ ) );
define( 'RECKON_WC_MIN_WC_VERSION', '8.2' );

// Classes that only depend on WordPress. Loading them has no side effects.
require_once RECKON_WC_PATH . 'includes/class-reckon-wc-logger.php';
require_once RECKON_WC_PATH . 'includes/class-reckon-wc-lock.php';
require_once RECKON_WC_PATH . 'includes/class-reckon-wc-settings.php';

/**
 * Main plugin class.
 */
class Reckon_WC_Integration {

	/**
	 * Instance of this class.
	 *
	 * @var Reckon_WC_Integration|null
	 */
	protected static $instance = null;

	/**
	 * Whether the WooCommerce-dependent components were loaded.
	 *
	 * @var bool
	 */
	private $loaded = false;

	/**
	 * Return an instance of this class.
	 *
	 * @return Reckon_WC_Integration
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor. Runs once, on plugins_loaded.
	 */
	private function __construct() {
		$problem = self::dependency_problem();
		if ( null !== $problem ) {
			add_action( 'admin_notices', array( $this, 'dependency_notice' ) );
			return;
		}

		Reckon_WC_Settings::maybe_migrate();
		$this->includes();
		$this->init_components();
		$this->loaded = true;
	}

	/**
	 * Whether the WooCommerce-dependent components are active.
	 *
	 * @return bool
	 */
	public function is_loaded() {
		return $this->loaded;
	}

	/**
	 * Describe a missing or outdated dependency, or null when requirements are met.
	 *
	 * @return string|null
	 */
	public static function dependency_problem() {
		if ( ! class_exists( 'WooCommerce' ) || ! defined( 'WC_VERSION' ) ) {
			return 'woocommerce_missing';
		}
		if ( version_compare( WC_VERSION, RECKON_WC_MIN_WC_VERSION, '<' ) ) {
			return 'woocommerce_outdated';
		}
		return null;
	}

	/**
	 * Whether WooCommerce's Action Scheduler functions are available.
	 *
	 * @return bool
	 */
	public static function scheduler_available() {
		return function_exists( 'as_enqueue_async_action' )
			&& function_exists( 'as_schedule_single_action' )
			&& function_exists( 'as_has_scheduled_action' )
			&& function_exists( 'as_unschedule_all_actions' );
	}

	/**
	 * Include files that require WooCommerce.
	 */
	private function includes() {
		require_once RECKON_WC_PATH . 'includes/class-reckon-wc-oauth.php';
		require_once RECKON_WC_PATH . 'includes/class-reckon-wc-api.php';
		require_once RECKON_WC_PATH . 'includes/class-reckon-wc-reference-data.php';
		require_once RECKON_WC_PATH . 'includes/class-reckon-wc-order-state.php';
		require_once RECKON_WC_PATH . 'includes/class-reckon-wc-invoice-builder.php';
		require_once RECKON_WC_PATH . 'includes/class-reckon-wc-customer-resolver.php';
		require_once RECKON_WC_PATH . 'includes/class-reckon-wc-sync.php';
		require_once RECKON_WC_PATH . 'includes/class-reckon-wc-history-export.php';
		require_once RECKON_WC_PATH . 'includes/class-reckon-wc-payment-status.php';
		if ( is_admin() ) {
			require_once RECKON_WC_PATH . 'includes/class-reckon-wc-admin.php';
			require_once RECKON_WC_PATH . 'includes/class-reckon-wc-dashboard.php';
			require_once RECKON_WC_PATH . 'includes/class-reckon-wc-invoice-preview.php';
			require_once RECKON_WC_PATH . 'includes/class-reckon-wc-order-admin.php';
		}
	}

	/**
	 * Register hooks for each component exactly once.
	 */
	private function init_components() {
		Reckon_WC_Settings::init();
		Reckon_WC_OAuth::init();
		Reckon_WC_Sync::init();
		Reckon_WC_History_Export::init();
		Reckon_WC_Payment_Status::init();
		if ( is_admin() ) {
			Reckon_WC_Admin::init();
			Reckon_WC_Order_Admin::init();
		}
	}

	/**
	 * Admin notice for a missing or outdated WooCommerce.
	 */
	public function dependency_notice() {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}
		if ( 'woocommerce_outdated' === self::dependency_problem() ) {
			/* translators: 1: required WooCommerce version, 2: installed WooCommerce version. */
			$message = sprintf( __( 'SparxSync Accounting Integration for Reckon One requires WooCommerce %1$s or later. You are running %2$s. Synchronization is inactive until WooCommerce is updated.', 'sparxsync-accounting-integration-for-reckon-one' ), RECKON_WC_MIN_WC_VERSION, defined( 'WC_VERSION' ) ? WC_VERSION : '?' );
		} else {
			$message = __( 'SparxSync Accounting Integration for Reckon One requires WooCommerce to be installed and active. Synchronization is inactive.', 'sparxsync-accounting-integration-for-reckon-one' );
		}
		echo '<div class="notice notice-error"><p>' . esc_html( $message ) . '</p></div>';
	}

	/**
	 * Activation: create options and migrate legacy settings. Never needs WooCommerce.
	 */
	public static function activate() {
		Reckon_WC_Settings::maybe_migrate();
	}

	/**
	 * Deactivation: cancel this plugin's pending jobs. Settings, tokens and order
	 * synchronization history are kept. Remote Reckon records are never touched.
	 */
	public static function deactivate() {
		if ( ! self::scheduler_available() ) {
			return;
		}
		as_unschedule_all_actions( 'reckon_wc_sync_order' );
		as_unschedule_all_actions( 'reckon_wc_verify_invoice' );
		as_unschedule_all_actions( 'reckon_wc_recover_verification' );
		as_unschedule_all_actions( 'reckon_wc_history_export_batch' );
		as_unschedule_all_actions( 'reckon_wc_check_payments' );

		if ( ! class_exists( 'Reckon_WC_Sync' ) && null === self::dependency_problem() ) {
			require_once RECKON_WC_PATH . 'includes/class-reckon-wc-order-state.php';
			require_once RECKON_WC_PATH . 'includes/class-reckon-wc-sync.php';
		}
		if ( class_exists( 'Reckon_WC_Sync' ) ) {
			Reckon_WC_Sync::mark_cancelled_jobs();
		}
	}
}

add_action( 'plugins_loaded', array( 'Reckon_WC_Integration', 'get_instance' ) );
register_activation_hook( __FILE__, array( 'Reckon_WC_Integration', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'Reckon_WC_Integration', 'deactivate' ) );

/**
 * Declare compatibility with WooCommerce High-Performance Order Storage.
 * All order data is read and written through WooCommerce CRUD methods and
 * wc_get_orders(); admin screens are registered for both storage modes.
 */
add_action(
	'before_woocommerce_init',
	function () {
		if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
		}
	}
);
